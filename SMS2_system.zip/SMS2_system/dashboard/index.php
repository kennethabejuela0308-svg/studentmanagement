<?php
/**
 * SMS 2 - Dashboard
 */
$pageTitle    = 'Dashboard';
$activeModule = 'dashboard';
$breadcrumbs  = [];

require_once __DIR__ . '/../includes/breadcrumbs.php';
require_once __DIR__ . '/../includes/layout-start.php';

$visibleModules = getVisibleModules($MODULES);
$isStudentPortal = getCurrentUserRoleKey() === 'student';

if ($isStudentPortal):
    $studentId = $_SESSION['student_id'] ?? 'S230000001';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="student-portal">
    <div class="page-header student-portal-header">
        <div>
            <span class="student-kicker">Student Portal</span>
            <h1>Welcome back, <?= htmlspecialchars(getCurrentUserName()) ?></h1>
            <p>Profile, student ID, schedule, records, subjects, professors, and payments.</p>
        </div>
        <div class="student-term-badge">
            <i class="fas fa-calendar-check"></i>
            <span>SY 2026-2027</span>
        </div>
    </div>

    <div class="row g-3 mb-4 dashboard-stats">
        <div class="col-12 col-sm-6 col-xl-3">
            <section class="card stat-card primary" id="student-id">
                <div class="card-body d-flex align-items-center">
                    <div class="stat-icon me-3"><i class="fas fa-id-card"></i></div>
                    <div>
                        <h6 class="text-muted mb-0 small">Student ID</h6>
                        <h4 class="mb-0 fw-bold"><?= htmlspecialchars($studentId) ?></h4>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-12 col-sm-6 col-xl-3">
            <section class="card stat-card warning" id="account-balance">
                <div class="card-body d-flex align-items-center">
                    <div class="stat-icon me-3"><i class="fas fa-wallet"></i></div>
                    <div>
                        <h6 class="text-muted mb-0 small">Account Balance</h6>
                        <h4 class="mb-0 fw-bold">PHP 8,450.00</h4>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-12 col-sm-6 col-xl-3">
            <section class="card stat-card success">
                <div class="card-body d-flex align-items-center">
                    <div class="stat-icon me-3"><i class="fas fa-book-open"></i></div>
                    <div>
                        <h6 class="text-muted mb-0 small">Enrolled Subjects</h6>
                        <h4 class="mb-0 fw-bold">6</h4>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-12 col-sm-6 col-xl-3">
            <section class="card stat-card info">
                <div class="card-body d-flex align-items-center">
                    <div class="stat-icon me-3"><i class="fas fa-chart-line"></i></div>
                    <div>
                        <h6 class="text-muted mb-0 small">GWA</h6>
                        <h4 class="mb-0 fw-bold">1.75</h4>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-lg-4">
            <section class="card student-profile-card h-100" id="my-profile">
                <div class="card-body">
                    <div class="student-avatar mb-3">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <h5 class="fw-semibold mb-1"><?= htmlspecialchars(getCurrentUserName()) ?></h5>
                    <p class="text-muted mb-3">Bachelor of Science in Information Technology</p>
                    <div class="student-detail-list">
                        <div><span>Student ID</span><strong><?= htmlspecialchars($studentId) ?></strong></div>
                        <div><span>Year Level</span><strong>2nd Year</strong></div>
                        <div><span>Section</span><strong>BSIT 2A</strong></div>
                        <div><span>Status</span><strong class="text-success">Enrolled</strong></div>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-lg-8">
            <section class="card h-100" id="class-schedule">
                <div class="card-body">
                    <h5 class="card-title fw-semibold mb-3">
                        <i class="fas fa-calendar-alt text-sms-primary me-2"></i>Class Schedule
                    </h5>
                    <div class="table-responsive">
                        <table class="table student-table align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>Subject</th>
                                    <th>Day</th>
                                    <th>Time</th>
                                    <th>Room</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td>Web Systems and Technologies</td><td>Mon / Wed</td><td>8:00 AM - 9:30 AM</td><td>Lab 204</td></tr>
                                <tr><td>Database Management</td><td>Tue / Thu</td><td>10:00 AM - 11:30 AM</td><td>Room 302</td></tr>
                                <tr><td>Systems Analysis and Design</td><td>Friday</td><td>1:00 PM - 4:00 PM</td><td>Room 210</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-lg-6">
            <section class="card h-100" id="academic-records">
                <div class="card-body">
                    <h5 class="card-title fw-semibold mb-3">
                        <i class="fas fa-file-alt text-sms-primary me-2"></i>Academic Records
                    </h5>
                    <div class="student-record-grid">
                        <div><span>Current Semester</span><strong>1st Semester</strong></div>
                        <div><span>Completed Units</span><strong>54</strong></div>
                        <div><span>Current Units</span><strong>18</strong></div>
                        <div><span>Academic Standing</span><strong>Good Standing</strong></div>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-lg-6">
            <section class="card h-100" id="subjects-professors">
                <div class="card-body">
                    <h5 class="card-title fw-semibold mb-3">
                        <i class="fas fa-chalkboard-teacher text-sms-primary me-2"></i>Subject & Professors
                    </h5>
                    <div class="student-list">
                        <div><strong>Web Systems and Technologies</strong><span>Prof. Maria Santos</span></div>
                        <div><strong>Database Management</strong><span>Prof. Carlo Reyes</span></div>
                        <div><strong>Systems Analysis and Design</strong><span>Prof. Ana Lim</span></div>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-12">
            <section class="card" id="payment-history">
                <div class="card-body">
                    <h5 class="card-title fw-semibold mb-3">
                        <i class="fas fa-receipt text-sms-primary me-2"></i>Payment History
                    </h5>
                    <div class="table-responsive">
                        <table class="table student-table align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Reference No.</th>
                                    <th>Description</th>
                                    <th class="text-end">Amount</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td>Jul 5, 2026</td><td>OR-2026-0018</td><td>Tuition Down Payment</td><td class="text-end">PHP 5,000.00</td><td><span class="badge text-bg-success">Paid</span></td></tr>
                                <tr><td>Jun 20, 2026</td><td>OR-2026-0009</td><td>Registration Fee</td><td class="text-end">PHP 1,500.00</td><td><span class="badge text-bg-success">Paid</span></td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

<?php
require_once __DIR__ . '/../includes/layout-end.php';
return;
endif;
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="page-header">
    <h1>Dashboard</h1>
    <p>Welcome back, <?= htmlspecialchars(getCurrentUserName()) ?>! Here's an overview of your system.</p>
</div>

<!-- Stats Row -->
<div class="row g-3 mb-4 dashboard-stats">
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card stat-card primary">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon me-3"><i class="fas fa-user-graduate"></i></div>
                <div>
                    <h6 class="text-muted mb-0 small">Total Students</h6>
                    <h4 class="mb-0 fw-bold">—</h4>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card stat-card success">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon me-3"><i class="fas fa-chalkboard-teacher"></i></div>
                <div>
                    <h6 class="text-muted mb-0 small">Faculty Members</h6>
                    <h4 class="mb-0 fw-bold">—</h4>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card stat-card warning">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon me-3"><i class="fas fa-file-alt"></i></div>
                <div>
                    <h6 class="text-muted mb-0 small">Pending Enrollments</h6>
                    <h4 class="mb-0 fw-bold">—</h4>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card stat-card info">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon me-3"><i class="fas fa-credit-card"></i></div>
                <div>
                    <h6 class="text-muted mb-0 small">Collections Today</h6>
                    <h4 class="mb-0 fw-bold">—</h4>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Access Modules -->
<div class="card mb-4">
    <div class="card-body">
        <h5 class="card-title fw-semibold mb-3">
            <i class="fas fa-th-large text-sms-primary me-2"></i>System Modules
        </h5>
        <div class="row g-3 module-grid">
            <?php foreach ($visibleModules as $moduleKey => $module): ?>
                <div class="col-6 col-md-4 col-lg-4 col-xl-3 col-xxl-2">
                    <a href="<?= BASE_URL ?>/modules/<?= $moduleKey ?>/index.php" class="quick-module">
                        <div class="card h-100">
                            <div class="card-body">
                                <i class="fas <?= htmlspecialchars($module['icon']) ?>"></i>
                                <p class="small mb-0 fw-medium"><?= htmlspecialchars($module['label']) ?></p>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- Recent Activity Placeholder -->
<div class="row g-3">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3">
                    <i class="fas fa-clock text-sms-primary me-2"></i>Recent Activity
                </h5>
                <div class="text-center text-muted py-4">
                    <i class="fas fa-inbox fa-2x mb-2 d-block opacity-50"></i>
                    <p class="mb-0">Activity feed will appear here once modules are integrated.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3">
                    <i class="fas fa-bell text-sms-primary me-2"></i>Announcements
                </h5>
                <div class="text-center text-muted py-4">
                    <i class="fas fa-bullhorn fa-2x mb-2 d-block opacity-50"></i>
                    <p class="mb-0">No announcements at this time.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/layout-end.php'; ?>
