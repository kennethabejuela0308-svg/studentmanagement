<?php
/**
 * SMS 2 - Dashboard
 */
$pageTitle    = 'Dashboard';
$activeModule = 'dashboard';
$breadcrumbs  = [];

require_once __DIR__ . '/../includes/breadcrumbs.php';
require_once __DIR__ . '/../includes/layout-start.php';

$visibleModules = getVisibleModules($MODULES);
$isStudentPortal = getCurrentUserRoleKey() === 'student';

if ($isStudentPortal):
    $studentId = $_SESSION['student_id'] ?? 'S230000001';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="student-portal">
    <div class="page-header student-portal-header">
        <div>
            <span class="student-kicker">Student Portal</span>
            <h1>Welcome back, <?= htmlspecialchars(getCurrentUserName()) ?></h1>
            <p>Profile, student ID, schedule, records, subjects, professors, and payments.</p>
        </div>
        <div class="student-term-badge">
            <i class="fas fa-calendar-check"></i>
            <span>SY 2026-2027</span>
        </div>
    </div>

    <div class="row g-3 mb-4 dashboard-stats">
        <div class="col-12 col-sm-6 col-xl-3">
            <section class="card stat-card primary" id="student-id">
                <div class="card-body d-flex align-items-center">
                    <div class="stat-icon me-3"><i class="fas fa-id-card"></i></div>
                    <div>
                        <h6 class="text-muted mb-0 small">Student ID</h6>
                        <h4 class="mb-0 fw-bold"><?= htmlspecialchars($studentId) ?></h4>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-12 col-sm-6 col-xl-3">
            <section class="card stat-card warning" id="account-balance">
                <div class="card-body d-flex align-items-center">
                    <div class="stat-icon me-3"><i class="fas fa-wallet"></i></div>
                    <div>
                        <h6 class="text-muted mb-0 small">Account Balance</h6>
                        <h4 class="mb-0 fw-bold">PHP 8,450.00</h4>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-12 col-sm-6 col-xl-3">
            <section class="card stat-card success">
                <div class="card-body d-flex align-items-center">
                    <div class="stat-icon me-3"><i class="fas fa-book-open"></i></div>
                    <div>
                        <h6 class="text-muted mb-0 small">Enrolled Subjects</h6>
                        <h4 class="mb-0 fw-bold">6</h4>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-12 col-sm-6 col-xl-3">
            <section class="card stat-card info">
                <div class="card-body d-flex align-items-center">
                    <div class="stat-icon me-3"><i class="fas fa-chart-line"></i></div>
                    <div>
                        <h6 class="text-muted mb-0 small">GWA</h6>
                        <h4 class="mb-0 fw-bold">1.75</h4>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-lg-4">
            <section class="card student-profile-card h-100" id="my-profile">
                <div class="card-body">
                    <div class="student-avatar mb-3">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <h5 class="fw-semibold mb-1"><?= htmlspecialchars(getCurrentUserName()) ?></h5>
                    <p class="text-muted mb-3">Bachelor of Science in Information Technology</p>
                    <div class="student-detail-list">
                        <div><span>Student ID</span><strong><?= htmlspecialchars($studentId) ?></strong></div>
                        <div><span>Year Level</span><strong>2nd Year</strong></div>
                        <div><span>Section</span><strong>BSIT 2A</strong></div>
                        <div><span>Status</span><strong class="text-success">Enrolled</strong></div>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-lg-8">
            <section class="card h-100" id="class-schedule">
                <div class="card-body">
                    <h5 class="card-title fw-semibold mb-3">
                        <i class="fas fa-calendar-alt text-sms-primary me-2"></i>Class Schedule
                    </h5>
                    <div class="table-responsive">
                        <table class="table student-table align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>Subject</th>
                                    <th>Day</th>
                                    <th>Time</th>
                                    <th>Room</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td>Web Systems and Technologies</td><td>Mon / Wed</td><td>8:00 AM - 9:30 AM</td><td>Lab 204</td></tr>
                                <tr><td>Database Management</td><td>Tue / Thu</td><td>10:00 AM - 11:30 AM</td><td>Room 302</td></tr>
                                <tr><td>Systems Analysis and Design</td><td>Friday</td><td>1:00 PM - 4:00 PM</td><td>Room 210</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-lg-6">
            <section class="card h-100" id="academic-records">
                <div class="card-body">
                    <h5 class="card-title fw-semibold mb-3">
                        <i class="fas fa-file-alt text-sms-primary me-2"></i>Academic Records
                    </h5>
                    <div class="student-record-grid">
                        <div><span>Current Semester</span><strong>1st Semester</strong></div>
                        <div><span>Completed Units</span><strong>54</strong></div>
                        <div><span>Current Units</span><strong>18</strong></div>
                        <div><span>Academic Standing</span><strong>Good Standing</strong></div>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-lg-6">
            <section class="card h-100" id="subjects-professors">
                <div class="card-body">
                    <h5 class="card-title fw-semibold mb-3">
                        <i class="fas fa-chalkboard-teacher text-sms-primary me-2"></i>Subject & Professors
                    </h5>
                    <div class="student-list">
                        <div><strong>Web Systems and Technologies</strong><span>Prof. Maria Santos</span></div>
                        <div><strong>Database Management</strong><span>Prof. Carlo Reyes</span></div>
                        <div><strong>Systems Analysis and Design</strong><span>Prof. Ana Lim</span></div>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-12">
            <section class="card" id="payment-history">
                <div class="card-body">
                    <h5 class="card-title fw-semibold mb-3">
                        <i class="fas fa-receipt text-sms-primary me-2"></i>Payment History
                    </h5>
                    <div class="table-responsive">
                        <table class="table student-table align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Reference No.</th>
                                    <th>Description</th>
                                    <th class="text-end">Amount</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td>Jul 5, 2026</td><td>OR-2026-0018</td><td>Tuition Down Payment</td><td class="text-end">PHP 5,000.00</td><td><span class="badge text-bg-success">Paid</span></td></tr>
                                <tr><td>Jun 20, 2026</td><td>OR-2026-0009</td><td>Registration Fee</td><td class="text-end">PHP 1,500.00</td><td><span class="badge text-bg-success">Paid</span></td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

<?php
require_once __DIR__ . '/../includes/layout-end.php';
return;
endif;
?>


<?php renderBreadcrumbs($breadcrumbs); ?>

<?php
/* ── Role-aware performance metrics ───────────────────── */
$roleKey   = getCurrentUserRoleKey();
$statCards = [];

if ($roleKey === 'admin') {
    $statCards = [
        ['icon'=>'fa-user-graduate',      'label'=>'Total Students',      'value'=>'2,893',   'type'=>'primary', 'delta'=>'+4.2%',  'deltaDir'=>'up',   'deltaLabel'=>'vs last month'],
        ['icon'=>'fa-chalkboard-teacher', 'label'=>'Faculty Members',     'value'=>'102',     'type'=>'success', 'delta'=>'+2.0%',  'deltaDir'=>'up',   'deltaLabel'=>'vs last month'],
        ['icon'=>'fa-file-alt',           'label'=>'Pending Enrollments', 'value'=>'47',      'type'=>'warning', 'delta'=>'-8.1%',  'deltaDir'=>'down', 'deltaLabel'=>'vs last week'],
        ['icon'=>'fa-credit-card',        'label'=>'Collections Today',   'value'=>'₱38,500', 'type'=>'info',    'delta'=>'+12.5%', 'deltaDir'=>'up',   'deltaLabel'=>'vs yesterday'],
    ];
} elseif ($roleKey === 'registrar') {
    $statCards = [
        ['icon'=>'fa-user-graduate', 'label'=>'Total Students',      'value'=>'2,893', 'type'=>'primary', 'delta'=>'+3.8%', 'deltaDir'=>'up',   'deltaLabel'=>'vs last month'],
        ['icon'=>'fa-file-alt',      'label'=>'Pending Enrollments', 'value'=>'47',    'type'=>'warning', 'delta'=>'-5.4%', 'deltaDir'=>'down', 'deltaLabel'=>'vs last week'],
        ['icon'=>'fa-folder-open',   'label'=>'Document Requests',   'value'=>'28',    'type'=>'info',    'delta'=>'+9.2%', 'deltaDir'=>'up',   'deltaLabel'=>'vs last week'],
        ['icon'=>'fa-check-circle',  'label'=>'Enrolled This Term',  'value'=>'1,204', 'type'=>'success', 'delta'=>'+6.1%', 'deltaDir'=>'up',   'deltaLabel'=>'vs last term'],
    ];
} elseif ($roleKey === 'finance') {
    $statCards = [
        ['icon'=>'fa-peso-sign',           'label'=>'Collections Today',       'value'=>'₱38,500', 'type'=>'success', 'delta'=>'+12.5%', 'deltaDir'=>'up',   'deltaLabel'=>'vs yesterday'],
        ['icon'=>'fa-file-invoice-dollar', 'label'=>'Pending Payments',        'value'=>'134',     'type'=>'warning', 'delta'=>'-3.2%',  'deltaDir'=>'down', 'deltaLabel'=>'vs last week'],
        ['icon'=>'fa-wallet',              'label'=>'Total Collected (Month)', 'value'=>'₱1.2M',   'type'=>'primary', 'delta'=>'+8.4%',  'deltaDir'=>'up',   'deltaLabel'=>'vs last month'],
        ['icon'=>'fa-times-circle',        'label'=>'Overdue Accounts',        'value'=>'23',      'type'=>'info',    'delta'=>'-1.5%',  'deltaDir'=>'down', 'deltaLabel'=>'vs last week'],
    ];
} elseif ($roleKey === 'hr') {
    $statCards = [
        ['icon'=>'fa-chalkboard-teacher', 'label'=>'Total Faculty',          'value'=>'102', 'type'=>'primary', 'delta'=>'+1.0%', 'deltaDir'=>'up',   'deltaLabel'=>'vs last month'],
        ['icon'=>'fa-calendar-times',     'label'=>'On Leave Today',         'value'=>'5',   'type'=>'warning', 'delta'=>'+2',    'deltaDir'=>'up',   'deltaLabel'=>'vs yesterday'],
        ['icon'=>'fa-star',               'label'=>'Avg Evaluation Score',   'value'=>'4.2', 'type'=>'success', 'delta'=>'+0.1',  'deltaDir'=>'up',   'deltaLabel'=>'vs last term'],
        ['icon'=>'fa-clock',              'label'=>'Pending Leave Requests', 'value'=>'8',   'type'=>'info',    'delta'=>'-3',    'deltaDir'=>'down', 'deltaLabel'=>'vs last week'],
    ];
} elseif ($roleKey === 'it_office') {
    $statCards = [
        ['icon'=>'fa-laptop',     'label'=>'Active Classes (LMS)',  'value'=>'148',   'type'=>'primary', 'delta'=>'+5.6%', 'deltaDir'=>'up',   'deltaLabel'=>'vs last week'],
        ['icon'=>'fa-users',      'label'=>'Active LMS Users',      'value'=>'2,104', 'type'=>'success', 'delta'=>'+7.3%', 'deltaDir'=>'up',   'deltaLabel'=>'vs last month'],
        ['icon'=>'fa-tasks',      'label'=>'Pending Submissions',   'value'=>'312',   'type'=>'warning', 'delta'=>'-4.1%', 'deltaDir'=>'down', 'deltaLabel'=>'vs last week'],
        ['icon'=>'fa-chart-line', 'label'=>'Avg Module Completion', 'value'=>'68%',   'type'=>'info',    'delta'=>'+2.4%', 'deltaDir'=>'up',   'deltaLabel'=>'vs last month'],
    ];
} elseif ($roleKey === 'osa') {
    $statCards = [
        ['icon'=>'fa-users',            'label'=>'Registered Clubs',  'value'=>'24',  'type'=>'primary', 'delta'=>'+1',    'deltaDir'=>'up',   'deltaLabel'=>'new this month'],
        ['icon'=>'fa-calendar-check',   'label'=>'Events This Month', 'value'=>'9',   'type'=>'success', 'delta'=>'+3',    'deltaDir'=>'up',   'deltaLabel'=>'vs last month'],
        ['icon'=>'fa-user-check',       'label'=>'Active Members',    'value'=>'876', 'type'=>'info',    'delta'=>'+4.8%', 'deltaDir'=>'up',   'deltaLabel'=>'vs last month'],
        ['icon'=>'fa-hand-holding-usd', 'label'=>'Budget Requests',   'value'=>'6',   'type'=>'warning', 'delta'=>'-2',    'deltaDir'=>'down', 'deltaLabel'=>'vs last week'],
    ];
} elseif ($roleKey === 'qa') {
    $statCards = [
        ['icon'=>'fa-award',              'label'=>'Accredited Programs', 'value'=>'8',        'type'=>'success', 'delta'=>'+1',    'deltaDir'=>'up',   'deltaLabel'=>'this year'],
        ['icon'=>'fa-clipboard-list',     'label'=>'Compliance Items',    'value'=>'142',      'type'=>'primary', 'delta'=>'+6.2%', 'deltaDir'=>'up',   'deltaLabel'=>'vs last audit'],
        ['icon'=>'fa-exclamation-circle', 'label'=>'Non-Conformities',    'value'=>'7',        'type'=>'warning', 'delta'=>'-2',    'deltaDir'=>'down', 'deltaLabel'=>'vs last review'],
        ['icon'=>'fa-calendar-alt',       'label'=>'Next Visit',          'value'=>'Sep 2026', 'type'=>'info',    'delta'=>'On track', 'deltaDir'=>'neutral', 'deltaLabel'=>'schedule'],
    ];
} else {
    $statCards = [
        ['icon'=>'fa-flask',            'label'=>'Active Research Projects', 'value'=>'18', 'type'=>'primary', 'delta'=>'+3',    'deltaDir'=>'up',   'deltaLabel'=>'vs last quarter'],
        ['icon'=>'fa-file-upload',      'label'=>'Submitted Proposals',      'value'=>'12', 'type'=>'info',    'delta'=>'+4',    'deltaDir'=>'up',   'deltaLabel'=>'this month'],
        ['icon'=>'fa-book-open',        'label'=>'Publications This Year',   'value'=>'9',  'type'=>'success', 'delta'=>'+2',    'deltaDir'=>'up',   'deltaLabel'=>'vs last year'],
        ['icon'=>'fa-hand-holding-usd', 'label'=>'Active Grants',            'value'=>'4',  'type'=>'warning', 'delta'=>'Stable', 'deltaDir'=>'neutral', 'deltaLabel'=>'current'],
    ];
}

require_once __DIR__ . '/glass-board.php';
?>

<script src="<?= BASE_URL ?>/assets/js/dashboard-glass.js"></script>

<?php require_once __DIR__ . '/../includes/layout-end.php'; ?>