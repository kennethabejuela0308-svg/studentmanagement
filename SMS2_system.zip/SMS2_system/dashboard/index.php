<?php
/**
 * SMS 2 - Dashboard
 */
$pageTitle    = 'Dashboard';
$activeModule = 'dashboard';
$breadcrumbs  = [];

require_once __DIR__ . '/../includes/breadcrumbs.php';
require_once __DIR__ . '/../includes/layout-start.php';

$visibleModules = getVisibleModules($MODULES);
$isStudentPortal = getCurrentUserRoleKey() === 'student';

if ($isStudentPortal):
    $studentId = $_SESSION['student_id'] ?? 'S230000001';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="student-portal">
    <div class="page-header student-portal-header">
        <div>
            <span class="student-kicker">Student Portal</span>
            <h1>Welcome back, <?= htmlspecialchars(getCurrentUserName()) ?></h1>
            <p>Profile, student ID, schedule, records, subjects, professors, and payments.</p>
        </div>
        <div class="student-term-badge">
            <i class="fas fa-calendar-check"></i>
            <span>SY 2026-2027</span>
        </div>
    </div>

    <div class="row g-3 mb-4 dashboard-stats">
        <div class="col-12 col-sm-6 col-xl-3">
            <section class="card stat-card primary" id="student-id">
                <div class="card-body d-flex align-items-center">
                    <div class="stat-icon me-3"><i class="fas fa-id-card"></i></div>
                    <div>
                        <h6 class="text-muted mb-0 small">Student ID</h6>
                        <h4 class="mb-0 fw-bold"><?= htmlspecialchars($studentId) ?></h4>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-12 col-sm-6 col-xl-3">
            <section class="card stat-card warning" id="account-balance">
                <div class="card-body d-flex align-items-center">
                    <div class="stat-icon me-3"><i class="fas fa-wallet"></i></div>
                    <div>
                        <h6 class="text-muted mb-0 small">Account Balance</h6>
                        <h4 class="mb-0 fw-bold">PHP 8,450.00</h4>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-12 col-sm-6 col-xl-3">
            <section class="card stat-card success">
                <div class="card-body d-flex align-items-center">
                    <div class="stat-icon me-3"><i class="fas fa-book-open"></i></div>
                    <div>
                        <h6 class="text-muted mb-0 small">Enrolled Subjects</h6>
                        <h4 class="mb-0 fw-bold">6</h4>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-12 col-sm-6 col-xl-3">
            <section class="card stat-card info">
                <div class="card-body d-flex align-items-center">
                    <div class="stat-icon me-3"><i class="fas fa-chart-line"></i></div>
                    <div>
                        <h6 class="text-muted mb-0 small">GWA</h6>
                        <h4 class="mb-0 fw-bold">1.75</h4>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-lg-4">
            <section class="card student-profile-card h-100" id="my-profile">
                <div class="card-body">
                    <div class="student-avatar mb-3">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <h5 class="fw-semibold mb-1"><?= htmlspecialchars(getCurrentUserName()) ?></h5>
                    <p class="text-muted mb-3">Bachelor of Science in Information Technology</p>
                    <div class="student-detail-list">
                        <div><span>Student ID</span><strong><?= htmlspecialchars($studentId) ?></strong></div>
                        <div><span>Year Level</span><strong>2nd Year</strong></div>
                        <div><span>Section</span><strong>BSIT 2A</strong></div>
                        <div><span>Status</span><strong class="text-success">Enrolled</strong></div>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-lg-8">
            <section class="card h-100" id="class-schedule">
                <div class="card-body">
                    <h5 class="card-title fw-semibold mb-3">
                        <i class="fas fa-calendar-alt text-sms-primary me-2"></i>Class Schedule
                    </h5>
                    <div class="table-responsive">
                        <table class="table student-table align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>Subject</th>
                                    <th>Day</th>
                                    <th>Time</th>
                                    <th>Room</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td>Web Systems and Technologies</td><td>Mon / Wed</td><td>8:00 AM - 9:30 AM</td><td>Lab 204</td></tr>
                                <tr><td>Database Management</td><td>Tue / Thu</td><td>10:00 AM - 11:30 AM</td><td>Room 302</td></tr>
                                <tr><td>Systems Analysis and Design</td><td>Friday</td><td>1:00 PM - 4:00 PM</td><td>Room 210</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-lg-6">
            <section class="card h-100" id="academic-records">
                <div class="card-body">
                    <h5 class="card-title fw-semibold mb-3">
                        <i class="fas fa-file-alt text-sms-primary me-2"></i>Academic Records
                    </h5>
                    <div class="student-record-grid">
                        <div><span>Current Semester</span><strong>1st Semester</strong></div>
                        <div><span>Completed Units</span><strong>54</strong></div>
                        <div><span>Current Units</span><strong>18</strong></div>
                        <div><span>Academic Standing</span><strong>Good Standing</strong></div>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-lg-6">
            <section class="card h-100" id="subjects-professors">
                <div class="card-body">
                    <h5 class="card-title fw-semibold mb-3">
                        <i class="fas fa-chalkboard-teacher text-sms-primary me-2"></i>Subject & Professors
                    </h5>
                    <div class="student-list">
                        <div><strong>Web Systems and Technologies</strong><span>Prof. Maria Santos</span></div>
                        <div><strong>Database Management</strong><span>Prof. Carlo Reyes</span></div>
                        <div><strong>Systems Analysis and Design</strong><span>Prof. Ana Lim</span></div>
                    </div>
                </div>
            </section>
        </div>
        <div class="col-12">
            <section class="card" id="payment-history">
                <div class="card-body">
                    <h5 class="card-title fw-semibold mb-3">
                        <i class="fas fa-receipt text-sms-primary me-2"></i>Payment History
                    </h5>
                    <div class="table-responsive">
                        <table class="table student-table align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Reference No.</th>
                                    <th>Description</th>
                                    <th class="text-end">Amount</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td>Jul 5, 2026</td><td>OR-2026-0018</td><td>Tuition Down Payment</td><td class="text-end">PHP 5,000.00</td><td><span class="badge text-bg-success">Paid</span></td></tr>
                                <tr><td>Jun 20, 2026</td><td>OR-2026-0009</td><td>Registration Fee</td><td class="text-end">PHP 1,500.00</td><td><span class="badge text-bg-success">Paid</span></td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

<?php
require_once __DIR__ . '/../includes/layout-end.php';
return;
endif;
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="page-header">
    <h1>Dashboard</h1>
    <p>Welcome back, <?= htmlspecialchars(getCurrentUserName()) ?>! Here's an overview of your system.</p>
</div>

<?php
/* ── Stat cards & charts — role-aware ───────────────────── */
$roleKey   = getCurrentUserRoleKey();
$statCards = [];

if ($roleKey === 'admin') {
    $statCards = [
        ['icon'=>'fa-user-graduate',        'label'=>'Total Students',       'value'=>'2,893',   'type'=>'primary'],
        ['icon'=>'fa-chalkboard-teacher',   'label'=>'Faculty Members',      'value'=>'102',     'type'=>'success'],
        ['icon'=>'fa-file-alt',             'label'=>'Pending Enrollments',  'value'=>'47',      'type'=>'warning'],
        ['icon'=>'fa-credit-card',          'label'=>'Collections Today',    'value'=>'₱38,500', 'type'=>'info'],
    ];
} elseif ($roleKey === 'registrar') {
    $statCards = [
        ['icon'=>'fa-user-graduate',  'label'=>'Total Students',      'value'=>'2,893',  'type'=>'primary'],
        ['icon'=>'fa-file-alt',       'label'=>'Pending Enrollments', 'value'=>'47',     'type'=>'warning'],
        ['icon'=>'fa-folder-open',    'label'=>'Document Requests',   'value'=>'28',     'type'=>'info'],
        ['icon'=>'fa-check-circle',   'label'=>'Enrolled This Term',  'value'=>'1,204',  'type'=>'success'],
    ];
} elseif ($roleKey === 'finance') {
    $statCards = [
        ['icon'=>'fa-peso-sign',             'label'=>'Collections Today',       'value'=>'₱38,500', 'type'=>'success'],
        ['icon'=>'fa-file-invoice-dollar',   'label'=>'Pending Payments',        'value'=>'134',     'type'=>'warning'],
        ['icon'=>'fa-wallet',                'label'=>'Total Collected (Month)', 'value'=>'₱1.2M',  'type'=>'primary'],
        ['icon'=>'fa-times-circle',          'label'=>'Overdue Accounts',        'value'=>'23',      'type'=>'info'],
    ];
} elseif ($roleKey === 'hr') {
    $statCards = [
        ['icon'=>'fa-chalkboard-teacher', 'label'=>'Total Faculty',          'value'=>'102', 'type'=>'primary'],
        ['icon'=>'fa-calendar-times',     'label'=>'On Leave Today',         'value'=>'5',   'type'=>'warning'],
        ['icon'=>'fa-star',               'label'=>'Avg Evaluation Score',   'value'=>'4.2', 'type'=>'success'],
        ['icon'=>'fa-clock',              'label'=>'Pending Leave Requests', 'value'=>'8',   'type'=>'info'],
    ];
} elseif ($roleKey === 'it_office') {
    $statCards = [
        ['icon'=>'fa-laptop',      'label'=>'Active Classes (LMS)',      'value'=>'148',   'type'=>'primary'],
        ['icon'=>'fa-users',       'label'=>'Active LMS Users',          'value'=>'2,104', 'type'=>'success'],
        ['icon'=>'fa-tasks',       'label'=>'Pending Submissions',       'value'=>'312',   'type'=>'warning'],
        ['icon'=>'fa-chart-line',  'label'=>'Avg Module Completion',     'value'=>'68%',   'type'=>'info'],
    ];
} elseif ($roleKey === 'osa') {
    $statCards = [
        ['icon'=>'fa-users',              'label'=>'Registered Clubs',    'value'=>'24',  'type'=>'primary'],
        ['icon'=>'fa-calendar-check',     'label'=>'Events This Month',   'value'=>'9',   'type'=>'success'],
        ['icon'=>'fa-user-check',         'label'=>'Active Members',      'value'=>'876', 'type'=>'info'],
        ['icon'=>'fa-hand-holding-usd',   'label'=>'Budget Requests',     'value'=>'6',   'type'=>'warning'],
    ];
} elseif ($roleKey === 'qa') {
    $statCards = [
        ['icon'=>'fa-award',              'label'=>'Accredited Programs', 'value'=>'8',        'type'=>'success'],
        ['icon'=>'fa-clipboard-list',     'label'=>'Compliance Items',    'value'=>'142',      'type'=>'primary'],
        ['icon'=>'fa-exclamation-circle', 'label'=>'Non-Conformities',    'value'=>'7',        'type'=>'warning'],
        ['icon'=>'fa-calendar-alt',       'label'=>'Next Visit',          'value'=>'Sep 2026', 'type'=>'info'],
    ];
} elseif ($roleKey === 'crad_officer') {
    $statCards = [
        ['icon'=>'fa-flask',            'label'=>'Active Research Projects', 'value'=>'18', 'type'=>'primary'],
        ['icon'=>'fa-file-upload',      'label'=>'Submitted Proposals',      'value'=>'12', 'type'=>'info'],
        ['icon'=>'fa-book-open',        'label'=>'Publications This Year',   'value'=>'9',  'type'=>'success'],
        ['icon'=>'fa-hand-holding-usd', 'label'=>'Active Grants',            'value'=>'4',  'type'=>'warning'],
    ];
}
?>

<!-- Stat Cards -->
<div class="row g-3 mb-4 dashboard-stats">
    <?php foreach ($statCards as $card): ?>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card stat-card <?= $card['type'] ?>">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon me-3"><i class="fas <?= $card['icon'] ?>"></i></div>
                <div>
                    <h6 class="text-muted mb-0 small"><?= $card['label'] ?></h6>
                    <h4 class="mb-0 fw-bold"><?= $card['value'] ?></h4>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Quick Access Modules -->
<div class="card mb-4">
    <div class="card-body">
        <h5 class="card-title fw-semibold mb-3">
            <i class="fas fa-th-large text-sms-primary me-2"></i>System Modules
        </h5>
        <div class="row g-3 module-grid">
            <?php foreach ($visibleModules as $moduleKey => $module): ?>
                <div class="col-6 col-md-4 col-lg-4 col-xl-3 col-xxl-2">
                    <a href="<?= BASE_URL ?>/modules/<?= $moduleKey ?>/index.php" class="quick-module">
                        <div class="card h-100">
                            <div class="card-body">
                                <i class="fas <?= htmlspecialchars($module['icon']) ?>"></i>
                                <p class="small mb-0 fw-medium"><?= htmlspecialchars($module['label']) ?></p>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php /* ── Role-Based Charts ── */ ?>

<?php if ($roleKey === 'admin'): ?>
<!-- ADMIN: all-system charts -->
<div class="row g-3 mb-4">
    <div class="col-lg-8">
        <div class="card h-100">
            <div class="card-body">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <h5 class="card-title fw-semibold mb-0"><i class="fas fa-chart-bar text-sms-primary me-2"></i>Monthly Enrollment Trend</h5>
                    <span class="badge bg-primary-subtle text-primary" style="font-size:.72rem">SY 2025–2026</span>
                </div>
                <canvas id="chart1" height="110"></canvas>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-graduation-cap text-sms-primary me-2"></i>Students by Program</h5>
                <canvas id="chart2" height="185"></canvas>
            </div>
        </div>
    </div>
</div>
<div class="row g-3">
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-body">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <h5 class="card-title fw-semibold mb-0"><i class="fas fa-peso-sign text-sms-primary me-2"></i>Monthly Collections</h5>
                    <span class="badge bg-success-subtle text-success" style="font-size:.72rem">₱ thousands</span>
                </div>
                <canvas id="chart3" height="130"></canvas>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-users text-sms-primary me-2"></i>Faculty by Department</h5>
                <canvas id="chart4" height="130"></canvas>
            </div>
        </div>
    </div>
</div>

<?php elseif ($roleKey === 'registrar'): ?>
<!-- REGISTRAR: enrollment, registrar, curriculum, scheduling -->
<div class="row g-3 mb-4">
    <div class="col-lg-8">
        <div class="card h-100">
            <div class="card-body">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <h5 class="card-title fw-semibold mb-0"><i class="fas fa-chart-bar text-sms-primary me-2"></i>Monthly Enrollment Trend</h5>
                    <span class="badge bg-primary-subtle text-primary" style="font-size:.72rem">SY 2025–2026</span>
                </div>
                <canvas id="chart1" height="110"></canvas>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-graduation-cap text-sms-primary me-2"></i>Students by Program</h5>
                <canvas id="chart2" height="185"></canvas>
            </div>
        </div>
    </div>
</div>
<div class="row g-3">
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-folder-open text-sms-primary me-2"></i>Document Requests per Month</h5>
                <canvas id="chart3" height="130"></canvas>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-calendar-alt text-sms-primary me-2"></i>Class Sections per Year Level</h5>
                <canvas id="chart4" height="130"></canvas>
            </div>
        </div>
    </div>
</div>

<?php elseif ($roleKey === 'finance'): ?>
<!-- FINANCE: payment charts -->
<div class="row g-3 mb-4">
    <div class="col-lg-8">
        <div class="card h-100">
            <div class="card-body">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <h5 class="card-title fw-semibold mb-0"><i class="fas fa-peso-sign text-sms-primary me-2"></i>Monthly Collections</h5>
                    <span class="badge bg-success-subtle text-success" style="font-size:.72rem">₱ thousands</span>
                </div>
                <canvas id="chart1" height="110"></canvas>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-chart-pie text-sms-primary me-2"></i>Collection by Fee Type</h5>
                <canvas id="chart2" height="185"></canvas>
            </div>
        </div>
    </div>
</div>
<div class="row g-3">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-exclamation-circle text-sms-primary me-2"></i>Overdue Accounts per Program</h5>
                <canvas id="chart3" height="70"></canvas>
            </div>
        </div>
    </div>
</div>

<?php elseif ($roleKey === 'hr'): ?>
<!-- HR: faculty charts -->
<div class="row g-3 mb-4">
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-users text-sms-primary me-2"></i>Faculty by Department</h5>
                <canvas id="chart1" height="150"></canvas>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-star text-sms-primary me-2"></i>Evaluation Scores by Department</h5>
                <canvas id="chart2" height="150"></canvas>
            </div>
        </div>
    </div>
</div>
<div class="row g-3">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-calendar-times text-sms-primary me-2"></i>Monthly Leave Applications</h5>
                <canvas id="chart3" height="70"></canvas>
            </div>
        </div>
    </div>
</div>

<?php elseif ($roleKey === 'it_office'): ?>
<!-- IT OFFICE / LMS charts -->
<div class="row g-3 mb-4">
    <div class="col-lg-8">
        <div class="card h-100">
            <div class="card-body">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <h5 class="card-title fw-semibold mb-0"><i class="fas fa-laptop text-sms-primary me-2"></i>LMS Activity per Month</h5>
                    <span class="badge bg-primary-subtle text-primary" style="font-size:.72rem">Logins &amp; Submissions</span>
                </div>
                <canvas id="chart1" height="110"></canvas>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-tasks text-sms-primary me-2"></i>Module Completion by Subject</h5>
                <canvas id="chart2" height="185"></canvas>
            </div>
        </div>
    </div>
</div>
<div class="row g-3">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-chart-bar text-sms-primary me-2"></i>Quiz Average Scores per Subject</h5>
                <canvas id="chart3" height="70"></canvas>
            </div>
        </div>
    </div>
</div>

<?php elseif ($roleKey === 'osa'): ?>
<!-- OSA / CO-CURRICULAR charts -->
<div class="row g-3 mb-4">
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-users text-sms-primary me-2"></i>Club Membership Count</h5>
                <canvas id="chart1" height="150"></canvas>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-calendar-check text-sms-primary me-2"></i>Events per Month</h5>
                <canvas id="chart2" height="150"></canvas>
            </div>
        </div>
    </div>
</div>
<div class="row g-3">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-clock text-sms-primary me-2"></i>Volunteer Hours by Club</h5>
                <canvas id="chart3" height="70"></canvas>
            </div>
        </div>
    </div>
</div>

<?php elseif ($roleKey === 'qa'): ?>
<!-- QA / ACCREDITATION charts -->
<div class="row g-3 mb-4">
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-award text-sms-primary me-2"></i>Compliance Rate by Area</h5>
                <canvas id="chart1" height="150"></canvas>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-clipboard-check text-sms-primary me-2"></i>Audit Findings per Program</h5>
                <canvas id="chart2" height="150"></canvas>
            </div>
        </div>
    </div>
</div>
<div class="row g-3">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-tasks text-sms-primary me-2"></i>Action Plan Status</h5>
                <canvas id="chart3" height="70"></canvas>
            </div>
        </div>
    </div>
</div>

<?php elseif ($roleKey === 'crad_officer'): ?>
<!-- CRAD charts -->
<div class="row g-3 mb-4">
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-flask text-sms-primary me-2"></i>Research Projects by Status</h5>
                <canvas id="chart1" height="150"></canvas>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-book-open text-sms-primary me-2"></i>Publications per Year</h5>
                <canvas id="chart2" height="150"></canvas>
            </div>
        </div>
    </div>
</div>
<div class="row g-3">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-3"><i class="fas fa-hand-holding-usd text-sms-primary me-2"></i>Research Proposals by Department</h5>
                <canvas id="chart3" height="70"></canvas>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
(function () {
    var blue = '#1e40af', blue2 = '#3b82f6', blue3 = '#93c5fd';
    var green = '#16a34a', amber = '#d97706', sky = '#0284c7';
    var violet = '#7c3aed', rose = '#e11d48', teal = '#0d9488';
    var months = ['Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar','Apr','May'];
    var gc = 'rgba(0,0,0,0.05)';
    Chart.defaults.font.family = "'Inter',sans-serif";
    Chart.defaults.font.size = 12;
    Chart.defaults.color = '#64748b';

    var role = '<?= $roleKey ?>';

    if (role === 'admin') {
        /* 1. Enrollment trend bar+line */
        new Chart(document.getElementById('chart1'), { data: { labels: months, datasets: [
            { type:'bar', label:'New Enrollees', data:[142,389,521,478,203,88,45,312,267,198,154,96], backgroundColor:blue2, borderRadius:5, borderSkipped:false, order:2 },
            { type:'line', label:'Cumulative', data:[142,531,1052,1530,1733,1821,1866,2178,2445,2643,2797,2893], borderColor:amber, backgroundColor:'transparent', borderWidth:2, pointRadius:3, pointBackgroundColor:amber, tension:0.35, yAxisID:'y2', order:1 }
        ]}, options:{ responsive:true, interaction:{mode:'index',intersect:false}, plugins:{legend:{position:'top',align:'end',labels:{boxWidth:10,padding:12}}}, scales:{ x:{grid:{display:false}}, y:{title:{display:true,text:'New Enrollees'},grid:{color:gc},beginAtZero:true}, y2:{position:'right',title:{display:true,text:'Cumulative'},grid:{display:false},beginAtZero:true} } }});
        /* 2. Students by program horizontal */
        new Chart(document.getElementById('chart2'), { type:'bar', data:{ labels:['BSIT','BSEd','BSBA','BSCrim','BSN','BSCS'], datasets:[{ label:'Students', data:[612,487,543,328,415,381], backgroundColor:[blue,green,amber,sky,violet,rose], borderRadius:5, borderSkipped:false }]}, options:{ indexAxis:'y', responsive:true, plugins:{legend:{display:false}}, scales:{x:{grid:{color:gc},beginAtZero:true},y:{grid:{display:false}}} }});
        /* 3. Monthly collections stacked */
        new Chart(document.getElementById('chart3'), { type:'bar', data:{ labels:months, datasets:[
            { label:'Tuition', data:[320,890,1240,980,450,180,95,760,640,480,360,210], backgroundColor:blue, borderRadius:4, borderSkipped:false, stack:'s' },
            { label:'Miscellaneous', data:[45,120,165,130,60,25,15,95,80,60,45,28], backgroundColor:blue3, borderRadius:4, borderSkipped:false, stack:'s' }
        ]}, options:{ responsive:true, interaction:{mode:'index',intersect:false}, plugins:{legend:{position:'top',align:'end',labels:{boxWidth:10,padding:12}}}, scales:{ x:{stacked:true,grid:{display:false}}, y:{stacked:true,grid:{color:gc},beginAtZero:true,ticks:{callback:function(v){return '₱'+v+'K';}}} } }});
        /* 4. Faculty by dept */
        new Chart(document.getElementById('chart4'), { type:'bar', data:{ labels:['CITE','CTE','CBA','CCJ','CN','Gen Ed'], datasets:[{ label:'Faculty', data:[18,22,20,14,16,12], backgroundColor:[blue,green,amber,sky,violet,rose], borderRadius:5, borderSkipped:false }]}, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{x:{grid:{display:false}},y:{grid:{color:gc},beginAtZero:true,ticks:{stepSize:5}}} }});

    } else if (role === 'registrar') {
        /* 1. Enrollment trend */
        new Chart(document.getElementById('chart1'), { data:{ labels:months, datasets:[
            { type:'bar', label:'New Enrollees', data:[142,389,521,478,203,88,45,312,267,198,154,96], backgroundColor:blue2, borderRadius:5, borderSkipped:false, order:2 },
            { type:'line', label:'Cumulative', data:[142,531,1052,1530,1733,1821,1866,2178,2445,2643,2797,2893], borderColor:amber, backgroundColor:'transparent', borderWidth:2, pointRadius:3, pointBackgroundColor:amber, tension:0.35, yAxisID:'y2', order:1 }
        ]}, options:{ responsive:true, interaction:{mode:'index',intersect:false}, plugins:{legend:{position:'top',align:'end',labels:{boxWidth:10,padding:12}}}, scales:{ x:{grid:{display:false}}, y:{title:{display:true,text:'New Enrollees'},grid:{color:gc},beginAtZero:true}, y2:{position:'right',title:{display:true,text:'Cumulative'},grid:{display:false},beginAtZero:true} } }});
        /* 2. Students by program */
        new Chart(document.getElementById('chart2'), { type:'bar', data:{ labels:['BSIT','BSEd','BSBA','BSCrim','BSN','BSCS'], datasets:[{ label:'Students', data:[612,487,543,328,415,381], backgroundColor:[blue,green,amber,sky,violet,rose], borderRadius:5, borderSkipped:false }]}, options:{ indexAxis:'y', responsive:true, plugins:{legend:{display:false}}, scales:{x:{grid:{color:gc},beginAtZero:true},y:{grid:{display:false}}} }});
        /* 3. Document requests */
        new Chart(document.getElementById('chart3'), { type:'bar', data:{ labels:months, datasets:[{ label:'Requests', data:[12,18,24,21,15,8,5,19,16,13,11,9], backgroundColor:sky, borderRadius:5, borderSkipped:false }]}, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{x:{grid:{display:false}},y:{grid:{color:gc},beginAtZero:true}} }});
        /* 4. Sections per year level */
        new Chart(document.getElementById('chart4'), { type:'bar', data:{ labels:['1st Year','2nd Year','3rd Year','4th Year'], datasets:[{ label:'Sections', data:[18,16,14,12], backgroundColor:[blue,blue2,blue3,'#bfdbfe'], borderRadius:5, borderSkipped:false }]}, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{x:{grid:{display:false}},y:{grid:{color:gc},beginAtZero:true,ticks:{stepSize:4}}} }});

    } else if (role === 'finance') {
        /* 1. Monthly collections stacked */
        new Chart(document.getElementById('chart1'), { type:'bar', data:{ labels:months, datasets:[
            { label:'Tuition', data:[320,890,1240,980,450,180,95,760,640,480,360,210], backgroundColor:blue, borderRadius:4, borderSkipped:false, stack:'s' },
            { label:'Miscellaneous', data:[45,120,165,130,60,25,15,95,80,60,45,28], backgroundColor:blue3, borderRadius:4, borderSkipped:false, stack:'s' }
        ]}, options:{ responsive:true, interaction:{mode:'index',intersect:false}, plugins:{legend:{position:'top',align:'end',labels:{boxWidth:10,padding:12}}}, scales:{ x:{stacked:true,grid:{display:false}}, y:{stacked:true,grid:{color:gc},beginAtZero:true,ticks:{callback:function(v){return '₱'+v+'K';}}} } }});
        /* 2. Collection by fee type doughnut */
        new Chart(document.getElementById('chart2'), { type:'doughnut', data:{ labels:['Tuition','Misc','Lab','Registration','Others'], datasets:[{ data:[68,12,8,7,5], backgroundColor:[blue,blue2,blue3,sky,green], borderWidth:2, borderColor:'#fff' }]}, options:{ responsive:true, plugins:{ legend:{position:'bottom',labels:{boxWidth:10,padding:10,font:{size:11}}}, tooltip:{callbacks:{label:function(ctx){return ' '+ctx.label+': '+ctx.parsed+'%';}}}}  }});
        /* 3. Overdue by program */
        new Chart(document.getElementById('chart3'), { type:'bar', data:{ labels:['BSIT','BSEd','BSBA','BSCrim','BSN','BSCS'], datasets:[{ label:'Overdue Accounts', data:[8,5,6,3,4,4], backgroundColor:rose, borderRadius:5, borderSkipped:false }]}, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{x:{grid:{display:false}},y:{grid:{color:gc},beginAtZero:true,ticks:{stepSize:2}}} }});

    } else if (role === 'hr') {
        /* 1. Faculty by dept */
        new Chart(document.getElementById('chart1'), { type:'bar', data:{ labels:['CITE','CTE','CBA','CCJ','CN','Gen Ed'], datasets:[{ label:'Faculty', data:[18,22,20,14,16,12], backgroundColor:[blue,green,amber,sky,violet,rose], borderRadius:5, borderSkipped:false }]}, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{x:{grid:{display:false}},y:{grid:{color:gc},beginAtZero:true,ticks:{stepSize:5}}} }});
        /* 2. Evaluation scores */
        new Chart(document.getElementById('chart2'), { type:'bar', data:{ labels:['CITE','CTE','CBA','CCJ','CN','Gen Ed'], datasets:[{ label:'Avg Score', data:[4.3,4.1,4.2,4.0,4.4,3.9], backgroundColor:green, borderRadius:5, borderSkipped:false }]}, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{x:{grid:{display:false}},y:{min:3.5,max:5,grid:{color:gc}}} }});
        /* 3. Leave applications */
        new Chart(document.getElementById('chart3'), { type:'bar', data:{ labels:months, datasets:[{ label:'Leave Applications', data:[3,5,8,6,4,2,1,5,4,3,3,2], backgroundColor:amber, borderRadius:5, borderSkipped:false }]}, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{x:{grid:{display:false}},y:{grid:{color:gc},beginAtZero:true,ticks:{stepSize:2}}} }});

    } else if (role === 'it_office') {
        /* 1. LMS logins + submissions */
        new Chart(document.getElementById('chart1'), { data:{ labels:months, datasets:[
            { type:'bar', label:'Logins', data:[820,1240,1580,1430,980,640,310,1190,1050,870,720,540], backgroundColor:blue2, borderRadius:5, borderSkipped:false, order:2 },
            { type:'line', label:'Submissions', data:[210,380,520,480,310,180,95,420,380,290,240,180], borderColor:green, backgroundColor:'transparent', borderWidth:2, pointRadius:3, pointBackgroundColor:green, tension:0.35, order:1 }
        ]}, options:{ responsive:true, interaction:{mode:'index',intersect:false}, plugins:{legend:{position:'top',align:'end',labels:{boxWidth:10,padding:12}}}, scales:{ x:{grid:{display:false}}, y:{grid:{color:gc},beginAtZero:true} } }});
        /* 2. Module completion % per subject */
        new Chart(document.getElementById('chart2'), { type:'bar', data:{ labels:['Web Dev','Database','Networking','OS','Prog 1','Prog 2'], datasets:[{ label:'Completion %', data:[82,74,68,71,88,65], backgroundColor:[blue,green,amber,sky,violet,rose], borderRadius:5, borderSkipped:false }]}, options:{ indexAxis:'y', responsive:true, plugins:{legend:{display:false}}, scales:{x:{min:0,max:100,grid:{color:gc},ticks:{callback:function(v){return v+'%';}}},y:{grid:{display:false}}} }});
        /* 3. Quiz avg scores */
        new Chart(document.getElementById('chart3'), { type:'bar', data:{ labels:['Web Dev','Database','Networking','OS','Prog 1','Prog 2'], datasets:[{ label:'Avg Score', data:[78,72,65,70,84,63], backgroundColor:blue, borderRadius:5, borderSkipped:false }]}, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{x:{grid:{display:false}},y:{min:50,max:100,grid:{color:gc}}} }});

    } else if (role === 'osa') {
        /* 1. Club membership */
        new Chart(document.getElementById('chart1'), { type:'bar', data:{ labels:['SCA','JPCS','ROTC','Math Club','Science','Debate','Theater','Sports'], datasets:[{ label:'Members', data:[120,98,145,62,74,48,55,180], backgroundColor:[blue,green,amber,sky,violet,rose,teal,blue2], borderRadius:5, borderSkipped:false }]}, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{x:{grid:{display:false},ticks:{maxRotation:45}},y:{grid:{color:gc},beginAtZero:true}} }});
        /* 2. Events per month */
        new Chart(document.getElementById('chart2'), { type:'bar', data:{ labels:months, datasets:[{ label:'Events', data:[2,4,6,5,3,1,1,4,3,3,2,2], backgroundColor:violet, borderRadius:5, borderSkipped:false }]}, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{x:{grid:{display:false}},y:{grid:{color:gc},beginAtZero:true,ticks:{stepSize:2}}} }});
        /* 3. Volunteer hours by club */
        new Chart(document.getElementById('chart3'), { type:'bar', data:{ labels:['SCA','JPCS','ROTC','Math Club','Science','Debate','Theater','Sports'], datasets:[{ label:'Hours', data:[340,280,520,180,210,140,165,410], backgroundColor:teal, borderRadius:5, borderSkipped:false }]}, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{x:{grid:{display:false},ticks:{maxRotation:45}},y:{grid:{color:gc},beginAtZero:true}} }});

    } else if (role === 'qa') {
        /* 1. Compliance rate by area */
        new Chart(document.getElementById('chart1'), { type:'bar', data:{ labels:['Curriculum','Faculty','Facilities','Research','Community','Admin'], datasets:[{ label:'Compliance %', data:[88,82,74,79,85,91], backgroundColor:[blue,green,amber,sky,violet,rose], borderRadius:5, borderSkipped:false }]}, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{x:{grid:{display:false}},y:{min:50,max:100,grid:{color:gc},ticks:{callback:function(v){return v+'%';}}}} }});
        /* 2. Audit findings per program */
        new Chart(document.getElementById('chart2'), { type:'bar', data:{ labels:['BSIT','BSEd','BSBA','BSCrim','BSN','BSCS'], datasets:[{ label:'Findings', data:[3,5,4,2,3,2], backgroundColor:rose, borderRadius:5, borderSkipped:false }]}, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{x:{grid:{display:false}},y:{grid:{color:gc},beginAtZero:true,ticks:{stepSize:1}}} }});
        /* 3. Action plan status */
        new Chart(document.getElementById('chart3'), { type:'bar', data:{ labels:['Curriculum','Faculty','Facilities','Research','Community','Admin'], datasets:[
            { label:'Completed', data:[12,10,8,9,11,14], backgroundColor:green, borderRadius:4, borderSkipped:false, stack:'s' },
            { label:'In Progress', data:[5,7,9,6,4,3], backgroundColor:amber, borderRadius:4, borderSkipped:false, stack:'s' },
            { label:'Not Started', data:[2,3,4,3,2,1], backgroundColor:rose, borderRadius:4, borderSkipped:false, stack:'s' }
        ]}, options:{ responsive:true, interaction:{mode:'index',intersect:false}, plugins:{legend:{position:'top',align:'end',labels:{boxWidth:10,padding:12}}}, scales:{x:{stacked:true,grid:{display:false}},y:{stacked:true,grid:{color:gc},beginAtZero:true}} }});

    } else if (role === 'crad_officer') {
        /* 1. Projects by status doughnut */
        new Chart(document.getElementById('chart1'), { type:'doughnut', data:{ labels:['Ongoing','Submitted','Completed','On Hold'], datasets:[{ data:[8,4,5,1], backgroundColor:[blue,amber,green,rose], borderWidth:2, borderColor:'#fff' }]}, options:{ responsive:true, plugins:{ legend:{position:'bottom',labels:{boxWidth:10,padding:10,font:{size:11}}} } }});
        /* 2. Publications per year */
        new Chart(document.getElementById('chart2'), { type:'bar', data:{ labels:['2020','2021','2022','2023','2024','2025'], datasets:[{ label:'Publications', data:[3,5,4,7,8,9], backgroundColor:blue, borderRadius:5, borderSkipped:false }]}, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{x:{grid:{display:false}},y:{grid:{color:gc},beginAtZero:true,ticks:{stepSize:2}}} }});
        /* 3. Proposals by dept */
        new Chart(document.getElementById('chart3'), { type:'bar', data:{ labels:['CITE','CTE','CBA','CCJ','CN','Gen Ed'], datasets:[{ label:'Proposals', data:[5,4,3,2,4,2], backgroundColor:[blue,green,amber,sky,violet,rose], borderRadius:5, borderSkipped:false }]}, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{x:{grid:{display:false}},y:{grid:{color:gc},beginAtZero:true,ticks:{stepSize:1}}} }});
    }

})();
</script>


<?php require_once __DIR__ . '/../includes/layout-end.php'; ?>
