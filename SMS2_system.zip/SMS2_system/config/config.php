<?php
/**
 * SMS 2 - Global Configuration
 * Bestlink College of the Philippines
 */

define('APP_NAME', 'Student Management System 2');
define('APP_SHORT_NAME', 'SMS 2');
define('INSTITUTION', 'Bestlink College of the Philippines');
define('APP_VERSION', '1.0.0');

// Adjust if deployed under a different folder name
define('BASE_URL', '/SMS2_system');
define('ROOT_PATH', dirname(__DIR__));

/**
 * Module registry — drives sidebar navigation and subsystem index cards.
 * slug: URL-safe filename (without .php)
 */
$MODULES = [
    'enrollment' => [
        'label' => 'Enrollment Management',
        'icon'  => 'fa-user-graduate',
        'pages' => [
            ['slug' => 'online-pre-registration', 'title' => 'Online Pre-registration'],
            ['slug' => 'document-upload-portal', 'title' => 'Document Upload Portal'],
            ['slug' => 'enrollment-validation', 'title' => 'Enrollment Validation'],
            ['slug' => 'id-number-generation', 'title' => 'ID Number Generation'],
            ['slug' => 'grade-level-assignment', 'title' => 'Grade Level Assignment'],
            ['slug' => 'waiting-list-queue', 'title' => 'Waiting List Queue'],
            ['slug' => 'cross-enrollment-checker', 'title' => 'Cross-enrollment Checker'],
            ['slug' => 'auto-section-assignment', 'title' => 'Auto Section Assignment'],
            ['slug' => 'parent-notification', 'title' => 'Parent Notification'],
            ['slug' => 'enrollment-dashboard', 'title' => 'Enrollment Dashboard'],
        ],
    ],
    'registrar' => [
        'label' => 'Registrar',
        'icon'  => 'fa-folder-open',
        'pages' => [
            ['slug' => 'student-information-system', 'title' => 'Student Information System'],
            ['slug' => 'persona-file-database', 'title' => 'Persona File Database'],
            ['slug' => 'guardian-emergency-contact', 'title' => 'Guardian & Emergency Contact'],
            ['slug' => 'academic-history', 'title' => 'Academic History'],
            ['slug' => 'health-record-log', 'title' => 'Health Record Log'],
            ['slug' => 'rfid-qr-code-integration', 'title' => 'RFID/QR Code Integration'],
            ['slug' => 'student-id-generation', 'title' => 'Student ID Generation'],
            ['slug' => 'document-requests', 'title' => 'Document Requests'],
            ['slug' => 'student-status-tracker', 'title' => 'Student Status Tracker'],
            ['slug' => 'digital-file-storage', 'title' => 'Digital File Storage'],
            ['slug' => 'transcript-management', 'title' => 'Transcript Management'],
        ],
    ],
    'curriculum' => [
        'label' => 'Curriculum & Subject Management',
        'icon'  => 'fa-book',
        'pages' => [
            ['slug' => 'curriculum-builder', 'title' => 'Curriculum Builder'],
            ['slug' => 'subject-mapping', 'title' => 'Subject Mapping'],
            ['slug' => 'pre-requisite-configuration', 'title' => 'Pre-requisite Configuration'],
            ['slug' => 'electives-manager', 'title' => 'Electives Manager'],
            ['slug' => 'academic-strand-assignment', 'title' => 'Academic Strand Assignment'],
            ['slug' => 'subject-offering-history', 'title' => 'Subject Offering History'],
            ['slug' => 'subject-equivalency-tool', 'title' => 'Subject Equivalency Tool'],
            ['slug' => 'grade-weighting-setup', 'title' => 'Grade Weighting Setup'],
            ['slug' => 'ched-deped-validator', 'title' => 'CHED/DepEd Validator'],
            ['slug' => 'curriculum-export-tool', 'title' => 'Curriculum Export Tool'],
        ],
    ],
    'accreditation' => [
        'label' => 'Accreditation Management',
        'icon'  => 'fa-award',
        'pages' => [
            ['slug' => 'accreditation-document-repository', 'title' => 'Accreditation Document Repository'],
            ['slug' => 'self-assessment-report-builder', 'title' => 'Self Assessment Report Builder'],
            ['slug' => 'compliance-matrix-criteria-tracking', 'title' => 'Compliance Matrix & Criteria Tracking'],
            ['slug' => 'internal-quality-audit-scheduler', 'title' => 'Internal Quality Audit Scheduler'],
            ['slug' => 'accreditation-visit-management', 'title' => 'Accreditation Visit Management'],
            ['slug' => 'program-accreditation-tracker', 'title' => 'Program Accreditation Tracker'],
            ['slug' => 'faculty-staff-qualification-tracking', 'title' => 'Faculty & Staff Qualification Tracking'],
            ['slug' => 'physical-facilities-monitoring', 'title' => 'Physical Facilities Monitoring'],
            ['slug' => 'continuous-improvement-action-planning', 'title' => 'Continuous Improvement Action Planning'],
            ['slug' => 'accreditation-reports-analytics', 'title' => 'Accreditation Reports & Analytics'],
        ],
    ],
    'payment' => [
        'label' => 'Payment Management',
        'icon'  => 'fa-credit-card',
        'pages' => [
            ['slug' => 'student-billing-invoicing', 'title' => 'Student Billing & Invoicing'],
            ['slug' => 'payment-collection-portal', 'title' => 'Payment Collection Portal'],
            ['slug' => 'online-payment-integration', 'title' => 'Online Payment Integration'],
            ['slug' => 'fee-setup-configuration', 'title' => 'Fee Setup & Configuration'],
            ['slug' => 'discount-scholarship-application', 'title' => 'Discount & Scholarship Application'],
            ['slug' => 'payment-history-ledger-system', 'title' => 'Payment History & Ledger System'],
            ['slug' => 'collection-reporting-analytics', 'title' => 'Collection Reporting & Analytics'],
            ['slug' => 'accounts-receivable-management', 'title' => 'Accounts Receivable Management'],
            ['slug' => 'penalty-due-date-management', 'title' => 'Penalty & Due Date Management'],
            ['slug' => 'audit-access-control', 'title' => 'Audit & Access Control'],
        ],
    ],
    'faculty' => [
        'label' => 'Faculty Management',
        'icon'  => 'fa-chalkboard-teacher',
        'pages' => [
            ['slug' => 'faculty-profile', 'title' => 'Faculty Profile'],
            ['slug' => 'subject-load-tracker', 'title' => 'Subject Load Tracker'],
            ['slug' => 'schedule-assignment', 'title' => 'Schedule Assignment'],
            ['slug' => 'attendance-monitoring', 'title' => 'Attendance Monitoring'],
            ['slug' => 'leave-application-approval', 'title' => 'Leave Application & Approval'],
            ['slug' => 'salary-grade-payroll-setup', 'title' => 'Salary Grade & Payroll Setup'],
            ['slug' => 'teaching-history', 'title' => 'Teaching History'],
            ['slug' => 'clearance-system', 'title' => 'Clearance System'],
            ['slug' => 'evaluation-summary', 'title' => 'Evaluation Summary'],
            ['slug' => 'faculty-directory', 'title' => 'Faculty Directory'],
        ],
    ],
    'scheduling' => [
        'label' => 'Class Schedule',
        'icon'  => 'fa-calendar-alt',
        'pages' => [
            ['slug' => 'section-assignment-tool', 'title' => 'Section Assignment Tool'],
            ['slug' => 'teacher-schedule-mapping', 'title' => 'Teacher Schedule Mapping'],
            ['slug' => 'conflict-checker', 'title' => 'Conflict Checker'],
            ['slug' => 'exam-timetable-generator', 'title' => 'Exam Timetable Generator'],
            ['slug' => 'substitute-assignment-tracker', 'title' => 'Substitute Assignment Tracker'],
            ['slug' => 'special-class-scheduler', 'title' => 'Special Class Scheduler'],
            ['slug' => 'room-availability-checker', 'title' => 'Room Availability Checker'],
            ['slug' => 'schedule-cloning-tool', 'title' => 'Schedule Cloning Tool'],
            ['slug' => 'time-block-generator', 'title' => 'Time Block Generator'],
            ['slug' => 'calendar-integration', 'title' => 'Calendar Integration'],
        ],
    ],
    'cocurricular' => [
        'label' => 'Co-Curricular',
        'icon'  => 'fa-users',
        'pages' => [
            ['slug' => 'club-registration-portal', 'title' => 'Club Registration Portal'],
            ['slug' => 'student-club-membership', 'title' => 'Student Club Membership'],
            ['slug' => 'club-officer-elections', 'title' => 'Club Officer Elections'],
            ['slug' => 'event-activity-logs', 'title' => 'Event & Activity Logs'],
            ['slug' => 'attendance-tracker', 'title' => 'Attendance Tracker'],
            ['slug' => 'club-achievement-records', 'title' => 'Club Achievement Records'],
            ['slug' => 'budget-requests', 'title' => 'Budget Requests'],
            ['slug' => 'inter-school-communication', 'title' => 'Inter-school Communication'],
            ['slug' => 'volunteer-hour-tracking', 'title' => 'Volunteer Hour Tracking'],
            ['slug' => 'club-directory', 'title' => 'Club Directory'],
        ],
    ],
    'lms' => [
        'label' => 'Online Learning & LMS',
        'icon'  => 'fa-laptop',
        'pages' => [
            ['slug' => 'class-portal', 'title' => 'Class Portal'],
            ['slug' => 'lesson-material-upload', 'title' => 'Lesson Material Upload'],
            ['slug' => 'assignment-submission', 'title' => 'Assignment Submission'],
            ['slug' => 'online-quiz', 'title' => 'Online Quiz'],
            ['slug' => 'virtual-classroom-integration', 'title' => 'Virtual Classroom Integration'],
            ['slug' => 'grading-integration', 'title' => 'Grading Integration'],
            ['slug' => 'feedback-comments', 'title' => 'Feedback & Comments'],
            ['slug' => 'module-completion-tracking', 'title' => 'Module Completion Tracking'],
            ['slug' => 'multimedia-support', 'title' => 'Multimedia Support'],
            ['slug' => 'lms-analytics', 'title' => 'LMS Analytics'],
        ],
    ],
    'crad' => [
        'label' => 'CRAD',
        'icon'  => 'fa-flask',
        'pages' => [
            ['slug' => 'proposal-submission-tracking', 'title' => 'Proposal Submission & Tracking'],
            ['slug' => 'adviser-assignment-system', 'title' => 'Adviser Assignment System'],
            ['slug' => 'research-grants-funding-assistance', 'title' => 'Research Grants & Funding Assistance'],
            ['slug' => 'documentation-publication-management', 'title' => 'Documentation & Publication Management'],
            ['slug' => 'research-collaboration-portal', 'title' => 'Research Collaboration Portal'],
            ['slug' => 'research-repository', 'title' => 'Research Repository'],
        ],
    ],

    // ── Superadmin only ──────────────────────────────────────────────────────
    'user-management' => [
        'label' => 'User Management',
        'icon'  => 'fa-users-cog',
        'pages' => [
            ['slug' => 'user-accounts',    'title' => 'User Accounts'],
            ['slug' => 'role-permissions', 'title' => 'Role & Permissions'],
            ['slug' => 'activity-logs',    'title' => 'Activity Logs'],
            ['slug' => 'system-settings',  'title' => 'System Settings'],
        ],
    ],
];
