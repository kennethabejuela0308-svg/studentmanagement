/**
 * SMS 2 – Modern page loader
 */
(function () {
    'use strict';

    window.__smsLoadStart = Date.now();

    var MIN_MS = 700;
    var FADE_MS = 480;
    var reduced = false;

    try {
        reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    } catch (e) { /* ignore */ }

    if (reduced) {
        MIN_MS = 100;
        FADE_MS = 120;
    }

    function getLoader() {
        return document.getElementById('smsPageLoader');
    }

    function isPublicPage() {
        var body = document.body;
        if (!body) return false;
        return body.classList.contains('login-page') || body.classList.contains('welcome-page');
    }

    function finishLoader() {
        var loader = getLoader();
        if (!loader || loader.classList.contains('is-done')) return;

        loader.classList.add('is-leaving');
        document.documentElement.classList.add('sms-app-ready');
        if (document.body) document.body.classList.add('sms-loaded');

        window.setTimeout(function () {
            loader.classList.add('is-done');
            loader.setAttribute('aria-busy', 'false');
            loader.setAttribute('aria-hidden', 'true');
            if (loader.parentNode) loader.parentNode.removeChild(loader);
        }, FADE_MS);
    }

    function scheduleHide() {
        if (isPublicPage()) {
            MIN_MS = Math.min(MIN_MS, 280);
        }
        var elapsed = Date.now() - (window.__smsLoadStart || Date.now());
        var wait = Math.max(0, MIN_MS - elapsed);
        window.setTimeout(finishLoader, wait);
    }

    function boot() {
        if (!getLoader()) {
            document.documentElement.classList.add('sms-app-ready');
            return;
        }

        if (document.readyState === 'complete') {
            scheduleHide();
        } else {
            window.addEventListener('load', scheduleHide, { once: true });
            window.setTimeout(scheduleHide, 4500);
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

    window.SMS2Loader = { hide: finishLoader };
})();
