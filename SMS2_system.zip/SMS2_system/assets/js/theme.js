/**
 * SMS 2 – Theme Manager (light / dark)
 * Persists preference, updates icons, and refreshes Chart.js when present.
 */
(function () {
    'use strict';

    var STORAGE_KEY = 'sms2-theme';
    var VALID = { light: true, dark: true };

    function normalize(theme) {
        return VALID[theme] ? theme : 'light';
    }

    function getStoredTheme() {
        try {
            return normalize(localStorage.getItem(STORAGE_KEY));
        } catch (e) {
            return 'light';
        }
    }

    function storeTheme(theme) {
        try {
            localStorage.setItem(STORAGE_KEY, theme);
        } catch (e) { /* private mode / blocked storage */ }
    }

    function applyTheme(theme, options) {
        theme = normalize(theme);
        var root = document.documentElement;
        root.setAttribute('data-theme', theme);
        root.style.colorScheme = theme;
        // Clear the FOUC-prevention inline background so our CSS takes over.
        // Keep it during the very first silent call (before CSS loads) but
        // clear it on every subsequent call and after DOMContentLoaded.
        if (!options || options.silent !== true) {
            root.style.backgroundColor = '';
        }

        document.querySelectorAll('[data-theme-toggle]').forEach(function (btn) {
            var next = theme === 'dark' ? 'light' : 'dark';
            btn.setAttribute('aria-label', theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
            btn.setAttribute('title', theme === 'dark' ? 'Light mode' : 'Dark mode');
            btn.setAttribute('aria-pressed', theme === 'dark' ? 'true' : 'false');
            btn.dataset.nextTheme = next;
        });

        document.querySelectorAll('[data-theme-set]').forEach(function (btn) {
            var isActive = btn.getAttribute('data-theme-set') === theme;
            btn.classList.toggle('active', isActive);
            btn.setAttribute('aria-current', isActive ? 'true' : 'false');
        });

        refreshCharts();

        if (!options || options.silent !== true) {
            try {
                window.dispatchEvent(new CustomEvent('sms2:themechange', { detail: { theme: theme } }));
            } catch (e) { /* older browsers */ }
        }

        return theme;
    }

    function cssVar(name, fallback) {
        var value = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
        return value || fallback;
    }

    function refreshCharts() {
        if (typeof Chart === 'undefined') return;

        var textColor = cssVar('--sms-chart-text', '#64748b');
        var gridColor = cssVar('--sms-chart-grid', 'rgba(15,33,88,0.06)');
        var doughnutBorder = cssVar('--sms-chart-doughnut-border', '#ffffff');

        Chart.defaults.color = textColor;
        if (Chart.defaults.borderColor !== undefined) {
            Chart.defaults.borderColor = gridColor;
        }

        var list = [];
        if (typeof Chart.getChart === 'function') {
            document.querySelectorAll('canvas').forEach(function (canvas) {
                var chart = Chart.getChart(canvas);
                if (chart) list.push(chart);
            });
        } else if (Chart.instances) {
            var charts = Chart.instances;
            if (typeof charts.forEach === 'function') {
                charts.forEach(function (chart) { list.push(chart); });
            } else {
                Object.keys(charts).forEach(function (k) { list.push(charts[k]); });
            }
        }

        list.forEach(function (chart) {
            if (!chart || !chart.options) return;

            try {
                if (chart.options.scales) {
                    Object.keys(chart.options.scales).forEach(function (key) {
                        var scale = chart.options.scales[key];
                        if (!scale) return;
                        scale.ticks = scale.ticks || {};
                        scale.ticks.color = textColor;
                        if (scale.title) scale.title.color = textColor;
                        if (scale.grid) scale.grid.color = gridColor;
                    });
                }

                if (chart.options.plugins && chart.options.plugins.legend && chart.options.plugins.legend.labels) {
                    chart.options.plugins.legend.labels.color = textColor;
                }

                if (chart.data && chart.data.datasets) {
                    var chartType = (chart.config && chart.config.type) || '';
                    chart.data.datasets.forEach(function (ds) {
                        if (chartType === 'doughnut' || chartType === 'pie') {
                            ds.borderColor = doughnutBorder;
                        } else if (ds.borderColor === '#fff' || ds.borderColor === '#ffffff' || ds.borderColor === 'white') {
                            ds.borderColor = doughnutBorder;
                        }
                    });
                }

                chart.update('none');
            } catch (err) {
                /* ignore chart refresh errors to avoid breaking the UI */
            }
        });
    }

    function toggleTheme() {
        var current = document.documentElement.getAttribute('data-theme') || getStoredTheme();
        var next = current === 'dark' ? 'light' : 'dark';
        storeTheme(next);
        applyTheme(next);
        return next;
    }

    function bindToggles() {
        document.querySelectorAll('[data-theme-toggle]').forEach(function (btn) {
            if (btn.dataset.themeBound === '1') return;
            btn.dataset.themeBound = '1';
            btn.addEventListener('click', function (e) {
                e.preventDefault();
                toggleTheme();
            });
        });

        document.querySelectorAll('[data-theme-set]').forEach(function (btn) {
            if (btn.dataset.themeBound === '1') return;
            btn.dataset.themeBound = '1';
            btn.addEventListener('click', function (e) {
                e.preventDefault();
                var theme = normalize(btn.getAttribute('data-theme-set'));
                storeTheme(theme);
                applyTheme(theme);
            });
        });
    }

    // Public API
    window.SMS2Theme = {
        get: function () {
            return document.documentElement.getAttribute('data-theme') || getStoredTheme();
        },
        set: function (theme) {
            theme = normalize(theme);
            storeTheme(theme);
            return applyTheme(theme);
        },
        toggle: toggleTheme,
        refreshCharts: refreshCharts
    };

    // Apply immediately if HTML already has data-theme from FOUC script
    applyTheme(document.documentElement.getAttribute('data-theme') || getStoredTheme(), { silent: true });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            bindToggles();
            // Clear the FOUC inline background now that CSS is fully loaded
            document.documentElement.style.backgroundColor = '';
            applyTheme(getStoredTheme(), { silent: true });
            // Charts often init after DOMContentLoaded in page scripts — refresh shortly after
            setTimeout(refreshCharts, 50);
            setTimeout(refreshCharts, 300);
        });
    } else {
        bindToggles();
        // Already past DOMContentLoaded — clear FOUC inline style now
        document.documentElement.style.backgroundColor = '';
        setTimeout(refreshCharts, 50);
        setTimeout(refreshCharts, 300);
    }
})();
