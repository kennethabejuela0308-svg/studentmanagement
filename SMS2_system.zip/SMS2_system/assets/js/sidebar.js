/**
 * SMS 2 - Sidebar Toggle & Responsive Behavior
 * Adapts sidebar mode based on viewport: drawer on mobile, collapse on desktop.
 */
document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.getElementById('smsSidebar');
    const overlay = document.getElementById('sidebarOverlay');
    const toggleBtn = document.getElementById('sidebarToggle');

    if (!sidebar) return;

    const DESKTOP_BREAKPOINT = 992;

    function isDesktop() {
        return window.innerWidth >= DESKTOP_BREAKPOINT;
    }

    function openMobileSidebar() {
        sidebar.classList.add('show');
        if (overlay) overlay.classList.add('show');
        document.body.classList.add('sidebar-open');
        document.body.style.overflow = 'hidden';
    }

    function closeMobileSidebar() {
        sidebar.classList.remove('show');
        if (overlay) overlay.classList.remove('show');
        document.body.classList.remove('sidebar-open');
        document.body.style.overflow = '';
    }

    function toggleDesktopSidebar() {
        document.body.classList.toggle('sidebar-collapsed');
        localStorage.setItem(
            'sidebarCollapsed',
            document.body.classList.contains('sidebar-collapsed') ? 'true' : 'false'
        );
    }

    function handleToggle() {
        if (isDesktop()) {
            closeMobileSidebar();
            toggleDesktopSidebar();
        } else {
            if (sidebar.classList.contains('show')) {
                closeMobileSidebar();
            } else {
                openMobileSidebar();
            }
        }
    }

    if (toggleBtn) {
        toggleBtn.addEventListener('click', handleToggle);
    }

    if (overlay) {
        overlay.addEventListener('click', closeMobileSidebar);
    }

    // Close drawer after navigation on mobile/tablet
    sidebar.querySelectorAll('.nav-link').forEach(function (link) {
        link.addEventListener('click', function () {
            if (!isDesktop()) {
                closeMobileSidebar();
            }
        });
    });

    // Escape key closes mobile drawer
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && !isDesktop() && sidebar.classList.contains('show')) {
            closeMobileSidebar();
        }
    });

    // Restore desktop collapsed preference
    function applyLayoutForViewport() {
        if (isDesktop()) {
            closeMobileSidebar();
            if (localStorage.getItem('sidebarCollapsed') === 'true') {
                document.body.classList.add('sidebar-collapsed');
            }
        } else {
            document.body.classList.remove('sidebar-collapsed');
            closeMobileSidebar();
        }
    }

    applyLayoutForViewport();

    // Re-adjust on resize, rotate, or fold (debounced)
    let resizeTimer;
    window.addEventListener('resize', function () {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(applyLayoutForViewport, 150);
    });

    window.addEventListener('orientationchange', function () {
        setTimeout(applyLayoutForViewport, 200);
    });
});
