<?php
/**
 * Shared Reports & Analytics page renderer
 * Fleet-style process list UI, role-accurate SMS2 content.
 * Expects: $reportSlug
 */
require_once ROOT_PATH . '/includes/authentication.php';
requireAuth();

require_once ROOT_PATH . '/includes/reports-catalog.php';
require_once ROOT_PATH . '/includes/reports-process.php';

$reportSlug = trim((string) ($reportSlug ?? ($activePage ?? '')));
if ($reportSlug === '' || !smsUserCanAccessReport($reportSlug)) {
    header('Location: ' . BASE_URL . '/dashboard/index.php');
    exit;
}

$reportMeta = null;
foreach (smsReportsCatalog() as $item) {
    if ($item['slug'] === $reportSlug) {
        $reportMeta = $item;
        break;
    }
}

$pageTitle = $reportMeta['title'] ?? 'Report';
$activeModule = 'reports-analytics';
$activePage = $reportSlug;
$breadcrumbs = [
    ['label' => 'Reports & Analytics', 'url' => BASE_URL . '/modules/reports-analytics/index.php'],
    ['label' => $pageTitle, 'url' => null],
];

$roleKey = getCurrentUserRoleKey();
$cradProcess = smsReportProcess($reportSlug, $roleKey);

require_once ROOT_PATH . '/includes/breadcrumbs.php';
require_once ROOT_PATH . '/includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>
<?php require_once ROOT_PATH . '/includes/crad-module-process.php'; ?>
<?php require_once ROOT_PATH . '/includes/layout-end.php'; ?>
