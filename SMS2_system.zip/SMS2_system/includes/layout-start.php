<?php
/**
 * SMS 2 - Authenticated Layout Start
 * Include after setting $pageTitle, $activeModule, optional $activePage, $breadcrumbs
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/authentication.php';
requireAuth();

$pageTitle    = $pageTitle ?? APP_NAME;
$activeModule = $activeModule ?? '';
$activePage   = $activePage ?? '';
$breadcrumbs  = $breadcrumbs ?? [];
$bodyClass    = 'sms-app';

requireModuleAccess($activeModule);

require_once ROOT_PATH . '/includes/header.php';
?>
<div class="sms-wrapper">
    <?php require_once ROOT_PATH . '/includes/navbar.php'; ?>
    <?php require_once ROOT_PATH . '/includes/sidebar.php'; ?>
    <div class="sms-content">
        <main class="sms-main">
