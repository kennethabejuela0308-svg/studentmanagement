<?php
/**
 * SMS 2 - Authentication Stub
 * Phase 1: UI-only — sets a demo session on login.
 * Phase 2: Replace with real credential validation.
 */

require_once __DIR__ . '/../config/session.php';

/**
 * Check if user is authenticated.
 */
function isAuthenticated(): bool
{
    return !empty($_SESSION['user_id']);
}

/**
 * Require authentication or redirect to login.
 */
function requireAuth(): void
{
    if (!isAuthenticated()) {
        header('Location: ' . BASE_URL . '/login/login.php');
        exit;
    }
}

/**
 * Get current user display name.
 */
function getCurrentUserName(): string
{
    return $_SESSION['user_name'] ?? 'Administrator';
}

/**
 * Get current user role label.
 */
function getCurrentUserRole(): string
{
    return $_SESSION['user_role'] ?? 'System Admin';
}

function getCurrentUserRoleKey(): string
{
    return $_SESSION['user_role_key'] ?? 'admin';
}

function getAllowedModuleKeys(): array
{
    $roleKey = getCurrentUserRoleKey();

    // admin / superadmin — always full access, never overridden
    if ($roleKey === 'admin') {
        return [];
    }

    /*
     * Default access per role — baseline before any superadmin override.
     */
    $defaults = [
        'student'      => ['student_portal'],
        'registrar'    => ['enrollment', 'registrar', 'curriculum', 'scheduling', 'reports-analytics'],
        'crad_officer' => ['crad', 'reports-analytics'],
        'finance'      => ['payment', 'reports-analytics'],
        'hr'           => ['faculty', 'reports-analytics'],
        'it_office'    => ['lms', 'reports-analytics'],
        'osa'          => ['cocurricular', 'reports-analytics'],
        'qa'           => ['accreditation', 'reports-analytics'],
    ];

    $allowed = $defaults[$roleKey] ?? [];

    /*
     * Apply overrides from shared JSON file written by the permission matrix.
     * crad_officer's role_key is 'crad_officer' but the matrix stores it as 'crad'.
     */
    $matrixRoleKey = $roleKey === 'crad_officer' ? 'crad' : $roleKey;

    $permFile = ROOT_PATH . '/config/perm_overrides.json';
    if (file_exists($permFile)) {
        $json      = file_get_contents($permFile);
        $overrides = json_decode($json, true);

        if (is_array($overrides) && !empty($overrides[$matrixRoleKey])) {
            foreach ($overrides[$matrixRoleKey] as $module => $granted) {
                if ($granted) {
                    if (!in_array($module, $allowed, true)) {
                        $allowed[] = $module;
                    }
                } else {
                    $allowed = array_values(array_filter(
                        $allowed,
                        fn($m) => $m !== $module
                    ));
                }
            }
        }
    }

    // Staff with at least one office module always keep Reports & Analytics.
    if ($roleKey !== 'student') {
        $officeModules = array_values(array_filter(
            $allowed,
            static fn(string $m): bool => !in_array($m, ['reports-analytics', 'student_portal', 'user-management'], true)
        ));
        if ($officeModules !== [] && !in_array('reports-analytics', $allowed, true)) {
            $allowed[] = 'reports-analytics';
        }
    }

    return $allowed;
}

function userCanAccessModule(string $moduleKey): bool
{
    if ($moduleKey === '' || $moduleKey === 'dashboard') {
        return true;
    }

    // user-management is strictly superadmin / admin only
    if ($moduleKey === 'user-management') {
        return getCurrentUserRoleKey() === 'admin';
    }

    $allowedModules = getAllowedModuleKeys();
    return $allowedModules === [] || in_array($moduleKey, $allowedModules, true);
}

/**
 * Require superadmin role or redirect to dashboard.
 */
function requireSuperAdmin(): void
{
    if (getCurrentUserRoleKey() !== 'admin') {
        header('Location: ' . BASE_URL . '/dashboard/index.php');
        exit;
    }
}

function getVisibleModules(array $modules): array
{
    $allowedModules = getAllowedModuleKeys();

    if ($allowedModules === []) {
        $visible = $modules;
    } else {
        $visible = array_intersect_key($modules, array_flip($allowedModules));
    }

    // Reports & Analytics pages are role-filtered for accuracy.
    if (isset($visible['reports-analytics'])) {
        require_once __DIR__ . '/reports-catalog.php';
        $roleReports = smsReportsForRole();
        $visible['reports-analytics']['pages'] = array_map(
            static fn(array $report): array => [
                'slug'  => $report['slug'],
                'title' => $report['title'],
            ],
            $roleReports
        );
    }

    return $visible;
}

function requireModuleAccess(string $moduleKey): void
{
    if (!userCanAccessModule($moduleKey)) {
        header('Location: ' . BASE_URL . '/dashboard/index.php');
        exit;
    }
}

/**
 * Demo login — validates username + password against fixed credentials.
 *
 * Login accepts:
 *   email  — username@bestlink.edu.ph  (required for all staff accounts)
 *   e.g. superadmin@bestlink.edu.ph, registrar@bestlink.edu.ph
 *
 * Student exception: bare student ID works without domain (e.g. s230106713)
 *
 * Password pattern: @<username>123
 *   e.g. superadmin  → @superadmin123
 *        registrar   → @registrar123
 */
function attemptLogin(string $username, string $password): bool
{
    if (trim($username) === '' || trim($password) === '') {
        return false;
    }

    $input = strtolower(trim($username));

    // Staff MUST log in with full email: username@bestlink.edu.ph
    // Student IDs (s + digits) are the only exception — they log in bare.
    if (str_ends_with($input, '@bestlink.edu.ph')) {
        // Strip domain to get the lookup key
        $input = substr($input, 0, strpos($input, '@bestlink.edu.ph'));
    } elseif (preg_match('/^s\d+$/i', $input)) {
        // Student ID — allowed without domain
    } else {
        // Bare staff username without @bestlink.edu.ph — reject
        return false;
    }

    /*
     * Credential table
     * Each entry: [ username, expected_password, user_id, display_name, role_label, role_key, extra_session ]
     */
    $credentials = [
        'superadmin'     => [
            'password'   => '@superadmin123',
            'id'         => 1,
            'name'       => 'Super Admin',
            'role'       => 'Super Admin',
            'role_key'   => 'admin',
        ],
        'registrar'      => [
            'password'   => '@registrar123',
            'id'         => 2,
            'name'       => 'Registrar',
            'role'       => 'Registrar',
            'role_key'   => 'registrar',
        ],
        'cradofficer'    => [
            'password'   => '@cradofficer123',
            'id'         => 3,
            'name'       => 'CRAD Officer',
            'role'       => 'CRAD Officer',
            'role_key'   => 'crad_officer',
        ],
        'finance'        => [
            'password'   => '@finance123',
            'id'         => 4,
            'name'       => 'Finance',
            'role'       => 'Finance',
            'role_key'   => 'finance',
        ],
        'hr'             => [
            'password'   => '@hr123',
            'id'         => 5,
            'name'       => 'HR',
            'role'       => 'HR',
            'role_key'   => 'hr',
        ],
        'itofficer'      => [
            'password'   => '@itofficer123',
            'id'         => 6,
            'name'       => 'IT Officer',
            'role'       => 'IT Officer',
            'role_key'   => 'it_office',
        ],
        'studentaffairs' => [
            'password'   => '@studentaffairs123',
            'id'         => 7,
            'name'       => 'Student Affairs',
            'role'       => 'Student Affairs',
            'role_key'   => 'osa',
        ],
        'qualityassurance' => [
            'password'   => '@qualityassurance123',
            'id'         => 8,
            'name'       => 'Quality Assurance',
            'role'       => 'Quality Assurance',
            'role_key'   => 'qa',
        ],
        's230106713'     => [
            'password'   => '@ka8080',
            'id'         => 230106713,
            'name'       => 'Kenneth Abejuela',
            'role'       => 'Student',
            'role_key'   => 'student',
            'student_id' => 'S230106713',
        ],
    ];

    // Unknown username — reject immediately
    if (!isset($credentials[$input])) {
        return false;
    }

    $user = $credentials[$input];

    // Wrong password — reject (case-sensitive, exact match)
    if ($password !== $user['password']) {
        return false;
    }

    // Credentials valid — populate session
    $_SESSION['user_id']       = $user['id'];
    $_SESSION['user_name']     = $user['name'];
    $_SESSION['user_role']     = $user['role'];
    $_SESSION['user_role_key'] = $user['role_key'];

    // Role-specific extras
    if (isset($user['student_id'])) {
        $_SESSION['student_id'] = $user['student_id'];
    }

    return true;
}

/**
 * Destroy session and log out.
 */
function logout(): void
{
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();
}
