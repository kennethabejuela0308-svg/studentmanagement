<?php
/**
 * SMS 2 - Authentication Stub
 * Phase 1: UI-only — sets a demo session on login.
 * Phase 2: Replace with real credential validation.
 */

require_once __DIR__ . '/../config/session.php';

/**
 * Check if user is authenticated.
 */
function isAuthenticated(): bool
{
    return !empty($_SESSION['user_id']);
}

/**
 * Require authentication or redirect to login.
 */
function requireAuth(): void
{
    if (!isAuthenticated()) {
        header('Location: ' . BASE_URL . '/login/login.php');
        exit;
    }
}

/**
 * Get current user display name.
 */
function getCurrentUserName(): string
{
    return $_SESSION['user_name'] ?? 'Administrator';
}

/**
 * Get current user role label.
 */
function getCurrentUserRole(): string
{
    return $_SESSION['user_role'] ?? 'System Admin';
}

function getCurrentUserRoleKey(): string
{
    return $_SESSION['user_role_key'] ?? 'admin';
}

function getAllowedModuleKeys(): array
{
    $roleKey = getCurrentUserRoleKey();

    if ($roleKey === 'student') {
        return ['student_portal'];
    }

    if ($roleKey === 'registrar') {
        return [
            'enrollment',
            'registrar',
            'curriculum',
            'scheduling',
        ];
    }

    if ($roleKey === 'crad_officer') {
        return ['crad'];
    }

    if ($roleKey === 'finance') {
        return ['payment'];
    }

    if ($roleKey === 'hr') {
        return ['faculty'];
    }

    if ($roleKey === 'it_office') {
        return ['lms'];
    }

    if ($roleKey === 'osa') {
        return ['cocurricular'];
    }

    if ($roleKey === 'qa') {
        return ['accreditation'];
    }

    return [];
}

function userCanAccessModule(string $moduleKey): bool
{
    if ($moduleKey === '' || $moduleKey === 'dashboard') {
        return true;
    }

    $allowedModules = getAllowedModuleKeys();
    return $allowedModules === [] || in_array($moduleKey, $allowedModules, true);
}

function getVisibleModules(array $modules): array
{
    $allowedModules = getAllowedModuleKeys();

    if ($allowedModules === []) {
        return $modules;
    }

    return array_intersect_key($modules, array_flip($allowedModules));
}

function requireModuleAccess(string $moduleKey): void
{
    if (!userCanAccessModule($moduleKey)) {
        header('Location: ' . BASE_URL . '/dashboard/index.php');
        exit;
    }
}

/**
 * Demo login — accepts any credentials in Phase 1.
 */
function attemptLogin(string $username, string $password): bool
{
    if (trim($username) === '' || trim($password) === '') {
        return false;
    }

    $normalizedUsername = strtolower(trim($username));
    $isSuperAdmin = $normalizedUsername === 'superadmin';
    $isRegistrar = $normalizedUsername === 'registrar';
    $isCradOfficer = $normalizedUsername === 'cradofficer';
    $isFinance = $normalizedUsername === 'finance';
    $isHr = $normalizedUsername === 'hr';
    $isItOffice = $normalizedUsername === 'itofficer';
    $isOsa = $normalizedUsername === 'studentaffairs';
    $isQa = $normalizedUsername === 'qualityassurance';
    $isStudent = $normalizedUsername === 's230000001';

    if ($isSuperAdmin) {
        $_SESSION['user_id']       = 1;
        $_SESSION['user_name']     = 'Super Admin';
        $_SESSION['user_role']     = 'Super Admin';
        $_SESSION['user_role_key'] = 'admin';

        return true;
    }

    if ($isRegistrar) {
        $_SESSION['user_id']       = 2;
        $_SESSION['user_name']     = 'Registrar';
        $_SESSION['user_role']     = 'Registrar';
        $_SESSION['user_role_key'] = 'registrar';

        return true;
    }

    if ($isCradOfficer) {
        $_SESSION['user_id']       = 3;
        $_SESSION['user_name']     = 'CRAD Officer';
        $_SESSION['user_role']     = 'CRAD Officer';
        $_SESSION['user_role_key'] = 'crad_officer';

        return true;
    }

    if ($isFinance) {
        $_SESSION['user_id']       = 4;
        $_SESSION['user_name']     = 'Finance';
        $_SESSION['user_role']     = 'Finance';
        $_SESSION['user_role_key'] = 'finance';

        return true;
    }

    if ($isHr) {
        $_SESSION['user_id']       = 5;
        $_SESSION['user_name']     = 'HR';
        $_SESSION['user_role']     = 'HR';
        $_SESSION['user_role_key'] = 'hr';

        return true;
    }

    if ($isItOffice) {
        $_SESSION['user_id']       = 6;
        $_SESSION['user_name']     = 'IT Officer';
        $_SESSION['user_role']     = 'IT Officer';
        $_SESSION['user_role_key'] = 'it_office';

        return true;
    }

    if ($isOsa) {
        $_SESSION['user_id']       = 7;
        $_SESSION['user_name']     = 'Student Affairs';
        $_SESSION['user_role']     = 'Student Affairs';
        $_SESSION['user_role_key'] = 'osa';

        return true;
    }

    if ($isQa) {
        $_SESSION['user_id']       = 8;
        $_SESSION['user_name']     = 'Quality Assurance';
        $_SESSION['user_role']     = 'Quality Assurance';
        $_SESSION['user_role_key'] = 'qa';

        return true;
    }

    if ($isStudent) {
        $_SESSION['user_id']       = 230000001;
        $_SESSION['user_name']     = 'Kenneth Abejuela';
        $_SESSION['user_role']     = 'Student';
        $_SESSION['user_role_key'] = 'student';
        $_SESSION['student_id']    = 'S230000001';

        return true;
    }

    // Unknown username — reject login
    return false;
}

/**
 * Destroy session and log out.
 */
function logout(): void
{
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();
}
