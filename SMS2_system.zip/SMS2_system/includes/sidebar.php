<?php
/**
 * SMS 2 - Sidebar Navigation
 * Expects: optional $activeModule (string), optional $activePage (string)
 */
if (!isset($MODULES)) {
    require_once __DIR__ . '/../config/config.php';
}
require_once __DIR__ . '/authentication.php';

$activeModule = $activeModule ?? '';
$activePage   = $activePage ?? '';
$isStudentPortal = getCurrentUserRoleKey() === 'student';
$visibleModules = getVisibleModules($MODULES);
$studentNavItems = [
    ['slug' => 'my-profile', 'href' => BASE_URL . '/modules/student-portal/pages/my-profile.php', 'icon' => 'fa-user', 'label' => 'My Profile'],
    ['slug' => 'student-id', 'href' => BASE_URL . '/modules/student-portal/pages/student-id.php', 'icon' => 'fa-id-card', 'label' => 'Student ID'],
    ['slug' => 'account-balance', 'href' => BASE_URL . '/modules/student-portal/pages/account-balance.php', 'icon' => 'fa-wallet', 'label' => 'Account Balance'],
    ['slug' => 'class-schedule', 'href' => BASE_URL . '/modules/student-portal/pages/class-schedule.php', 'icon' => 'fa-calendar-alt', 'label' => 'Class Schedule'],
    ['slug' => 'academic-records', 'href' => BASE_URL . '/modules/student-portal/pages/academic-records.php', 'icon' => 'fa-file-alt', 'label' => 'Academic Records'],
    ['slug' => 'subjects-professors', 'href' => BASE_URL . '/modules/student-portal/pages/subjects-professors.php', 'icon' => 'fa-chalkboard-teacher', 'label' => 'Subject & Professors'],
    ['slug' => 'payment-history', 'href' => BASE_URL . '/modules/student-portal/pages/payment-history.php', 'icon' => 'fa-receipt', 'label' => 'Payment History'],
];
?>
<aside class="sms-sidebar" id="smsSidebar">
    <div class="sidebar-header d-none d-lg-flex align-items-center px-3 py-3">
        <div class="brand-logo-frame me-2">
            <img class="sidebar-brand-logo" src="<?= BASE_URL ?>/images/bestlink.png" alt="Bestlink College logo">
        </div>
        <span class="text-white fw-semibold"><?= htmlspecialchars(APP_SHORT_NAME) ?></span>
    </div>

    <nav class="sidebar-nav">
        <ul class="nav flex-column">
            <?php if ($isStudentPortal): ?>
                <?php foreach ($studentNavItems as $item): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= ($activeModule === 'student_portal' && $activePage === $item['slug']) ? 'active' : '' ?>"
                           href="<?= htmlspecialchars($item['href']) ?>">
                            <i class="fas <?= htmlspecialchars($item['icon']) ?>"></i>
                            <span><?= htmlspecialchars($item['label']) ?></span>
                        </a>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
            <!-- Dashboard -->
            <li class="nav-item">
                <a class="nav-link <?= $activeModule === 'dashboard' ? 'active' : '' ?>"
                   href="<?= BASE_URL ?>/dashboard/index.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>

            <!-- Module Menus -->
            <?php foreach ($visibleModules as $moduleKey => $module): ?>
                <?php
                $isModuleActive = ($activeModule === $moduleKey);
                $collapseId = 'sidebar-' . $moduleKey;
                ?>
                <li class="nav-item">
                    <a class="nav-link sidebar-parent <?= $isModuleActive ? 'active' : '' ?>"
                       data-bs-toggle="collapse"
                       href="#<?= $collapseId ?>"
                       role="button"
                       aria-expanded="<?= $isModuleActive ? 'true' : 'false' ?>"
                       aria-controls="<?= $collapseId ?>">
                        <i class="fas <?= htmlspecialchars($module['icon']) ?>"></i>
                        <span><?= htmlspecialchars($module['label']) ?></span>
                        <i class="fas fa-chevron-down ms-auto sidebar-chevron"></i>
                    </a>
                    <div class="collapse <?= $isModuleActive ? 'show' : '' ?>" id="<?= $collapseId ?>">
                        <ul class="nav flex-column sidebar-submenu">
                            <li class="nav-item">
                                <a class="nav-link sidebar-sub overview-link <?= ($isModuleActive && $activePage === '') ? 'active' : '' ?>"
                                   href="<?= BASE_URL ?>/modules/<?= $moduleKey ?>/index.php">
                                    <i class="fas fa-th-large"></i>
                                    <span>Overview</span>
                                </a>
                            </li>
                            <?php foreach ($module['pages'] as $page): ?>
                                <?php $isPageActive = ($isModuleActive && $activePage === $page['slug']); ?>
                                <li class="nav-item">
                                    <a class="nav-link sidebar-sub <?= $isPageActive ? 'active' : '' ?>"
                                       href="<?= BASE_URL ?>/modules/<?= $moduleKey ?>/pages/<?= $page['slug'] ?>.php">
                                        <i class="far fa-square"></i>
                                        <span><?= htmlspecialchars($page['title']) ?></span>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </li>
            <?php endforeach; ?>
            <?php endif; ?>
        </ul>
    </nav>

    <!-- Sidebar Footer -->
    <div class="sidebar-footer">
        <div class="sidebar-footer-links">
            <a href="#" class="sidebar-footer-link">
                <i class="fas fa-user-circle"></i>
                <span>My Profile</span>
            </a>
            <a href="#" class="sidebar-footer-link">
                <i class="fas fa-cog"></i>
                <span>Settings</span>
            </a>
            <a href="<?= BASE_URL ?>/login/logout.php" class="sidebar-footer-link sidebar-footer-logout">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
        <a href="#" class="sidebar-support-btn">
            <i class="fas fa-headset me-2"></i>Support Center
        </a>
    </div>

</aside>

<!-- Sidebar overlay for mobile -->
<div class="sidebar-overlay" id="sidebarOverlay"></div>
