<?php
/**
 * SMS 2 - Sidebar Navigation
 * Expects: optional $activeModule (string), optional $activePage (string)
 */
if (!isset($MODULES)) {
    require_once __DIR__ . '/../config/config.php';
}
require_once __DIR__ . '/authentication.php';
require_once __DIR__ . '/nav-icons.php';

$activeModule = $activeModule ?? '';
$activePage   = $activePage ?? '';
$isStudentPortal = getCurrentUserRoleKey() === 'student';
$visibleModules = getVisibleModules($MODULES);
$studentNavItems = [
    ['slug' => 'my-profile', 'href' => BASE_URL . '/modules/student-portal/pages/my-profile.php', 'icon' => 'fa-user', 'label' => 'My Profile'],
    ['slug' => 'student-id', 'href' => BASE_URL . '/modules/student-portal/pages/student-id.php', 'icon' => 'fa-id-card', 'label' => 'Student ID'],
    ['slug' => 'account-balance', 'href' => BASE_URL . '/modules/student-portal/pages/account-balance.php', 'icon' => 'fa-wallet', 'label' => 'Account Balance'],
    ['slug' => 'class-schedule', 'href' => BASE_URL . '/modules/student-portal/pages/class-schedule.php', 'icon' => 'fa-calendar-alt', 'label' => 'Class Schedule'],
    ['slug' => 'academic-records', 'href' => BASE_URL . '/modules/student-portal/pages/academic-records.php', 'icon' => 'fa-file-alt', 'label' => 'Academic Records'],
    ['slug' => 'subjects-professors', 'href' => BASE_URL . '/modules/student-portal/pages/subjects-professors.php', 'icon' => 'fa-chalkboard-teacher', 'label' => 'Subject & Professors'],
    ['slug' => 'payment-history', 'href' => BASE_URL . '/modules/student-portal/pages/payment-history.php', 'icon' => 'fa-receipt', 'label' => 'Payment History'],
    ['slug' => 'research-proposal-submission', 'href' => BASE_URL . '/modules/student-portal/pages/research-proposal-submission.php', 'icon' => 'fa-flask', 'label' => 'Research Proposal'],
    ['slug' => 'submit-documents', 'href' => BASE_URL . '/modules/student-portal/pages/submit-documents.php', 'icon' => 'fa-cloud-upload-alt', 'label' => 'Submit Documents'],
];
?>
<aside class="sms-sidebar" id="smsSidebar" aria-label="Main navigation">
    <nav class="sidebar-nav">
        <ul class="nav flex-column">
            <?php if ($isStudentPortal): ?>
                <?php foreach ($studentNavItems as $item): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= ($activeModule === 'student_portal' && $activePage === $item['slug']) ? 'active' : '' ?>"
                           href="<?= htmlspecialchars($item['href']) ?>"
                           data-title="<?= htmlspecialchars($item['label']) ?>"
                           title="<?= htmlspecialchars($item['label']) ?>">
                            <i class="fas <?= htmlspecialchars($item['icon']) ?>" aria-hidden="true"></i>
                            <span><?= htmlspecialchars($item['label']) ?></span>
                        </a>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
            <!-- Dashboard -->
            <li class="nav-item">
                <a class="nav-link <?= $activeModule === 'dashboard' ? 'active' : '' ?>"
                   href="<?= BASE_URL ?>/dashboard/index.php"
                   data-title="Dashboard"
                   title="Dashboard">
                    <i class="fas fa-tachometer-alt" aria-hidden="true"></i>
                    <span>Dashboard</span>
                </a>
            </li>

            <!-- Module Menus -->
            <?php foreach ($visibleModules as $moduleKey => $module): ?>
                <?php
                $isModuleActive = ($activeModule === $moduleKey);
                $collapseId = 'sidebar-' . $moduleKey;
                $overviewUrl = BASE_URL . '/modules/' . $moduleKey . '/index.php';
                ?>
                <li class="nav-item">
                    <a class="nav-link sidebar-parent <?= $isModuleActive ? 'active' : '' ?>"
                       data-bs-toggle="collapse"
                       href="#<?= $collapseId ?>"
                       role="button"
                       aria-expanded="<?= $isModuleActive ? 'true' : 'false' ?>"
                       aria-controls="<?= $collapseId ?>"
                       data-title="<?= htmlspecialchars($module['label']) ?>"
                       data-overview-url="<?= htmlspecialchars($overviewUrl) ?>"
                       title="<?= htmlspecialchars($module['label']) ?>">
                        <i class="fas <?= htmlspecialchars($module['icon']) ?>" aria-hidden="true"></i>
                        <span><?= htmlspecialchars($module['label']) ?></span>
                        <i class="fas fa-chevron-down ms-auto sidebar-chevron" aria-hidden="true"></i>
                    </a>
                    <div class="collapse <?= $isModuleActive ? 'show' : '' ?>" id="<?= $collapseId ?>">
                        <ul class="nav flex-column sidebar-submenu">
                            <li class="nav-item">
                                <a class="nav-link sidebar-sub overview-link <?= ($isModuleActive && $activePage === '') ? 'active' : '' ?>"
                                   href="<?= htmlspecialchars($overviewUrl) ?>">
                                    <i class="fas fa-th-large" aria-hidden="true"></i>
                                    <span>Overview</span>
                                </a>
                            </li>
                            <?php foreach ($module['pages'] as $page): ?>
                                <?php $isPageActive = ($isModuleActive && $activePage === $page['slug']); ?>
                                <li class="nav-item">
                                    <a class="nav-link sidebar-sub <?= $isPageActive ? 'active' : '' ?>"
                                       href="<?= BASE_URL ?>/modules/<?= $moduleKey ?>/pages/<?= $page['slug'] ?>.php">
                                        <i class="fas <?= htmlspecialchars(smsNavPageIcon($page['slug'])) ?>" aria-hidden="true"></i>
                                        <span><?= htmlspecialchars($page['title']) ?></span>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </li>
            <?php endforeach; ?>
            <?php endif; ?>
        </ul>
    </nav>
</aside>

<!-- Sidebar overlay for mobile -->
<div class="sidebar-overlay" id="sidebarOverlay"></div>
