<?php
/**
 * SMS 2 - CRAD Module Process Board
 *
 * Expects $pageTitle and $cradProcess:
 * - description, kicker
 * - metrics: [label, value, icon, tone]
 * - steps: [title, detail]
 * - columns: table headers
 * - records: row arrays matching columns + status + status_class
 * - actions: [label, process, icon, class]
 * - form: [label, type, name, options?]
 * - notice: optional policy text
 */
$processAction = $_GET['process'] ?? '';
$cradProcess = $cradProcess ?? [];
$pageName = $pageTitle ?? 'CRAD Process';
$description = $cradProcess['description'] ?? 'CRAD officer workflow.';
$kicker = $cradProcess['kicker'] ?? 'CRAD Officer Process';
$metrics = $cradProcess['metrics'] ?? [];
$steps = $cradProcess['steps'] ?? [];
$columns = $cradProcess['columns'] ?? ['Reference', 'Item', 'Owner', 'Status'];
$records = $cradProcess['records'] ?? [];
$actions = $cradProcess['actions'] ?? [];
$formFields = $cradProcess['form'] ?? [];
$notice = $cradProcess['notice'] ?? '';

$actionMessages = [];
foreach ($actions as $action) {
    $key = $action['process'] ?? '';
    if ($key !== '') {
        $actionMessages[$key] = ($action['label'] ?? 'Action') . ' recorded for ' . $pageName . '.';
    }
}
$processMessage = $actionMessages[$processAction] ?? '';
?>

<div class="crad-process">
    <header class="crad-process-header">
        <div>
            <span class="crad-process-kicker"><?= htmlspecialchars($kicker) ?></span>
            <h1><?= htmlspecialchars($pageName) ?></h1>
            <p><?= htmlspecialchars($description) ?></p>
        </div>
        <span class="crad-process-badge"><i class="fas fa-diagram-project"></i> Active Process</span>
    </header>

    <?php if ($processMessage !== ''): ?>
        <div class="crad-process-alert" role="alert">
            <i class="fas fa-check-circle"></i>
            <span><?= htmlspecialchars($processMessage) ?></span>
        </div>
    <?php endif; ?>

    <?php if ($metrics): ?>
        <section class="crad-process-metrics" aria-label="Process metrics">
            <?php foreach ($metrics as $metric): ?>
                <article class="crad-process-metric">
                    <div class="crad-process-metric-icon <?= htmlspecialchars($metric['tone'] ?? 'blue') ?>">
                        <i class="fas <?= htmlspecialchars($metric['icon'] ?? 'fa-circle') ?>"></i>
                    </div>
                    <div>
                        <span><?= htmlspecialchars($metric['label']) ?></span>
                        <strong><?= htmlspecialchars((string) $metric['value']) ?></strong>
                    </div>
                </article>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <div class="crad-process-grid">
        <section class="crad-process-card">
            <h2><i class="fas fa-list-ol"></i> Process Flow</h2>
            <ol class="crad-process-steps">
                <?php foreach ($steps as $index => $step): ?>
                    <li>
                        <span class="crad-process-step-num"><?= $index + 1 ?></span>
                        <div>
                            <strong><?= htmlspecialchars($step[0]) ?></strong>
                            <p><?= htmlspecialchars($step[1]) ?></p>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ol>
        </section>

        <section class="crad-process-card">
            <div class="crad-process-card-head">
                <h2><i class="fas fa-table"></i> Queue / Records</h2>
                <label class="crad-process-search">
                    <i class="fas fa-search"></i>
                    <input type="search" id="cradProcessSearch" placeholder="Search records..." aria-label="Search records">
                </label>
            </div>
            <div class="table-responsive">
                <table class="crad-process-table">
                    <thead>
                        <tr>
                            <?php foreach ($columns as $column): ?>
                                <th><?= htmlspecialchars($column) ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody id="cradProcessRows">
                        <?php foreach ($records as $record): ?>
                            <?php
                            $searchBlob = strtolower(implode(' ', array_map('strval', array_diff_key($record, ['status_class' => true]))));
                            $status = $record['status'] ?? '';
                            $statusClass = $record['status_class'] ?? 'review';
                            $fieldKeys = $cradProcess['fields'] ?? array_values(array_diff(array_keys($record), ['status_class']));
                            ?>
                            <tr data-search="<?= htmlspecialchars($searchBlob) ?>">
                                <?php foreach ($fieldKeys as $fieldKey): ?>
                                    <?php if ($fieldKey === 'status'): ?>
                                        <td><span class="crad-process-status <?= htmlspecialchars($statusClass) ?>"><?= htmlspecialchars($status) ?></span></td>
                                    <?php else: ?>
                                        <td><?= htmlspecialchars((string) ($record[$fieldKey] ?? '')) ?></td>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="crad-process-empty" id="cradProcessEmpty" hidden>
                <i class="fas fa-search"></i>
                <strong>No records found</strong>
            </div>
            <?php if ($actions): ?>
                <div class="crad-process-actions">
                    <?php foreach ($actions as $action): ?>
                        <a class="crad-process-btn <?= htmlspecialchars($action['class'] ?? 'ghost') ?>"
                           href="?process=<?= htmlspecialchars(urlencode($action['process'] ?? 'new')) ?>">
                            <i class="fas <?= htmlspecialchars($action['icon'] ?? 'fa-circle') ?>"></i>
                            <?= htmlspecialchars($action['label'] ?? 'Action') ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </div>

    <?php if ($formFields): ?>
        <section class="crad-process-card crad-process-form-card">
            <h2><i class="fas fa-clipboard-list"></i> Process Form</h2>
            <form class="crad-process-form" method="get" action="">
                <input type="hidden" name="process" value="submit">
                <div class="crad-process-form-grid">
                    <?php foreach ($formFields as $field): ?>
                        <label class="crad-process-field">
                            <span><?= htmlspecialchars($field['label']) ?></span>
                            <?php if (($field['type'] ?? 'text') === 'select'): ?>
                                <select name="<?= htmlspecialchars($field['name']) ?>">
                                    <?php foreach (($field['options'] ?? []) as $option): ?>
                                        <option><?= htmlspecialchars($option) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            <?php elseif (($field['type'] ?? '') === 'textarea'): ?>
                                <textarea name="<?= htmlspecialchars($field['name']) ?>" rows="3" placeholder="<?= htmlspecialchars($field['placeholder'] ?? '') ?>"></textarea>
                            <?php else: ?>
                                <input type="<?= htmlspecialchars($field['type'] ?? 'text') ?>"
                                       name="<?= htmlspecialchars($field['name']) ?>"
                                       placeholder="<?= htmlspecialchars($field['placeholder'] ?? '') ?>"
                                       value="<?= htmlspecialchars($field['value'] ?? '') ?>">
                            <?php endif; ?>
                        </label>
                    <?php endforeach; ?>
                </div>
                <div class="crad-process-form-footer">
                    <button type="submit" class="crad-process-btn primary">
                        <i class="fas fa-save"></i> Save Process Entry
                    </button>
                </div>
            </form>
        </section>
    <?php endif; ?>

    <?php if ($notice !== ''): ?>
        <aside class="crad-process-notice">
            <div class="crad-process-notice-icon"><i class="fas fa-info-circle"></i></div>
            <div>
                <h2>Process Policy</h2>
                <p><?= htmlspecialchars($notice) ?></p>
            </div>
        </aside>
    <?php endif; ?>
</div>

<style>
.crad-process {
    --cp-bg: #151719;
    --cp-panel: #101214;
    --cp-line: rgba(148,163,184,0.2);
    --cp-text: #f8fafc;
    --cp-muted: #94a3b8;
    padding: 1rem;
    border: 1px solid rgba(148,163,184,0.12);
    border-radius: 18px;
    background:
        radial-gradient(circle at 88% 0%, rgba(37,99,235,0.1), transparent 26rem),
        var(--cp-bg);
    color: var(--cp-text);
}
.crad-process-header {
    display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem;
    margin-bottom: 1rem;
}
.crad-process-kicker {
    color: #7fa2ff; font-size: 0.68rem; font-weight: 800; letter-spacing: 0.08em; text-transform: uppercase;
}
.crad-process-header h1 { margin: 0.2rem 0 0; color: #fff; font-size: 1.2rem; font-weight: 800; }
.crad-process-header p { margin: 0.35rem 0 0; color: var(--cp-muted); font-size: 0.84rem; max-width: 54rem; }
.crad-process-badge {
    display: inline-flex; align-items: center; gap: 0.45rem; padding: 0.45rem 0.8rem;
    border: 1px solid rgba(99,102,241,0.35); border-radius: 999px;
    background: rgba(79,70,229,0.12); color: #c7d2fe; font-size: 0.72rem; font-weight: 700; white-space: nowrap;
}
.crad-process-alert {
    display: flex; align-items: center; gap: 0.65rem; margin-bottom: 1rem; padding: 0.85rem 1rem;
    border: 1px solid rgba(16,185,129,0.28); border-radius: 12px;
    background: rgba(16,185,129,0.12); color: #6ee7b7; font-size: 0.86rem; font-weight: 600;
}
.crad-process-metrics {
    display: grid; grid-template-columns: repeat(4, minmax(0,1fr)); gap: 0.85rem; margin-bottom: 1rem;
}
.crad-process-metric {
    display: flex; align-items: center; gap: 0.85rem; min-height: 82px; padding: 0.9rem 1rem;
    border: 1px solid var(--cp-line); border-radius: 14px;
    background: linear-gradient(145deg, rgba(20,23,26,0.96), rgba(8,10,12,0.96));
}
.crad-process-metric span { display: block; color: var(--cp-muted); font-size: 0.72rem; font-weight: 700; }
.crad-process-metric strong { display: block; margin-top: 0.15rem; color: #fff; font-size: 1.45rem; }
.crad-process-metric-icon {
    width: 42px; height: 42px; display: grid; place-items: center; border-radius: 11px; font-size: 1rem;
}
.crad-process-metric-icon.blue { color: #8da9ff; background: rgba(62,92,190,0.15); }
.crad-process-metric-icon.green { color: #34d399; background: rgba(16,185,129,0.13); }
.crad-process-metric-icon.amber { color: #fbbf24; background: rgba(245,158,11,0.14); }
.crad-process-metric-icon.purple { color: #c4b5fd; background: rgba(139,92,246,0.14); }
.crad-process-grid {
    display: grid; grid-template-columns: 0.9fr 1.35fr; gap: 1rem; margin-bottom: 1rem;
}
.crad-process-card {
    padding: 1rem 1.1rem; border: 1px solid var(--cp-line); border-radius: 14px;
    background: rgba(12,14,16,0.84);
}
.crad-process-card h2 {
    margin: 0 0 0.9rem; color: #fff; font-size: 0.92rem; font-weight: 800;
    display: flex; align-items: center; gap: 0.5rem;
}
.crad-process-card h2 i { color: #7fa2ff; }
.crad-process-card-head {
    display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; margin-bottom: 0.75rem;
}
.crad-process-card-head h2 { margin: 0; }
.crad-process-search {
    width: min(240px, 100%); display: flex; align-items: center; gap: 0.5rem;
    padding: 0.45rem 0.7rem; border: 1px solid var(--cp-line); border-radius: 8px; background: #232629; color: var(--cp-muted);
}
.crad-process-search input {
    width: 100%; border: 0; outline: 0; background: transparent; color: #fff; font-size: 0.78rem;
}
.crad-process-steps { list-style: none; margin: 0; padding: 0; display: grid; gap: 0.75rem; }
.crad-process-steps li { display: flex; gap: 0.75rem; align-items: flex-start; }
.crad-process-step-num {
    width: 28px; height: 28px; flex: 0 0 auto; display: grid; place-items: center;
    border-radius: 8px; background: rgba(37,99,235,0.18); color: #93c5fd; font-size: 0.75rem; font-weight: 800;
}
.crad-process-steps strong { display: block; color: #f1f5f9; font-size: 0.84rem; }
.crad-process-steps p { margin: 0.2rem 0 0; color: var(--cp-muted); font-size: 0.74rem; line-height: 1.4; }
.crad-process-table { width: 100%; border-collapse: collapse; font-size: 0.78rem; }
.crad-process-table th, .crad-process-table td {
    padding: 0.7rem 0.55rem; border-bottom: 1px solid var(--cp-line); text-align: left; vertical-align: middle;
}
.crad-process-table th { color: #9db0d0; font-size: 0.68rem; text-transform: uppercase; letter-spacing: 0.04em; }
.crad-process-table td { color: #e2e8f0; }
.crad-process-status {
    display: inline-flex; padding: 0.22rem 0.6rem; border-radius: 999px; font-size: 0.66rem; font-weight: 800;
}
.crad-process-status.approved,
.crad-process-status.assigned,
.crad-process-status.published,
.crad-process-status.archived { color: #6ee7b7; border: 1px solid rgba(16,185,129,0.25); background: rgba(16,185,129,0.12); }
.crad-process-status.review,
.crad-process-status.pending,
.crad-process-status.evaluation { color: #fbbf24; border: 1px solid rgba(245,158,11,0.25); background: rgba(245,158,11,0.1); }
.crad-process-status.open,
.crad-process-status.active { color: #93c5fd; border: 1px solid rgba(59,130,246,0.28); background: rgba(59,130,246,0.12); }
.crad-process-status.denied { color: #fca5a5; border: 1px solid rgba(239,68,68,0.25); background: rgba(239,68,68,0.1); }
.crad-process-actions {
    display: flex; flex-wrap: wrap; gap: 0.55rem; margin-top: 0.95rem; padding-top: 0.95rem;
    border-top: 1px solid var(--cp-line);
}
.crad-process-btn {
    display: inline-flex; align-items: center; gap: 0.45rem; min-height: 36px; padding: 0.45rem 0.8rem;
    border-radius: 8px; border: 1px solid var(--cp-line); text-decoration: none;
    font-size: 0.74rem; font-weight: 700; color: #d8dee8; background: #22262a;
}
.crad-process-btn:hover { border-color: #5478df; color: #fff; background: #29334a; }
.crad-process-btn.primary { border-color: transparent; background: #2563eb; color: #fff; }
.crad-process-btn.primary:hover { background: #1d4ed8; color: #fff; }
.crad-process-empty {
    display: grid; place-items: center; gap: 0.35rem; padding: 1.5rem; color: var(--cp-muted);
}
.crad-process-form-card { margin-bottom: 1rem; }
.crad-process-form-grid {
    display: grid; grid-template-columns: repeat(3, minmax(0,1fr)); gap: 0.85rem;
}
.crad-process-field { display: grid; gap: 0.35rem; }
.crad-process-field span { color: #cbd5e1; font-size: 0.74rem; font-weight: 700; }
.crad-process-field input,
.crad-process-field select,
.crad-process-field textarea {
    width: 100%; padding: 0.6rem 0.75rem; border: 1px solid var(--cp-line); border-radius: 8px;
    background: #1a1e23; color: #fff; font-size: 0.82rem;
}
.crad-process-field textarea { resize: vertical; min-height: 84px; }
.crad-process-form-footer { margin-top: 1rem; }
.crad-process-notice {
    display: flex; gap: 0.85rem; padding: 1rem 1.1rem;
    border: 1px solid rgba(245,158,11,0.22); border-radius: 14px;
    background: linear-gradient(90deg, rgba(120,74,8,0.2), rgba(77,46,7,0.1)); color: #f4c768;
}
.crad-process-notice-icon {
    width: 36px; height: 36px; flex: 0 0 auto; display: grid; place-items: center;
    border-radius: 50%; background: #f59e0b; color: #fff;
}
.crad-process-notice h2 { margin: 0; color: #fbbf24; font-size: 0.86rem; font-weight: 800; }
.crad-process-notice p { margin: 0.25rem 0 0; color: #d7b977; font-size: 0.76rem; line-height: 1.45; }

[data-theme="light"] .crad-process {
    --cp-bg: #f4f7fc;
    --cp-panel: #ffffff;
    --cp-line: #d7e0ef;
    --cp-text: #0f172a;
    --cp-muted: #64748b;
    background:
        radial-gradient(circle at 88% 0%, rgba(37,99,235,0.08), transparent 24rem),
        #eef3fb;
    border-color: #d9e3f2;
}
[data-theme="light"] .crad-process-header h1,
[data-theme="light"] .crad-process-card h2,
[data-theme="light"] .crad-process-metric strong,
[data-theme="light"] .crad-process-steps strong,
[data-theme="light"] .crad-process-table td { color: #0f172a; }
[data-theme="light"] .crad-process-metric,
[data-theme="light"] .crad-process-card {
    background: #fff; box-shadow: 0 8px 22px rgba(15,33,88,0.06);
}
[data-theme="light"] .crad-process-search,
[data-theme="light"] .crad-process-btn,
[data-theme="light"] .crad-process-field input,
[data-theme="light"] .crad-process-field select,
[data-theme="light"] .crad-process-field textarea {
    background: #fff; color: #0f172a; border-color: #d7e0ef;
}
[data-theme="light"] .crad-process-btn.primary { background: #2563eb; color: #fff; border-color: transparent; }
[data-theme="light"] .crad-process-badge { background: #eef2ff; color: #3730a3; border-color: #c7d2fe; }

@media (max-width: 991.98px) {
    .crad-process-metrics { grid-template-columns: repeat(2, minmax(0,1fr)); }
    .crad-process-grid,
    .crad-process-form-grid { grid-template-columns: 1fr; }
}
@media (max-width: 575.98px) {
    .crad-process-metrics { grid-template-columns: 1fr; }
    .crad-process-header { flex-direction: column; }
    .crad-process-card-head { flex-direction: column; align-items: stretch; }
    .crad-process-search { width: 100%; }
}
</style>

<script>
(function () {
    var search = document.getElementById('cradProcessSearch');
    var rows = Array.prototype.slice.call(document.querySelectorAll('#cradProcessRows tr'));
    var empty = document.getElementById('cradProcessEmpty');
    if (!search) return;
    search.addEventListener('input', function () {
        var q = search.value.trim().toLowerCase();
        var visible = 0;
        rows.forEach(function (row) {
            var show = !q || (row.getAttribute('data-search') || '').indexOf(q) !== -1;
            row.hidden = !show;
            if (show) visible += 1;
        });
        if (empty) empty.hidden = visible > 0;
    });
})();
</script>
