<?php
/**
 * SMS 2 - Top Navigation Bar
 */
require_once __DIR__ . '/authentication.php';
?>
<nav class="navbar navbar-expand-lg navbar-dark sms-navbar fixed-top shadow-sm">
    <div class="container-fluid">
        <button class="btn btn-link text-white sidebar-toggle me-1 me-sm-2 p-2" type="button" id="sidebarToggle" aria-label="Toggle sidebar">
            <i class="fas fa-bars fa-lg"></i>
        </button>

        <a class="navbar-brand d-flex align-items-center" href="<?= BASE_URL ?>/dashboard/index.php">
            <i class="fas fa-graduation-cap me-2"></i>
            <span class="d-none d-sm-inline"><?= htmlspecialchars(APP_SHORT_NAME) ?></span>
        </a>

        <div class="ms-auto d-flex align-items-center gap-2 gap-md-3">
            <!-- Notifications -->
            <div class="dropdown">
                <button class="btn btn-link text-white position-relative" type="button" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Notifications">
                    <i class="fas fa-bell"></i>
                    <span class="position-absolute badge rounded-pill bg-danger notification-badge" style="top:2px;right:0;transform:translate(40%,-20%);">3</span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end shadow">
                    <li><h6 class="dropdown-header">Notifications</h6></li>
                    <li><a class="dropdown-item" href="#"><i class="fas fa-info-circle text-primary me-2"></i>Welcome to SMS 2</a></li>
                    <li><a class="dropdown-item" href="#"><i class="fas fa-user-plus text-success me-2"></i>New enrollment pending</a></li>
                    <li><a class="dropdown-item" href="#"><i class="fas fa-file-alt text-warning me-2"></i>Document request received</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-center text-primary" href="#">View all</a></li>
                </ul>
            </div>

            <!-- User Profile -->
            <div class="dropdown">
                <button class="btn btn-link text-white text-decoration-none dropdown-toggle d-flex align-items-center" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <div class="user-avatar me-2">
                        <i class="fas fa-user-circle fa-lg"></i>
                    </div>
                    <span class="d-none d-md-inline"><?= htmlspecialchars(getCurrentUserName()) ?></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end shadow">
                    <li><h6 class="dropdown-header"><?= htmlspecialchars(getCurrentUserRole()) ?></h6></li>
                    <li><a class="dropdown-item" href="#"><i class="fas fa-user me-2"></i>My Profile</a></li>
                    <li><a class="dropdown-item" href="#"><i class="fas fa-cog me-2"></i>Settings</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>/login/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>
