<?php
/**
 * SMS 2 - Top Navigation Bar
 */
require_once __DIR__ . '/authentication.php';
if (!isset($MODULES)) {
    require_once __DIR__ . '/../config/config.php';
}
$visibleModulesNav = getVisibleModules($MODULES);
?>
<nav class="navbar navbar-expand-lg navbar-dark sms-navbar fixed-top">
    <div class="container-fluid navbar-inner">

        <!-- Left: Toggle + Brand -->
        <div class="navbar-left d-flex align-items-center gap-2">
            <button class="btn btn-link text-white sidebar-toggle p-2" type="button" id="sidebarToggle" aria-label="Toggle sidebar">
                <i class="fas fa-bars"></i>
            </button>
            <a class="navbar-brand d-flex align-items-center gap-2" href="<?= BASE_URL ?>/dashboard/index.php">
                <div class="brand-logo-frame">
                    <img class="navbar-brand-logo" src="<?= BASE_URL ?>/images/bestlink.png" alt="Bestlink College logo">
                </div>
                <span class="d-none d-sm-inline"><?= htmlspecialchars(APP_SHORT_NAME) ?></span>
            </a>
        </div>

        <!-- Center: Global Search -->
        <div class="navbar-center">
            <div class="navbar-search position-relative">
                <i class="fas fa-search navbar-search-icon"></i>
                <input type="text" id="globalSearch" class="form-control navbar-search-input"
                       placeholder="Search modules and pages…"
                       autocomplete="off"
                       aria-label="Search modules and pages"
                       aria-haspopup="listbox"
                       aria-expanded="false">
                <button class="navbar-search-clear d-none" id="globalSearchClear" type="button" aria-label="Clear search">
                    <i class="fas fa-times"></i>
                </button>
                <div class="search-kbd-hint" aria-hidden="true">
                    <kbd>Ctrl</kbd><kbd>K</kbd>
                </div>
                <!-- Results dropdown -->
                <div class="navbar-search-dropdown" id="searchDropdown" role="listbox" aria-label="Search results">
                    <div class="search-empty" id="searchEmpty">
                        <i class="fas fa-search-minus"></i>
                        <span>No results found</span>
                    </div>
                    <ul class="search-results-list" id="searchResultsList"></ul>
                </div>
            </div>
        </div>

        <!-- Right: Messages + Notifications + User -->
        <div class="navbar-right d-flex align-items-center gap-2 gap-md-3">

<?php
/* ── Role-specific messages & notifications ───────────────── */
$roleKey = getCurrentUserRoleKey();

$roleMessages = [
    'admin' => [
        ['avatar'=>'R','name'=>'Registrar Office',   'text'=>'New document request submitted...',    'time'=>'2 mins ago'],
        ['avatar'=>'F','name'=>'Finance Office',      'text'=>'Monthly collection report ready...',  'time'=>'1 hour ago'],
    ],
    'registrar' => [
        ['avatar'=>'S','name'=>'Student Affairs',     'text'=>'Transfer applicant documents sent...', 'time'=>'5 mins ago'],
        ['avatar'=>'A','name'=>'Admin',               'text'=>'Records archiving scheduled...',       'time'=>'3 hours ago'],
    ],
    'finance' => [
        ['avatar'=>'A','name'=>'Admin',               'text'=>'Quarter-end audit reminder...',        'time'=>'10 mins ago'],
        ['avatar'=>'R','name'=>'Registrar Office',    'text'=>'Clearance request for 12 students...', 'time'=>'2 hours ago'],
    ],
    'hr' => [
        ['avatar'=>'A','name'=>'Admin',               'text'=>'Faculty evaluation period starts...',  'time'=>'1 hour ago'],
        ['avatar'=>'D','name'=>'Department Head',     'text'=>'New leave application pending...',     'time'=>'4 hours ago'],
    ],
    'it_office' => [
        ['avatar'=>'A','name'=>'Admin',               'text'=>'LMS server maintenance tonight...',    'time'=>'30 mins ago'],
        ['avatar'=>'S','name'=>'Support Desk',        'text'=>'2 new IT support tickets filed...',   'time'=>'2 hours ago'],
    ],
    'osa' => [
        ['avatar'=>'C','name'=>'Club President',      'text'=>'Budget request for JPCS event...',    'time'=>'15 mins ago'],
        ['avatar'=>'A','name'=>'Admin',               'text'=>'OSA annual report due next week...',  'time'=>'1 hour ago'],
    ],
    'qa' => [
        ['avatar'=>'A','name'=>'Admin',               'text'=>'Accreditation visit scheduled...',    'time'=>'1 hour ago'],
        ['avatar'=>'P','name'=>'Program Chair',       'text'=>'Self-assessment report draft sent...','time'=>'3 hours ago'],
    ],
    'crad_officer' => [
        ['avatar'=>'A','name'=>'Admin',               'text'=>'Research grant deadline reminder...',  'time'=>'20 mins ago'],
        ['avatar'=>'P','name'=>'Prof. Santos',        'text'=>'Research proposal submitted...',       'time'=>'5 hours ago'],
    ],
    'student' => [
        ['avatar'=>'R','name'=>'Registrar Office',    'text'=>'Your document request is ready...',   'time'=>'1 hour ago'],
        ['avatar'=>'P','name'=>'Prof. Reyes',         'text'=>'Quiz 2 results have been posted...',  'time'=>'3 hours ago'],
    ],
];

$roleNotifications = [
    'admin' => [
        ['icon'=>'fa-user-plus',    'color'=>'text-success', 'text'=>'47 pending enrollment requests'],
        ['icon'=>'fa-exclamation-circle','color'=>'text-warning','text'=>'System backup due tonight'],
        ['icon'=>'fa-file-alt',     'color'=>'text-primary', 'text'=>'Monthly report generated'],
    ],
    'registrar' => [
        ['icon'=>'fa-file-alt',     'color'=>'text-warning', 'text'=>'28 document requests pending'],
        ['icon'=>'fa-user-check',   'color'=>'text-success', 'text'=>'12 enrollments validated today'],
        ['icon'=>'fa-clock',        'color'=>'text-info',    'text'=>'Records archiving at 11 PM'],
    ],
    'finance' => [
        ['icon'=>'fa-peso-sign',    'color'=>'text-success', 'text'=>'Collections today: ₱38,500'],
        ['icon'=>'fa-exclamation',  'color'=>'text-warning', 'text'=>'23 overdue accounts flagged'],
        ['icon'=>'fa-file-invoice', 'color'=>'text-primary', 'text'=>'134 payments pending posting'],
    ],
    'hr' => [
        ['icon'=>'fa-calendar-times','color'=>'text-warning','text'=>'5 faculty on leave today'],
        ['icon'=>'fa-star',         'color'=>'text-success', 'text'=>'Evaluation period now open'],
        ['icon'=>'fa-clock',        'color'=>'text-info',    'text'=>'8 leave requests pending approval'],
    ],
    'it_office' => [
        ['icon'=>'fa-laptop',       'color'=>'text-primary', 'text'=>'148 active LMS classes today'],
        ['icon'=>'fa-tasks',        'color'=>'text-warning', 'text'=>'312 pending student submissions'],
        ['icon'=>'fa-server',       'color'=>'text-info',    'text'=>'Server maintenance at midnight'],
    ],
    'osa' => [
        ['icon'=>'fa-calendar-check','color'=>'text-success','text'=>'9 events scheduled this month'],
        ['icon'=>'fa-hand-holding-usd','color'=>'text-warning','text'=>'6 budget requests pending'],
        ['icon'=>'fa-users',        'color'=>'text-primary', 'text'=>'3 new club registrations'],
    ],
    'qa' => [
        ['icon'=>'fa-award',        'color'=>'text-success', 'text'=>'Accreditation visit: Sep 2026'],
        ['icon'=>'fa-exclamation-circle','color'=>'text-warning','text'=>'7 non-conformities to resolve'],
        ['icon'=>'fa-clipboard-check','color'=>'text-primary','text'=>'142 compliance items tracked'],
    ],
    'crad_officer' => [
        ['icon'=>'fa-flask',        'color'=>'text-primary', 'text'=>'18 active research projects'],
        ['icon'=>'fa-hand-holding-usd','color'=>'text-warning','text'=>'Grant deadline in 5 days'],
        ['icon'=>'fa-book-open',    'color'=>'text-success', 'text'=>'9 publications this year'],
    ],
    'student' => [
        ['icon'=>'fa-book-open',    'color'=>'text-primary', 'text'=>'Quiz 2 results are now available'],
        ['icon'=>'fa-calendar-alt', 'color'=>'text-warning', 'text'=>'Prelim exams start July 21'],
        ['icon'=>'fa-peso-sign',    'color'=>'text-danger',  'text'=>'Balance due: ₱8,450.00'],
    ],
];

$messages      = $roleMessages[$roleKey]      ?? $roleMessages['admin'];
$notifications = $roleNotifications[$roleKey] ?? $roleNotifications['admin'];
$msgCount      = count($messages);
$notifCount    = count($notifications);
?>

            <!-- Messages -->
            <div class="dropdown">
                <button class="btn btn-link text-white position-relative" type="button" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Messages">
                    <i class="fas fa-envelope"></i>
                    <span class="position-absolute badge rounded-pill bg-success notification-badge" style="top:2px;right:-2px;transform:none;"><?= $msgCount ?></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end shadow" style="min-width:290px;">
                    <li><h6 class="dropdown-header"><i class="fas fa-envelope me-2"></i>Messages</h6></li>
                    <?php foreach ($messages as $i => $msg): ?>
                        <?php if ($i > 0): ?><li><hr class="dropdown-divider my-1"></li><?php endif; ?>
                        <li>
                            <a class="dropdown-item d-flex align-items-start gap-2 py-2" href="#">
                                <div class="navbar-msg-avatar"><?= htmlspecialchars($msg['avatar']) ?></div>
                                <div class="navbar-msg-body">
                                    <div class="navbar-msg-name"><?= htmlspecialchars($msg['name']) ?></div>
                                    <div class="navbar-msg-text"><?= htmlspecialchars($msg['text']) ?></div>
                                    <div class="navbar-msg-time"><?= htmlspecialchars($msg['time']) ?></div>
                                </div>
                            </a>
                        </li>
                    <?php endforeach; ?>
                    <li><hr class="dropdown-divider my-1"></li>
                    <li><a class="dropdown-item text-center text-primary py-2" href="#"><i class="fas fa-envelope-open me-1"></i>View all messages</a></li>
                </ul>
            </div>

            <!-- Help -->
            <div class="dropdown">
                <button class="btn btn-link position-relative" type="button" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Help">
                    <i class="fas fa-question-circle"></i>
                </button>
                <ul class="dropdown-menu dropdown-menu-end shadow" style="min-width:220px;">
                    <li><h6 class="dropdown-header"><i class="fas fa-question-circle me-2"></i>Help & Support</h6></li>
                    <li><a class="dropdown-item" href="#"><i class="fas fa-book me-2 text-primary"></i>User Guide</a></li>
                    <li><a class="dropdown-item" href="#"><i class="fas fa-video me-2 text-success"></i>Video Tutorials</a></li>
                    <li><a class="dropdown-item" href="#"><i class="fas fa-headset me-2 text-warning"></i>Contact Support</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="#"><i class="fas fa-info-circle me-2 text-info"></i>About SMS 2 v1.0.0</a></li>
                </ul>
            </div>

            <!-- Notifications -->
            <div class="dropdown">
                <button class="btn btn-link text-white position-relative" type="button" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Notifications">
                    <i class="fas fa-bell"></i>
                    <span class="position-absolute badge rounded-pill bg-danger notification-badge" style="top:2px;right:-2px;transform:none;"><?= $notifCount ?></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end shadow" style="min-width:280px;">
                    <li><h6 class="dropdown-header"><i class="fas fa-bell me-2"></i>Notifications</h6></li>
                    <?php foreach ($notifications as $notif): ?>
                        <li>
                            <a class="dropdown-item d-flex align-items-center gap-2 py-2" href="#">
                                <i class="fas <?= htmlspecialchars($notif['icon']) ?> <?= htmlspecialchars($notif['color']) ?> fa-fw"></i>
                                <span style="font-size:0.83rem;"><?= htmlspecialchars($notif['text']) ?></span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-center text-primary" href="#">View all notifications</a></li>
                </ul>
            </div>

            <!-- User Profile (display only — not clickable) -->
            <div class="d-flex align-items-center gap-2 navbar-user-display">
                <div class="navbar-user-avatar">
                    <?= strtoupper(substr(getCurrentUserName(), 0, 1)) ?>
                </div>
                <div class="navbar-user-info d-none d-md-flex flex-column text-start">
                    <span class="navbar-user-name"><?= htmlspecialchars(getCurrentUserName()) ?></span>
                    <span class="navbar-user-role">
                        <?php if (getCurrentUserRoleKey() === 'student'): ?>
                            Student #<?= htmlspecialchars($_SESSION['student_id'] ?? 'S230000001') ?>
                        <?php else: ?>
                            <?= htmlspecialchars(getCurrentUserRole()) ?>
                        <?php endif; ?>
                    </span>
                </div>
            </div>
        </div>

    </div>
</nav>

<script>
/* Global Search Index — built from PHP $MODULES visible to current user */
window.SMS2_SEARCH_INDEX = (function() {
    var base = '<?= BASE_URL ?>';
    var items = [];
    <?php foreach ($visibleModulesNav as $moduleKey => $module): ?>
    items.push({type:'module',label:<?= json_encode($module['label']) ?>,icon:<?= json_encode($module['icon']) ?>,url:base+'/modules/<?= $moduleKey ?>/index.php',keywords:<?= json_encode(strtolower($module['label'])) ?>});
    <?php foreach ($module['pages'] as $page): ?>
    items.push({type:'page',label:<?= json_encode($page['title']) ?>,parent:<?= json_encode($module['label']) ?>,icon:<?= json_encode($module['icon']) ?>,url:base+'/modules/<?= $moduleKey ?>/pages/<?= $page['slug'] ?>.php',keywords:<?= json_encode(strtolower($page['title'].' '.$module['label'])) ?>});
    <?php endforeach; ?>
    <?php endforeach; ?>
    return items;
})();
</script>
