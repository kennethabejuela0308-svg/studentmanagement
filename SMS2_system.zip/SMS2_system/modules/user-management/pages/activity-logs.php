<?php
/**
 * SMS 2 – User Management – Activity Logs
 */
require_once __DIR__ . '/../../../config/config.php';

$pageTitle    = 'Activity Logs';
$activeModule = 'user-management';
$activePage   = 'activity-logs';
$breadcrumbs  = [
    ['label' => 'User Management', 'url' => BASE_URL . '/modules/user-management/index.php'],
    ['label' => 'Activity Logs',   'url' => null],
];

require_once __DIR__ . '/../../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../../includes/layout-start.php';
requireSuperAdmin();

/* ── Demo log data (Phase 1) ───────────────────────────────── */
$logs = [
    ['id'=>1,  'user'=>'Super Admin',       'role'=>'admin',      'action'=>'login',  'detail'=>'Logged in successfully',                        'module'=>'System',          'ip'=>'192.168.1.1',  'time'=>'Jul 13, 2026 08:02:14'],
    ['id'=>2,  'user'=>'Registrar',         'role'=>'registrar',  'action'=>'login',  'detail'=>'Logged in successfully',                        'module'=>'System',          'ip'=>'192.168.1.10', 'time'=>'Jul 13, 2026 07:55:03'],
    ['id'=>3,  'user'=>'Super Admin',       'role'=>'admin',      'action'=>'view',   'detail'=>'Viewed User Accounts page',                     'module'=>'User Management', 'ip'=>'192.168.1.1',  'time'=>'Jul 13, 2026 08:03:22'],
    ['id'=>4,  'user'=>'Finance',           'role'=>'finance',    'action'=>'login',  'detail'=>'Logged in successfully',                        'module'=>'System',          'ip'=>'192.168.1.22', 'time'=>'Jul 13, 2026 09:10:00'],
    ['id'=>5,  'user'=>'Registrar',         'role'=>'registrar',  'action'=>'update', 'detail'=>'Updated student record S230000001',              'module'=>'Registrar',       'ip'=>'192.168.1.10', 'time'=>'Jul 13, 2026 09:15:44'],
    ['id'=>6,  'user'=>'Super Admin',       'role'=>'admin',      'action'=>'create', 'detail'=>'Created user account: testuser',                'module'=>'User Management', 'ip'=>'192.168.1.1',  'time'=>'Jul 12, 2026 14:05:10'],
    ['id'=>7,  'user'=>'IT Officer',        'role'=>'it_office',  'action'=>'update', 'detail'=>'Published LMS lesson: Week 3 Materials',        'module'=>'LMS',             'ip'=>'192.168.1.35', 'time'=>'Jul 12, 2026 14:30:55'],
    ['id'=>8,  'user'=>'Finance',           'role'=>'finance',    'action'=>'view',   'detail'=>'Viewed collection report – Jul 2026',           'module'=>'Payment',         'ip'=>'192.168.1.22', 'time'=>'Jul 12, 2026 11:00:00'],
    ['id'=>9,  'user'=>'Super Admin',       'role'=>'admin',      'action'=>'delete', 'detail'=>'Removed user account: testuser2',               'module'=>'User Management', 'ip'=>'192.168.1.1',  'time'=>'Jul 11, 2026 16:20:30'],
    ['id'=>10, 'user'=>'HR',                'role'=>'hr',         'action'=>'update', 'detail'=>'Approved leave request – Prof. Santos',         'module'=>'Faculty',         'ip'=>'192.168.1.18', 'time'=>'Jul 11, 2026 11:45:00'],
    ['id'=>11, 'user'=>'Quality Assurance', 'role'=>'qa',         'action'=>'create', 'detail'=>'Added compliance evidence – Criterion 4.2',     'module'=>'Accreditation',   'ip'=>'192.168.1.50', 'time'=>'Jul 10, 2026 10:00:00'],
    ['id'=>12, 'user'=>'Registrar',         'role'=>'registrar',  'action'=>'export', 'detail'=>'Exported enrollment report – AY 2025-2026',     'module'=>'Enrollment',      'ip'=>'192.168.1.10', 'time'=>'Jul 10, 2026 09:30:00'],
    ['id'=>13, 'user'=>'CRAD Officer',      'role'=>'crad',       'action'=>'create', 'detail'=>'Submitted research proposal: AI in Education',  'module'=>'CRAD',            'ip'=>'192.168.1.60', 'time'=>'Jul 9, 2026 14:00:00'],
    ['id'=>14, 'user'=>'Student Affairs',   'role'=>'osa',        'action'=>'update', 'detail'=>'Approved budget request: IT Club – Q3 2026',   'module'=>'Co-Curricular',   'ip'=>'192.168.1.45', 'time'=>'Jul 8, 2026 15:20:00'],
    ['id'=>15, 'user'=>'Finance',           'role'=>'finance',    'action'=>'logout', 'detail'=>'Logged out',                                    'module'=>'System',          'ip'=>'192.168.1.22', 'time'=>'Jul 8, 2026 17:00:00'],
];

$actionIcons = [
    'login'  => 'fa-sign-in-alt',
    'logout' => 'fa-sign-out-alt',
    'create' => 'fa-plus-circle',
    'update' => 'fa-pen',
    'delete' => 'fa-trash-alt',
    'view'   => 'fa-eye',
    'export' => 'fa-file-export',
];

$total   = count($logs);
$logins  = count(array_filter($logs, fn($l) => $l['action'] === 'login'));
$changes = count(array_filter($logs, fn($l) => in_array($l['action'], ['create','update','delete'])));
$exports = count(array_filter($logs, fn($l) => $l['action'] === 'export'));
?>

<link href="<?= BASE_URL ?>/modules/user-management/assets/css/user-management.css" rel="stylesheet">

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="page-header d-flex justify-content-between align-items-start flex-wrap gap-2">
    <div>
        <h1><i class="fas fa-history text-sms-primary me-2"></i>Activity Logs</h1>
        <p>Audit trail of all user actions, system events, and session activity.</p>
    </div>
    <button type="button" class="btn btn-outline-primary btn-sm"
            data-um-confirm="Export all activity logs as CSV?">
        <i class="fas fa-file-export me-2"></i>Export Logs
    </button>
</div>

<!-- Stats -->
<div class="row g-3 mb-4 dashboard-stats">
    <?php foreach ([
        ['label'=>'Total Events',   'value'=>$total,   'icon'=>'fa-list-alt',     'type'=>'primary'],
        ['label'=>'Login Events',   'value'=>$logins,  'icon'=>'fa-sign-in-alt',  'type'=>'info'],
        ['label'=>'Data Changes',   'value'=>$changes, 'icon'=>'fa-database',     'type'=>'warning'],
        ['label'=>'Exports',        'value'=>$exports, 'icon'=>'fa-file-export',  'type'=>'success'],
    ] as $sc): ?>
        <div class="col-6 col-xl-3">
            <section class="card stat-card <?= $sc['type'] ?>">
                <div class="card-body d-flex align-items-center">
                    <div class="stat-icon me-3"><i class="fas <?= $sc['icon'] ?>"></i></div>
                    <div>
                        <h6 class="text-muted mb-0 small"><?= $sc['label'] ?></h6>
                        <h4 class="mb-0 fw-bold"><?= $sc['value'] ?></h4>
                    </div>
                </div>
            </section>
        </div>
    <?php endforeach; ?>
</div>

<!-- Filter bar -->
<section class="card mb-3">
    <div class="card-body py-3">
        <div class="um-filter-bar">
            <div class="flex-grow-1" style="min-width:180px;max-width:280px;">
                <div class="input-group input-group-sm">
                    <span class="input-group-text"><i class="fas fa-search" style="font-size:.72rem;"></i></span>
                    <input type="text" id="logUserFilter" class="form-control"
                           placeholder="Filter by user…" style="max-width:unset;">
                </div>
            </div>
            <select id="logActionFilter" class="form-select form-select-sm">
                <option value="">All Actions</option>
                <option value="login">Login</option>
                <option value="logout">Logout</option>
                <option value="create">Create</option>
                <option value="update">Update</option>
                <option value="delete">Delete</option>
                <option value="view">View</option>
                <option value="export">Export</option>
            </select>
            <span class="ms-auto text-muted" style="font-size:.78rem;white-space:nowrap;"><?= $total ?> events</span>
        </div>
    </div>
</section>

<!-- Log table -->
<section class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table submodule-table align-middle mb-0">
                <thead>
                    <tr>
                        <th style="padding-left:1.2rem;width:42px;">#</th>
                        <th>User</th>
                        <th>Action</th>
                        <th>Detail</th>
                        <th>Module</th>
                        <th>IP Address</th>
                        <th style="white-space:nowrap;">Timestamp</th>
                    </tr>
                </thead>
                <tbody id="logTableBody">
                    <?php foreach ($logs as $log):
                        $icon = $actionIcons[$log['action']] ?? 'fa-circle';
                    ?>
                    <tr class="log-row"
                        data-action="<?= htmlspecialchars($log['action']) ?>"
                        data-user="<?= htmlspecialchars(strtolower($log['user'])) ?>">
                        <td class="text-muted" style="padding-left:1.2rem;font-size:.75rem;"><?= $log['id'] ?></td>
                        <td>
                            <div class="um-user-cell">
                                <span class="um-avatar a"><?= strtoupper($log['user'][0]) ?></span>
                                <div>
                                    <span class="um-user-name"><?= htmlspecialchars($log['user']) ?></span>
                                    <span class="um-user-email"><?= ucfirst($log['role']) ?></span>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="log-action-badge <?= $log['action'] ?>">
                                <i class="fas <?= $icon ?>"></i>
                                <?= ucfirst($log['action']) ?>
                            </span>
                        </td>
                        <td style="max-width:260px;font-size:.8rem;"><?= htmlspecialchars($log['detail']) ?></td>
                        <td style="font-size:.78rem;color:var(--sms-text-muted);"><?= htmlspecialchars($log['module']) ?></td>
                        <td><code style="font-size:.72rem;color:var(--sms-text-faint);"><?= htmlspecialchars($log['ip']) ?></code></td>
                        <td style="font-size:.75rem;white-space:nowrap;color:var(--sms-text-muted);"><?= htmlspecialchars($log['time']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<script src="<?= BASE_URL ?>/modules/user-management/assets/js/user-management.js"></script>
<?php require_once ROOT_PATH . '/includes/layout-end.php'; ?>
