<?php
/**
 * SMS 2 – User Management – System Settings
 */
require_once __DIR__ . '/../../../config/config.php';

$pageTitle    = 'System Settings';
$activeModule = 'user-management';
$activePage   = 'system-settings';
$breadcrumbs  = [
    ['label' => 'User Management', 'url' => BASE_URL . '/modules/user-management/index.php'],
    ['label' => 'System Settings', 'url' => null],
];

require_once __DIR__ . '/../../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../../includes/layout-start.php';
requireSuperAdmin();

$saved = $_GET['saved'] ?? '';
?>

<link href="<?= BASE_URL ?>/modules/user-management/assets/css/user-management.css" rel="stylesheet">
<!-- Toast container -->
<div id="umToastContainer" class="position-fixed bottom-0 end-0 p-3" style="z-index:1100;"></div>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="page-header d-flex justify-content-between align-items-start flex-wrap gap-2">
    <div>
        <h1><i class="fas fa-sliders-h text-sms-primary me-2"></i>System Settings</h1>
        <p>Configure application-wide settings, school year, security rules, and global feature toggles.</p>
    </div>
    <span class="placeholder-badge"><i class="fas fa-lock me-1"></i>Superadmin Only</span>
</div>

<div class="row g-4">

    <!-- Left column: App + Academic + Security -->
    <div class="col-lg-7">

        <!-- Application Identity -->
        <section class="card mb-4 settings-form">
            <div class="card-body">
                <div class="settings-section-head">
                    <div class="settings-icon"><i class="fas fa-university"></i></div>
                    <div>
                        <h6>Application Identity</h6>
                        <p>System name, institution, and branding settings.</p>
                    </div>
                </div>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Application Name</label>
                        <input type="text" class="form-control" value="Student Management System 2">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Short Name</label>
                        <input type="text" class="form-control" value="SMS 2">
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-semibold">Institution</label>
                        <input type="text" class="form-control" value="Bestlink College of the Philippines">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">App Version</label>
                        <input type="text" class="form-control" value="1.0.0" readonly>
                        <div class="form-text">Managed via deployment — read-only.</div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Base URL</label>
                        <input type="text" class="form-control" value="/SMS2_system">
                        <div class="form-text">Change if deployed under a different folder.</div>
                    </div>
                </div>
            </div>
            <div class="settings-save-bar">
                <button type="button" class="btn btn-outline-secondary btn-sm">Reset</button>
                <button type="button" class="btn btn-sms-primary btn-sm"
                        onclick="window.umShowToast('Application identity saved.','success')">
                    <i class="fas fa-save me-2"></i>Save Changes
                </button>
            </div>
        </section>

        <!-- Academic Calendar -->
        <section class="card mb-4 settings-form">
            <div class="card-body">
                <div class="settings-section-head">
                    <div class="settings-icon" style="background:linear-gradient(145deg,#059669,#34d399);">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div>
                        <h6>Academic Calendar</h6>
                        <p>Active school year, semester, and enrollment period.</p>
                    </div>
                </div>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Active School Year</label>
                        <select class="form-select">
                            <option selected>2025–2026</option>
                            <option>2026–2027</option>
                            <option>2024–2025</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Current Semester</label>
                        <select class="form-select">
                            <option>1st Semester</option>
                            <option selected>2nd Semester</option>
                            <option>Summer</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Enrollment Start</label>
                        <input type="date" class="form-control" value="2026-06-01">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Enrollment End</label>
                        <input type="date" class="form-control" value="2026-07-31">
                    </div>
                </div>
            </div>
            <div class="settings-save-bar">
                <button type="button" class="btn btn-outline-secondary btn-sm">Reset</button>
                <button type="button" class="btn btn-sms-primary btn-sm"
                        onclick="window.umShowToast('Academic calendar saved.','success')">
                    <i class="fas fa-save me-2"></i>Save Changes
                </button>
            </div>
        </section>

        <!-- Security & Sessions -->
        <section class="card mb-4 settings-form">
            <div class="card-body">
                <div class="settings-section-head">
                    <div class="settings-icon" style="background:linear-gradient(145deg,#dc2626,#f87171);">
                        <i class="fas fa-lock"></i>
                    </div>
                    <div>
                        <h6>Security &amp; Sessions</h6>
                        <p>Session timeout, login limits, and password policy.</p>
                    </div>
                </div>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Session Timeout</label>
                        <select class="form-select">
                            <option>15 minutes</option>
                            <option selected>30 minutes</option>
                            <option>1 hour</option>
                            <option>2 hours</option>
                            <option>8 hours (until logout)</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Max Failed Login Attempts</label>
                        <select class="form-select">
                            <option>3 attempts</option>
                            <option selected>5 attempts</option>
                            <option>10 attempts</option>
                            <option>Unlimited</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Minimum Password Length</label>
                        <input type="number" class="form-control" value="8" min="6" max="32">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Password Expiry</label>
                        <select class="form-select">
                            <option selected>Never</option>
                            <option>30 days</option>
                            <option>60 days</option>
                            <option>90 days</option>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-semibold d-flex align-items-center gap-2 mb-1">
                            <label class="um-toggle mb-0">
                                <input type="checkbox" checked>
                                <span class="um-toggle-track"></span>
                            </label>
                            Require password change on first login
                        </label>
                    </div>
                </div>
            </div>
            <div class="settings-save-bar">
                <button type="button" class="btn btn-outline-secondary btn-sm">Reset</button>
                <button type="button" class="btn btn-sms-primary btn-sm"
                        onclick="window.umShowToast('Security settings saved.','success')">
                    <i class="fas fa-save me-2"></i>Save Changes
                </button>
            </div>
        </section>

    </div><!-- /left col -->

    <!-- Right column: Features + Notifications + Maintenance -->
    <div class="col-lg-5">

        <!-- Feature Toggles -->
        <section class="card mb-4 settings-form">
            <div class="card-body">
                <div class="settings-section-head">
                    <div class="settings-icon" style="background:linear-gradient(145deg,#7c3aed,#a78bfa);">
                        <i class="fas fa-toggle-on"></i>
                    </div>
                    <div>
                        <h6>Feature Toggles</h6>
                        <p>Enable or disable system-wide features.</p>
                    </div>
                </div>
                <?php
                $toggles = [
                    ['label'=>'Online Pre-registration',  'checked'=>true],
                    ['label'=>'Online Payment Gateway',   'checked'=>false],
                    ['label'=>'LMS Module',               'checked'=>true],
                    ['label'=>'Student Portal',           'checked'=>true],
                    ['label'=>'Activity Logging',         'checked'=>true],
                    ['label'=>'Email Notifications',      'checked'=>false],
                    ['label'=>'Maintenance Mode',         'checked'=>false],
                ];
                foreach ($toggles as $toggle): ?>
                <div class="d-flex align-items-center justify-content-between py-2"
                     style="border-bottom:1px solid var(--sms-border-soft);">
                    <span style="font-size:.85rem;font-weight:600;color:var(--sms-text);">
                        <?= htmlspecialchars($toggle['label']) ?>
                    </span>
                    <label class="um-toggle mb-0">
                        <input type="checkbox" <?= $toggle['checked'] ? 'checked' : '' ?>>
                        <span class="um-toggle-track"></span>
                    </label>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="settings-save-bar">
                <button type="button" class="btn btn-sms-primary btn-sm w-100"
                        onclick="window.umShowToast('Feature toggles saved.','success')">
                    <i class="fas fa-save me-2"></i>Save Toggles
                </button>
            </div>
        </section>

        <!-- Notification Settings -->
        <section class="card mb-4 settings-form">
            <div class="card-body">
                <div class="settings-section-head">
                    <div class="settings-icon" style="background:linear-gradient(145deg,#d97706,#fbbf24);">
                        <i class="fas fa-bell"></i>
                    </div>
                    <div>
                        <h6>Notifications</h6>
                        <p>System email and in-app alert settings.</p>
                    </div>
                </div>
                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label fw-semibold">System Email (From)</label>
                        <input type="email" class="form-control" value="noreply@bestlink.edu.ph">
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-semibold">Admin Alert Email</label>
                        <input type="email" class="form-control" value="admin@bestlink.edu.ph">
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-semibold">SMTP Server</label>
                        <input type="text" class="form-control" value="smtp.bestlink.edu.ph" placeholder="smtp.host.com">
                    </div>
                    <div class="col-6">
                        <label class="form-label fw-semibold">SMTP Port</label>
                        <input type="number" class="form-control" value="587">
                    </div>
                    <div class="col-6">
                        <label class="form-label fw-semibold">Encryption</label>
                        <select class="form-select">
                            <option>None</option>
                            <option selected>TLS</option>
                            <option>SSL</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="settings-save-bar">
                <button type="button" class="btn btn-outline-secondary btn-sm"
                        onclick="window.umShowToast('Test email sent.','info')">
                    <i class="fas fa-paper-plane me-1"></i>Test
                </button>
                <button type="button" class="btn btn-sms-primary btn-sm"
                        onclick="window.umShowToast('Notification settings saved.','success')">
                    <i class="fas fa-save me-2"></i>Save
                </button>
            </div>
        </section>

        <!-- Danger zone -->
        <section class="card border" style="border-color:rgba(220,38,38,0.30) !important;">
            <div class="card-body">
                <div class="settings-section-head">
                    <div class="settings-icon" style="background:linear-gradient(145deg,#dc2626,#f87171);">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div>
                        <h6 style="color:var(--sms-danger);">Danger Zone</h6>
                        <p>Irreversible system actions — proceed with caution.</p>
                    </div>
                </div>
                <div class="d-grid gap-2">
                    <button type="button" class="btn btn-outline-warning btn-sm text-start"
                            data-um-confirm="Clear all activity logs? This cannot be undone.">
                        <i class="fas fa-trash-alt me-2"></i>Clear All Activity Logs
                    </button>
                    <button type="button" class="btn btn-outline-warning btn-sm text-start"
                            data-um-confirm="Reset all user passwords to default? This cannot be undone.">
                        <i class="fas fa-key me-2"></i>Reset All User Passwords
                    </button>
                    <button type="button" class="btn btn-outline-danger btn-sm text-start"
                            data-um-confirm="Enable maintenance mode? All non-admin users will be locked out.">
                        <i class="fas fa-tools me-2"></i>Enable Maintenance Mode
                    </button>
                </div>
            </div>
        </section>

    </div><!-- /right col -->
</div><!-- /row -->

<script src="<?= BASE_URL ?>/modules/user-management/assets/js/user-management.js"></script>
<?php require_once ROOT_PATH . '/includes/layout-end.php'; ?>
