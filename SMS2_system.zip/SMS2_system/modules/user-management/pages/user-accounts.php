<?php
/**
 * SMS 2 – User Management – User Accounts
 */
require_once __DIR__ . '/../../../config/config.php';

$pageTitle    = 'User Accounts';
$activeModule = 'user-management';
$activePage   = 'user-accounts';
$breadcrumbs  = [
    ['label' => 'User Management', 'url' => BASE_URL . '/modules/user-management/index.php'],
    ['label' => 'User Accounts',   'url' => null],
];

require_once __DIR__ . '/../../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../../includes/layout-start.php';
requireSuperAdmin();

/* ── Demo user data (Phase 1 — no DB) ─────────────────────── */
$users = [
    ['id'=>1, 'name'=>'Super Admin',         'username'=>'superadmin@bestlink.edu.ph',      'email'=>'superadmin@bestlink.edu.ph',      'role'=>'admin',      'roleLabel'=>'Super Admin',    'status'=>'active',   'created'=>'Jan 1, 2026',  'last_login'=>'Jul 13, 2026 08:02'],
    ['id'=>2, 'name'=>'Registrar',           'username'=>'registrar@bestlink.edu.ph',        'email'=>'registrar@bestlink.edu.ph',       'role'=>'registrar',  'roleLabel'=>'Registrar',      'status'=>'active',   'created'=>'Jan 2, 2026',  'last_login'=>'Jul 13, 2026 07:55'],
    ['id'=>3, 'name'=>'CRAD Officer',        'username'=>'cradofficer@bestlink.edu.ph',      'email'=>'crad@bestlink.edu.ph',            'role'=>'crad',       'roleLabel'=>'CRAD Officer',   'status'=>'active',   'created'=>'Jan 3, 2026',  'last_login'=>'Jul 12, 2026 14:30'],
    ['id'=>4, 'name'=>'Finance',             'username'=>'finance@bestlink.edu.ph',          'email'=>'finance@bestlink.edu.ph',         'role'=>'finance',    'roleLabel'=>'Finance',        'status'=>'active',   'created'=>'Jan 3, 2026',  'last_login'=>'Jul 13, 2026 09:10'],
    ['id'=>5, 'name'=>'HR',                  'username'=>'hr@bestlink.edu.ph',               'email'=>'hr@bestlink.edu.ph',              'role'=>'hr',         'roleLabel'=>'HR',             'status'=>'active',   'created'=>'Jan 4, 2026',  'last_login'=>'Jul 11, 2026 11:00'],
    ['id'=>6, 'name'=>'IT Officer',          'username'=>'itofficer@bestlink.edu.ph',        'email'=>'itofficer@bestlink.edu.ph',       'role'=>'it_office',  'roleLabel'=>'IT Office',      'status'=>'active',   'created'=>'Jan 4, 2026',  'last_login'=>'Jul 10, 2026 16:45'],
    ['id'=>7, 'name'=>'Student Affairs',     'username'=>'studentaffairs@bestlink.edu.ph',   'email'=>'osa@bestlink.edu.ph',             'role'=>'osa',        'roleLabel'=>'OSA',            'status'=>'active',   'created'=>'Jan 5, 2026',  'last_login'=>'Jul 9, 2026 10:20'],
    ['id'=>8, 'name'=>'Quality Assurance',   'username'=>'qualityassurance@bestlink.edu.ph', 'email'=>'qa@bestlink.edu.ph',              'role'=>'qa',         'roleLabel'=>'QA Office',      'status'=>'active',   'created'=>'Jan 5, 2026',  'last_login'=>'Jul 8, 2026 15:00'],
    ['id'=>9, 'name'=>'Kenneth Abejuela',    'username'=>'s230106713',                       'email'=>'s230106713@bestlink.edu.ph',      'role'=>'student',    'roleLabel'=>'Student',        'status'=>'active',   'created'=>'Jun 1, 2026',  'last_login'=>'Jul 7, 2026 09:00'],
    ['id'=>10,'name'=>'Test User',           'username'=>'testuser@bestlink.edu.ph',         'email'=>'testuser@bestlink.edu.ph',        'role'=>'registrar',  'roleLabel'=>'Registrar',      'status'=>'inactive', 'created'=>'Mar 10, 2026', 'last_login'=>'May 5, 2026 12:00'],
];

$avatarColors = ['a','b','c','d','e','f'];
?>

<link href="<?= BASE_URL ?>/modules/user-management/assets/css/user-management.css" rel="stylesheet">

<?php renderBreadcrumbs($breadcrumbs); ?>

<!-- Toast container -->
<div id="umToastContainer" class="position-fixed bottom-0 end-0 p-3" style="z-index:1100;"></div>

<div class="page-header d-flex justify-content-between align-items-start flex-wrap gap-2">
    <div>
        <h1><i class="fas fa-user-cog text-sms-primary me-2"></i>User Accounts</h1>
        <p>Create, edit, and manage all system user accounts and login credentials.</p>
    </div>
    <button type="button" class="btn btn-sms-primary"
            data-bs-toggle="modal" data-bs-target="#umUserModal"
            data-um-action="add">
        <i class="fas fa-user-plus me-2"></i>Add User
    </button>
</div>

<!-- Stats row -->
<div class="row g-3 mb-4 dashboard-stats">
    <?php
    $total    = count($users);
    $active   = count(array_filter($users, fn($u) => $u['status'] === 'active'));
    $inactive = count(array_filter($users, fn($u) => $u['status'] === 'inactive'));
    $locked   = count(array_filter($users, fn($u) => $u['status'] === 'locked'));
    $statCards = [
        ['label'=>'Total Users',  'value'=>$total,    'icon'=>'fa-users',      'type'=>'primary'],
        ['label'=>'Active',       'value'=>$active,   'icon'=>'fa-user-check', 'type'=>'success'],
        ['label'=>'Inactive',     'value'=>$inactive, 'icon'=>'fa-user-slash', 'type'=>'warning'],
        ['label'=>'Locked Out',   'value'=>$locked,   'icon'=>'fa-user-lock',  'type'=>'info'],
    ];
    foreach ($statCards as $sc): ?>
        <div class="col-6 col-xl-3">
            <section class="card stat-card <?= $sc['type'] ?>">
                <div class="card-body d-flex align-items-center">
                    <div class="stat-icon me-3"><i class="fas <?= $sc['icon'] ?>"></i></div>
                    <div>
                        <h6 class="text-muted mb-0 small"><?= $sc['label'] ?></h6>
                        <h4 class="mb-0 fw-bold"><?= $sc['value'] ?></h4>
                    </div>
                </div>
            </section>
        </div>
    <?php endforeach; ?>
</div>

<!-- Filter bar -->
<section class="card mb-3">
    <div class="card-body py-3">
        <div class="um-filter-bar">
            <div class="flex-grow-1" style="min-width:180px;max-width:320px;">
                <div class="input-group input-group-sm">
                    <span class="input-group-text"><i class="fas fa-search" style="font-size:.72rem;"></i></span>
                    <input type="text" id="umSearch" class="form-control form-control-sm"
                           placeholder="Search name or email…" style="max-width:unset;">
                </div>
            </div>
            <select id="umRoleFilter" class="form-select form-select-sm">
                <option value="">All Roles</option>
                <option value="admin">Super Admin</option>
                <option value="registrar">Registrar</option>
                <option value="finance">Finance</option>
                <option value="hr">HR</option>
                <option value="it_office">IT Office</option>
                <option value="osa">OSA</option>
                <option value="qa">QA Office</option>
                <option value="crad">CRAD Officer</option>
                <option value="student">Student</option>
            </select>
            <select id="umStatusFilter" class="form-select form-select-sm">
                <option value="">All Status</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="locked">Locked</option>
            </select>
            <span class="ms-auto text-muted" style="font-size:.78rem;white-space:nowrap;">
                <?= $total ?> users
            </span>
        </div>
    </div>
</section>

<!-- User table -->
<section class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table submodule-table align-middle mb-0">
                <thead>
                    <tr>
                        <th style="padding-left:1.2rem;">User</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Last Login</th>
                        <th>Created</th>
                        <th class="text-end" style="padding-right:1.2rem;">Actions</th>
                    </tr>
                </thead>
                <tbody id="umTableBody">
                    <?php foreach ($users as $i => $u):
                        $col = $avatarColors[$i % count($avatarColors)];
                    ?>
                    <tr class="um-user-row"
                        data-name="<?= htmlspecialchars($u['name']) ?>"
                        data-email="<?= htmlspecialchars($u['email']) ?>"
                        data-role="<?= htmlspecialchars($u['role']) ?>"
                        data-status="<?= htmlspecialchars($u['status']) ?>">
                        <td style="padding-left:1.2rem;">
                            <div class="um-user-cell">
                                <span class="um-avatar <?= $col ?>"><?= strtoupper($u['name'][0]) ?></span>
                                <div class="min-w-0">
                                    <span class="um-user-name"><?= htmlspecialchars($u['name']) ?></span>
                                    <span class="um-user-email"><?= htmlspecialchars($u['email']) ?></span>
                                </div>
                            </div>
                        </td>
                        <td><code style="font-size:.78rem;color:var(--sms-text-muted);"><?= htmlspecialchars($u['username']) ?></code></td>
                        <td><span class="role-badge <?= $u['role'] ?>"><?= htmlspecialchars($u['roleLabel']) ?></span></td>
                        <td><span class="user-status <?= $u['status'] ?>"><?= ucfirst($u['status']) ?></span></td>
                        <td class="text-muted" style="font-size:.78rem;white-space:nowrap;"><?= htmlspecialchars($u['last_login']) ?></td>
                        <td class="text-muted" style="font-size:.78rem;white-space:nowrap;"><?= htmlspecialchars($u['created']) ?></td>
                        <td class="text-end" style="padding-right:1.2rem;">
                            <div class="d-flex align-items-center justify-content-end gap-1">
                                <!-- Edit -->
                                <button type="button"
                                        class="btn btn-sm btn-outline-primary px-2 py-1"
                                        title="Edit user"
                                        data-bs-toggle="modal"
                                        data-bs-target="#umUserModal"
                                        data-um-action="edit"
                                        data-uid="<?= $u['id'] ?>"
                                        data-name="<?= htmlspecialchars($u['name']) ?>"
                                        data-username="<?= htmlspecialchars($u['username']) ?>"
                                        data-email="<?= htmlspecialchars($u['email']) ?>"
                                        data-role="<?= htmlspecialchars($u['role']) ?>"
                                        data-status="<?= htmlspecialchars($u['status']) ?>">
                                    <i class="fas fa-pen" style="font-size:.7rem;"></i>
                                </button>
                                <!-- Toggle status -->
                                <?php if ($u['status'] === 'active'): ?>
                                <button type="button"
                                        class="btn btn-sm btn-outline-warning px-2 py-1"
                                        title="Deactivate user"
                                        data-um-confirm="Deactivate <?= htmlspecialchars($u['name']) ?>?">
                                    <i class="fas fa-user-slash" style="font-size:.7rem;"></i>
                                </button>
                                <?php else: ?>
                                <button type="button"
                                        class="btn btn-sm btn-outline-success px-2 py-1"
                                        title="Activate user"
                                        data-um-confirm="Activate <?= htmlspecialchars($u['name']) ?>?">
                                    <i class="fas fa-user-check" style="font-size:.7rem;"></i>
                                </button>
                                <?php endif; ?>
                                <!-- Delete (not self) -->
                                <?php if ($u['id'] !== 1): ?>
                                <button type="button"
                                        class="btn btn-sm btn-outline-danger px-2 py-1"
                                        title="Delete user"
                                        data-um-confirm="Permanently delete <?= htmlspecialchars($u['name']) ?>? This cannot be undone.">
                                    <i class="fas fa-trash" style="font-size:.7rem;"></i>
                                </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <tr id="umNoResults" style="display:none;">
                <td colspan="7" class="text-center py-5 text-muted">
                    <i class="fas fa-search-minus fa-2x mb-2 d-block opacity-50"></i>No users match your filters.
                </td>
            </tr>
        </div>
    </div>
</section>

<!-- ── Add / Edit User Modal ─────────────────────────────────── -->
<div class="modal fade" id="umUserModal" tabindex="-1" aria-labelledby="umModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold" id="umModalTitle">Add New User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="umUserForm" action="#" method="POST" novalidate>
                <input type="hidden" name="user_id">
                <div class="modal-body">
                    <div class="um-modal-avatar-row mb-3">
                        <div class="um-modal-avatar">?</div>
                        <small class="text-muted">Avatar auto-generated from name</small>
                    </div>
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label fw-semibold">Full Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="full_name" placeholder="e.g. Maria Santos" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Username <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="username" placeholder="e.g. msantos" required autocomplete="off">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" name="email" placeholder="user@bestlink.edu.ph" required>
                        </div>
                        <div class="col-md-6 um-pw-row">
                            <label class="form-label fw-semibold">Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" name="password" placeholder="••••••••" autocomplete="new-password">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Role <span class="text-danger">*</span></label>
                            <select class="form-select" name="role" required>
                                <option value="">Select role…</option>
                                <option value="admin">Super Admin</option>
                                <option value="registrar">Registrar</option>
                                <option value="finance">Finance</option>
                                <option value="hr">HR</option>
                                <option value="it_office">IT Office</option>
                                <option value="osa">OSA</option>
                                <option value="qa">QA Office</option>
                                <option value="crad">CRAD Officer</option>
                                <option value="student">Student</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Status</label>
                            <select class="form-select" name="status">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                                <option value="locked">Locked</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Notes <span class="text-muted fw-normal">(optional)</span></label>
                            <textarea class="form-control" name="notes" rows="2" placeholder="Any notes about this account…"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-sms-primary">
                        <i class="fas fa-save me-2"></i>Save User
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="<?= BASE_URL ?>/modules/user-management/assets/js/user-management.js"></script>
<?php require_once ROOT_PATH . '/includes/layout-end.php'; ?>
