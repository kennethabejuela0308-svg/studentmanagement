<?php
/**
 * SMS 2 – AJAX endpoint: save role permission overrides.
 * Overrides are written to a shared JSON file so every user session
 * picks them up — not just the superadmin's own session.
 *
 * POST body (JSON):
 *   { "role": "registrar", "module": "enrollment", "granted": true }
 *   { "role": "__reset__", "module": "__all__",    "granted": false }
 *
 * Response (JSON):
 *   { "ok": true }  |  { "ok": false, "error": "..." }
 */
require_once __DIR__ . '/../../../config/config.php';
require_once ROOT_PATH . '/includes/authentication.php';

header('Content-Type: application/json');

// Must be superadmin
if (!isAuthenticated() || getCurrentUserRoleKey() !== 'admin') {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Forbidden']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!$data || !isset($data['role'], $data['module'], $data['granted'])) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Invalid payload']);
    exit;
}

$role    = (string) $data['role'];
$module  = (string) $data['module'];
$granted = (bool)   $data['granted'];

// Shared overrides file — readable by all PHP processes
define('PERM_FILE', ROOT_PATH . '/config/perm_overrides.json');

/* ── Helper: load current overrides from file ── */
function loadOverrides(): array
{
    if (!file_exists(PERM_FILE)) {
        return [];
    }
    $json = file_get_contents(PERM_FILE);
    $data = json_decode($json, true);
    return is_array($data) ? $data : [];
}

/* ── Helper: persist overrides to file ── */
function saveOverrides(array $overrides): bool
{
    $dir = dirname(PERM_FILE);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    return file_put_contents(
        PERM_FILE,
        json_encode($overrides, JSON_PRETTY_PRINT),
        LOCK_EX
    ) !== false;
}

// Full reset
if ($role === '__reset__' && $module === '__all__') {
    if (file_exists(PERM_FILE)) {
        unlink(PERM_FILE);
    }
    echo json_encode(['ok' => true, 'reset' => true]);
    exit;
}

// Protect locked cells
if ($role === 'admin' || $module === 'user-management') {
    echo json_encode(['ok' => false, 'error' => 'This permission is locked']);
    exit;
}

// Validate inputs
$validRoles   = ['registrar','finance','hr','it_office','osa','qa','crad','student'];
$validModules = ['enrollment','registrar','curriculum','accreditation',
                 'payment','faculty','scheduling','cocurricular','lms','crad','reports-analytics'];

if (!in_array($role, $validRoles, true) || !in_array($module, $validModules, true)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Unknown role or module']);
    exit;
}

// Load, update, save
$overrides = loadOverrides();

if (!isset($overrides[$role])) {
    $overrides[$role] = [];
}
$overrides[$role][$module] = $granted;

if (!saveOverrides($overrides)) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Could not write permissions file']);
    exit;
}

echo json_encode(['ok' => true]);
