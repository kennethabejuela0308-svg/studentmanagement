<?php
/**
 * SMS 2 - Research Proposal Submission
 * Student Portal — CRAD FORM S2 V3 (Title Approval)
 */
require_once __DIR__ . '/../../../config/config.php';
require_once ROOT_PATH . '/includes/authentication.php';
require_once ROOT_PATH . '/includes/breadcrumbs.php';

$studentId = $_SESSION['student_id'] ?? 'S230000001';
$studentName = $_SESSION['user_name'] ?? 'Juan Dela Cruz';
$nameParts = array_values(array_filter(preg_split('/\s+/', trim($studentName)) ?: []));
if (count($nameParts) >= 3) {
    $lastName = $nameParts[count($nameParts) - 2] . ' ' . $nameParts[count($nameParts) - 1];
    $firstNames = implode(' ', array_slice($nameParts, 0, -2));
} elseif (count($nameParts) === 2) {
    $lastName = $nameParts[1];
    $firstNames = $nameParts[0];
} else {
    $lastName = $nameParts[0] ?? 'Dela Cruz';
    $firstNames = 'Juan';
}
$defaultMemberName = $lastName . ', ' . $firstNames . ' A.';
$defaultOrNumber = 'OR-' . date('y') . str_pad((string) random_int(10000, 99999), 5, '0', STR_PAD_LEFT);
$submitted = ($_GET['process'] ?? '') === 'submit-proposal';
$submittedDate = $_GET['submission_date'] ?? date('Y-m-d');
$submittedDepartment = $_GET['department'] ?? 'College of Computer Studies';
$submittedMembers = array_values((array) ($_GET['member_name'] ?? []));
$submittedSections = array_values((array) ($_GET['member_section'] ?? []));
$submittedReceipts = array_values((array) ($_GET['member_or'] ?? []));
$submittedDiscipline = $_GET['discipline_cluster'] ?? '';
$submittedAgenda = $_GET['research_agenda'] ?? '';
if (str_starts_with($submittedAgenda, 'Others')) {
    $submittedAgenda = trim((string) ($_GET['research_agenda_others'] ?? '')) ?: $submittedAgenda;
}
$submittedSdg = $_GET['primary_sdg'] ?? '';
$submittedTitle = strtoupper(trim((string) ($_GET['proposed_title'] ?? '')));
$submittedJustification = trim((string) ($_GET['sdg_justification'] ?? ''));

$pageTitle = 'Research Proposal Submission';
$activeModule = 'student_portal';
$activePage = 'research-proposal-submission';
$breadcrumbs = [
    ['label' => 'Student Portal', 'url' => BASE_URL . '/modules/student-portal/pages/my-profile.php'],
    ['label' => 'Research Proposal Submission', 'url' => null],
];

$departments = [
    'College of Computer Studies',
    'College of Business Administration',
    'College of Education',
    'College of Criminal Justice',
    'College of Hospitality & Tourism Management',
    'College of Nursing and Health Sciences',
];

$disciplineClusters = [
    'Natural Sciences, Environmental Studies, and Mathematics',
    'Education, Curriculum, Teaching, and Learning',
    'Health Sciences, Mental Health, and Allied Professions',
    'Engineering, Information Technology, and Computing',
    'Humanities, Social Sciences, and Public Safety',
    'Business, Entrepreneurship, Hospitality, and Tourism Management',
];

$researchAgendas = [
    'Quality Education and Human Capital Development',
    'Inclusive Economic Development, Entrepreneurship, and Industry Competitiveness',
    'Science, Technology, Digital Transformation, and Innovation',
    'Community Health, Well-being, and Social Development',
    'Sustainable Communities, Environmental Stewardship, and Climate Resilience',
    'Peace, Good Governance, Public Safety, and Social Justice',
    'Global Partnerships, Research Excellence, and Institutional Sustainability',
    'Others [Please Specify Below]',
];

$sdgOptions = [
    ['num' => 1,  'title' => 'No Poverty'],
    ['num' => 2,  'title' => 'Zero Hunger'],
    ['num' => 3,  'title' => 'Good Health and Well-being'],
    ['num' => 4,  'title' => 'Quality Education'],
    ['num' => 5,  'title' => 'Gender Equality'],
    ['num' => 6,  'title' => 'Clean Water and Sanitation'],
    ['num' => 7,  'title' => 'Affordable and Clean Energy'],
    ['num' => 8,  'title' => 'Decent Work and Economic Growth'],
    ['num' => 9,  'title' => 'Industry, Innovation and Infrastructure'],
    ['num' => 10, 'title' => 'Reduced Inequalities'],
    ['num' => 11, 'title' => 'Sustainable Cities and Communities'],
    ['num' => 12, 'title' => 'Responsible Consumption and Production'],
    ['num' => 13, 'title' => 'Climate Action'],
    ['num' => 14, 'title' => 'Life Below Water'],
    ['num' => 15, 'title' => 'Life on Land'],
    ['num' => 16, 'title' => 'Peace, Justice and Strong Institutions'],
    ['num' => 17, 'title' => 'Partnerships for the Goals'],
];

$defaultDiscipline = 'Engineering, Information Technology, and Computing';
$defaultAgenda = 'Science, Technology, Digital Transformation, and Innovation';
$defaultSdg = 9;

require_once ROOT_PATH . '/includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="student-portal crad-title-form-wrap">
    <?php if ($submitted): ?>
        <div class="crad-print-preview">
            <div class="crad-print-actions">
                <a class="btn btn-outline-secondary" href="<?= BASE_URL ?>/modules/student-portal/pages/research-proposal-submission.php">
                    <i class="fas fa-arrow-left me-2"></i>New Submission
                </a>
                <button type="button" class="btn btn-sms-primary" onclick="window.print()">
                    <i class="fas fa-print me-2"></i>Print Title Approval Form
                </button>
            </div>

            <article class="crad-print-sheet">
                <header class="print-document-header">
                    <div class="print-bcp-logo-wrap">
                        <img class="print-bcp-logo" src="<?= BASE_URL ?>/images/bestlink.png" alt="Bestlink College of the Philippines logo">
                    </div>
                    <div class="print-school-name">
                        <strong>BESTLINK COLLEGE OF THE PHILIPPINES</strong>
                        <span>#1071 Brgy. Kaligayahan, Quirino Highway, Novaliches, Quezon City</span>
                        <b>CENTER FOR RESEARCH AND DEVELOPMENT</b>
                    </div>
                    <div class="print-form-code">CRAD Form S2 V3</div>
                </header>

                <h1 class="print-document-title">TITLE APPROVAL FORM</h1>

                <div class="print-meta">
                    <div><strong>Date:</strong> <span><?= htmlspecialchars(date('Y-m-d', strtotime($submittedDate))) ?></span></div>
                    <div><strong>I. Department:</strong> <span><?= htmlspecialchars($submittedDepartment) ?></span></div>
                </div>

                <section class="print-section">
                    <h2>II. Students Information</h2>
                    <table class="print-table print-student-table">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Name (Last name, First Name, Middle Initial)</th>
                                <th>Section</th>
                                <th>Research Forum OR No.</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php for ($i = 0; $i < 6; $i++): ?>
                                <tr>
                                    <td><?= $i + 1 ?></td>
                                    <td><?= htmlspecialchars(strtoupper($submittedMembers[$i] ?? '')) ?></td>
                                    <td><?= htmlspecialchars(strtoupper($submittedSections[$i] ?? '')) ?></td>
                                    <td><?= htmlspecialchars(strtoupper($submittedReceipts[$i] ?? '')) ?></td>
                                </tr>
                            <?php endfor; ?>
                        </tbody>
                    </table>
                </section>

                <div class="print-two-column">
                    <div>
                        <section class="print-choice-box">
                            <h2>III. Research Discipline Cluster</h2>
                            <?php foreach ($disciplineClusters as $cluster): ?>
                                <div class="<?= $cluster === $submittedDiscipline ? 'is-selected' : '' ?>">
                                    [<?= $cluster === $submittedDiscipline ? '✓' : ' ' ?>] <?= htmlspecialchars($cluster) ?>
                                </div>
                            <?php endforeach; ?>
                        </section>

                        <section class="print-choice-box">
                            <h2>V. Institutional Research Agenda Alignment</h2>
                            <?php foreach ($researchAgendas as $agenda): ?>
                                <?php
                                $agendaSelected = $agenda === ($_GET['research_agenda'] ?? '')
                                    || (str_starts_with((string) ($_GET['research_agenda'] ?? ''), 'Others')
                                        && str_starts_with($agenda, 'Others'));
                                ?>
                                <div class="<?= $agendaSelected ? 'is-selected' : '' ?>">
                                    [<?= $agendaSelected ? '✓' : ' ' ?>] <?= htmlspecialchars($agenda) ?>
                                </div>
                            <?php endforeach; ?>
                            <?php if (str_starts_with((string) ($_GET['research_agenda'] ?? ''), 'Others')): ?>
                                <div class="print-other-value"><?= htmlspecialchars($submittedAgenda) ?></div>
                            <?php endif; ?>
                        </section>
                    </div>

                    <section class="print-choice-box print-sdg-box">
                        <h2>IV. Sustainable Development Goal (SDG) Alignment</h2>
                        <p>Select the one (1) primary SDG that aligns with proposed research.</p>
                        <div class="print-sdg-list">
                            <?php foreach ($sdgOptions as $sdg): ?>
                                <?php $sdgLabel = 'SDG ' . $sdg['num'] . ' — ' . $sdg['title']; ?>
                                <div class="<?= $sdgLabel === $submittedSdg ? 'is-selected' : '' ?>">
                                    [<?= $sdgLabel === $submittedSdg ? '✓' : ' ' ?>]
                                    SDG <?= (int) $sdg['num'] ?> - <?= htmlspecialchars($sdg['title']) ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </section>
                </div>

                <section class="print-response-section">
                    <h2>VI. Proposed Research Title</h2>
                    <div class="print-response"><?= htmlspecialchars($submittedTitle) ?></div>
                </section>

                <section class="print-response-section">
                    <h2>VII. Sustainable Development Goal Justification</h2>
                    <div class="print-response print-response-small"><?= htmlspecialchars($submittedJustification) ?></div>
                </section>

                <div class="print-two-column print-approval-row">
                    <section class="print-choice-box">
                        <h2>VIII. Research Coordinator Screening</h2>
                        <table class="print-table">
                            <thead><tr><th>Evaluation Criteria</th><th>Yes</th><th>No</th></tr></thead>
                            <tbody>
                                <tr><td>Title aligns with institutional research agenda</td><td></td><td></td></tr>
                                <tr><td>Proposed study is feasible and original</td><td></td><td></td></tr>
                                <tr><td>Ethical and SDG requirements are satisfied</td><td></td><td></td></tr>
                            </tbody>
                        </table>
                    </section>
                    <section class="print-choice-box print-signature-box">
                        <h2>IX. Approval (Name, signature and date)</h2>
                        <div class="print-signature-line"></div>
                        <strong>Research Coordinator</strong>
                        <div class="print-signature-line"></div>
                        <strong>Date</strong>
                    </section>
                </div>

                <footer class="print-page-footer">CRAD Form S2 V3 &nbsp; • &nbsp; Page 1 of 2</footer>
            </article>

            <article class="crad-print-sheet">
                <header class="print-document-header">
                    <div class="print-bcp-logo-wrap">
                        <img class="print-bcp-logo" src="<?= BASE_URL ?>/images/bestlink.png" alt="Bestlink College of the Philippines logo">
                    </div>
                    <div class="print-school-name">
                        <strong>BESTLINK COLLEGE OF THE PHILIPPINES</strong>
                        <b>CENTER FOR RESEARCH AND DEVELOPMENT</b>
                    </div>
                    <div class="print-form-code">CRAD Form S2 V3</div>
                </header>
                <h1 class="print-document-title">RESEARCH TITLE EVALUATION SHEET</h1>

                <section class="print-response-section">
                    <h2>Proposed Research Title</h2>
                    <div class="print-response"><?= htmlspecialchars($submittedTitle) ?></div>
                </section>

                <section class="print-section">
                    <h2>CRD Evaluation Checklist</h2>
                    <table class="print-table print-evaluation-table">
                        <thead>
                            <tr><th>Evaluation Criteria</th><th>Acceptable</th><th>For Revision</th><th>Remarks</th></tr>
                        </thead>
                        <tbody>
                            <tr><td>Clarity and specificity of the proposed title</td><td></td><td></td><td></td></tr>
                            <tr><td>Alignment with research discipline cluster</td><td></td><td></td><td></td></tr>
                            <tr><td>Alignment with institutional research agenda</td><td></td><td></td><td></td></tr>
                            <tr><td>Contribution to the selected SDG</td><td></td><td></td><td></td></tr>
                            <tr><td>Feasibility within available time and resources</td><td></td><td></td><td></td></tr>
                            <tr><td>Originality and relevance of the study</td><td></td><td></td><td></td></tr>
                            <tr><td>Compliance with ethical research standards</td><td></td><td></td><td></td></tr>
                        </tbody>
                    </table>
                </section>

                <section class="print-notes-box">
                    <h2>Evaluator's Comments and Recommendations</h2>
                    <div></div><div></div><div></div><div></div><div></div><div></div>
                </section>

                <div class="print-two-column print-final-decision">
                    <section class="print-choice-box">
                        <h2>Final Recommendation</h2>
                        <p>[ &nbsp; ] Approved</p>
                        <p>[ &nbsp; ] Approved with Minor Revisions</p>
                        <p>[ &nbsp; ] For Major Revision and Resubmission</p>
                        <p>[ &nbsp; ] Not Approved</p>
                    </section>
                    <section class="print-choice-box print-signature-box">
                        <h2>Evaluator Certification</h2>
                        <div class="print-signature-line"></div>
                        <strong>Name and Signature</strong>
                        <div class="print-signature-line"></div>
                        <strong>Date</strong>
                    </section>
                </div>

                <footer class="print-page-footer">CRAD Form S2 V3 &nbsp; • &nbsp; Page 2 of 2</footer>
            </article>
        </div>
    <?php else: ?>
    <form class="crad-title-form" id="cradTitleForm" method="get" action="">
        <input type="hidden" name="process" value="submit-proposal" id="cradProcessField" disabled>

        <header class="crad-form-header">
            <div>
                <span class="crad-form-code">CRAD FORM S2 V3</span>
                <h1>Submit Title Approval Form</h1>
                <p>Register complete details for Bestlink CRD evaluation</p>
            </div>
            <a class="crad-btn crad-btn-ghost" href="<?= BASE_URL ?>/modules/student-portal/pages/my-profile.php">
                ← Cancel &amp; Exit
            </a>
        </header>

        <nav class="crad-stepper" aria-label="Form steps">
            <div class="crad-step is-active" data-step-indicator="1">
                <span class="crad-step-icon"><i class="fas fa-check"></i></span>
                <span class="crad-step-label">Students Information</span>
            </div>
            <div class="crad-step-line"></div>
            <div class="crad-step" data-step-indicator="2">
                <span class="crad-step-icon"><i class="fas fa-check"></i></span>
                <span class="crad-step-label">Alignments &amp; SDGs</span>
            </div>
            <div class="crad-step-line"></div>
            <div class="crad-step" data-step-indicator="3">
                <span class="crad-step-icon">3</span>
                <span class="crad-step-label">Proposed Title</span>
            </div>
        </nav>

        <div class="crad-form-body">
            <!-- Step 1: Students Information -->
            <section class="crad-step-panel is-active" data-step-panel="1">
                <div class="crad-field-row">
                    <div class="crad-field">
                        <label for="submissionDate">Submission Date <span>*</span></label>
                        <input type="date" id="submissionDate" name="submission_date" value="<?= date('Y-m-d') ?>" required>
                    </div>
                    <div class="crad-field">
                        <label for="department">Department / College <span>*</span></label>
                        <select id="department" name="department" required>
                            <?php foreach ($departments as $dept): ?>
                                <option value="<?= htmlspecialchars($dept) ?>" <?= $dept === 'College of Computer Studies' ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($dept) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="crad-section-head">
                    <div>
                        <h2>II. Students Information</h2>
                        <p>Provide complete research group metadata (Maximum 6 members).</p>
                    </div>
                    <button type="button" class="crad-link-btn" id="addMemberBtn">+ Add Member</button>
                </div>

                <div id="memberList">
                    <article class="crad-member-card" data-member="1">
                        <h3><span>1</span> Group Member Profile</h3>
                        <div class="crad-field-row crad-field-row-3">
                            <div class="crad-field">
                                <label>Full Name (Last, First, M.I.) <span>*</span></label>
                                <input type="text" name="member_name[]" value="<?= htmlspecialchars($defaultMemberName) ?>" required>
                            </div>
                            <div class="crad-field">
                                <label>Section <span>*</span></label>
                                <input type="text" name="member_section[]" value="BSIT 4101" required>
                            </div>
                            <div class="crad-field">
                                <label>Research Forum Receipt OR</label>
                                <input type="text" name="member_or[]" value="<?= htmlspecialchars($defaultOrNumber) ?>" readonly class="crad-or-field" data-auto-or>
                            </div>
                        </div>
                    </article>
                </div>
            </section>

            <!-- Step 2: Alignments & SDGs -->
            <section class="crad-step-panel" data-step-panel="2" hidden>
                <div class="crad-align-block">
                    <div class="crad-align-head">
                        <h2>III. Research Discipline Cluster <span>*</span></h2>
                        <p>Select the discipline cluster that best aligns with your proposed research.</p>
                    </div>
                    <div class="crad-radio-grid">
                        <?php foreach ($disciplineClusters as $cluster): ?>
                            <label class="crad-radio-card">
                                <input type="radio" name="discipline_cluster" value="<?= htmlspecialchars($cluster) ?>" <?= $cluster === $defaultDiscipline ? 'checked' : '' ?> required>
                                <span><?= htmlspecialchars($cluster) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="crad-align-block">
                    <div class="crad-align-head">
                        <h2>V. Institutional Research Agenda Alignment <span>*</span></h2>
                        <p>Select the primary research agenda of Bestlink College of the Philippines.</p>
                    </div>
                    <div class="crad-radio-list">
                        <?php foreach ($researchAgendas as $agenda): ?>
                            <label class="crad-radio-card crad-radio-card-wide">
                                <input type="radio" name="research_agenda" value="<?= htmlspecialchars($agenda) ?>" <?= $agenda === $defaultAgenda ? 'checked' : '' ?> required>
                                <span><?= htmlspecialchars($agenda) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <div class="crad-field crad-others-field" id="agendaOthersWrap" hidden>
                        <label for="agendaOthers">Please Specify <span>*</span></label>
                        <input type="text" id="agendaOthers" name="research_agenda_others" placeholder="Specify other institutional research agenda">
                    </div>
                </div>

                <div class="crad-align-block">
                    <div class="crad-align-head">
                        <h2>IV. Sustainable Development Goal (SDG) Alignment <span>*</span></h2>
                        <p>Select the <strong>one (1) primary SDG</strong> that aligns with the scope of your proposal.</p>
                    </div>
                    <div class="crad-sdg-tiles">
                        <?php foreach ($sdgOptions as $sdg): ?>
                            <label class="crad-sdg-tile <?= (int) $sdg['num'] === $defaultSdg ? 'is-selected' : '' ?>">
                                <input type="radio" name="primary_sdg" value="SDG <?= (int) $sdg['num'] ?> — <?= htmlspecialchars($sdg['title']) ?>" <?= (int) $sdg['num'] === $defaultSdg ? 'checked' : '' ?> required>
                                <span class="crad-sdg-num">SDG <?= (int) $sdg['num'] ?></span>
                                <span class="crad-sdg-title"><?= htmlspecialchars($sdg['title']) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            </section>

            <!-- Step 3: Proposed Title -->
            <section class="crad-step-panel" data-step-panel="3" hidden>
                <div class="crad-align-block">
                    <div class="crad-align-head">
                        <h2>VI. Proposed Research Title <span>*</span></h2>
                        <p>Enter the complete, finalized uppercase title proposed by the group.</p>
                    </div>
                    <div class="crad-field">
                        <textarea
                            id="proposedTitle"
                            name="proposed_title"
                            class="crad-title-input"
                            rows="4"
                            placeholder="E.G. DEVELOPMENT OF IOT-BASED FLOOD MONITORING AND COMMUNITY RISK ALERT RESPONSE PORTAL"
                            required
                        ></textarea>
                    </div>
                </div>

                <div class="crad-align-block">
                    <div class="crad-align-head">
                        <h2>VII. Sustainable Development Goal Justification <span>*</span></h2>
                        <p>In one or two sentences, explain how the proposed study contributes directly to the selected SDG.</p>
                    </div>
                    <div class="crad-field">
                        <textarea
                            id="sdgJustification"
                            name="sdg_justification"
                            rows="4"
                            placeholder="e.g. This study directly supports SDG 11 by deploying real-time community water monitors, reducing flash flood response delay, and securing resilient regional infrastructure."
                            required
                        ></textarea>
                    </div>
                </div>

                <aside class="crad-verify-box">
                    <div class="crad-verify-icon"><i class="fas fa-shield-alt"></i></div>
                    <div>
                        <h3>Bestlink CRD Pre-submission Verification</h3>
                        <p>By clicking Submit, you authorize Bestlink College research coordinators to commence active evaluation checks (feasibility, originality, ethics, and agenda compliance).</p>
                    </div>
                </aside>
            </section>
        </div>

        <footer class="crad-form-footer">
            <button type="button" class="crad-btn crad-btn-secondary" id="cradBackBtn" disabled>← Back</button>
            <button type="button" class="crad-btn crad-btn-primary" id="cradNextBtn">Next Step →</button>
        </footer>
    </form>
    <?php endif; ?>
</div>

<style>
.crad-title-form-wrap { max-width: 1100px; margin: 0 auto; }
.crad-title-form {
    --crad-bg: #111827;
    --crad-panel: #1a2234;
    --crad-panel-2: #151c2c;
    --crad-border: rgba(148,163,184,0.22);
    --crad-text: #f8fafc;
    --crad-muted: #94a3b8;
    --crad-blue: #2563eb;
    --crad-blue-soft: rgba(37,99,235,0.18);
    background: linear-gradient(180deg, #172033 0%, var(--crad-bg) 42%);
    border: 1px solid rgba(148,163,184,0.16);
    border-radius: 18px;
    overflow: hidden;
    box-shadow: 0 18px 48px rgba(15,23,42,0.28);
    color: var(--crad-text);
}
.crad-form-header {
    display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem;
    padding: 1.4rem 1.5rem 1.1rem;
    background: linear-gradient(135deg, #1e3a8a 0%, #1d4ed8 48%, #0f172a 100%);
}
.crad-form-code {
    display: inline-block; margin-bottom: 0.35rem;
    color: rgba(226,232,240,0.78); font-size: 0.72rem; font-weight: 700;
    letter-spacing: 0.08em; text-transform: uppercase;
}
.crad-form-header h1 {
    margin: 0; color: #fff; font-size: 1.55rem; font-weight: 800; letter-spacing: -0.02em;
}
.crad-form-header p { margin: 0.35rem 0 0; color: rgba(226,232,240,0.82); font-size: 0.92rem; }
.crad-btn {
    display: inline-flex; align-items: center; justify-content: center; gap: 0.35rem;
    min-height: 42px; padding: 0.55rem 1rem; border-radius: 10px;
    border: 1px solid transparent; font-size: 0.9rem; font-weight: 700;
    text-decoration: none; cursor: pointer; transition: 0.15s ease;
}
.crad-btn-ghost {
    color: #fff; background: rgba(15,23,42,0.25); border-color: rgba(226,232,240,0.35);
    white-space: nowrap;
}
.crad-btn-ghost:hover { background: rgba(15,23,42,0.4); color: #fff; }
.crad-btn-secondary {
    color: #e2e8f0; background: transparent; border-color: rgba(148,163,184,0.35);
}
.crad-btn-secondary:hover:not(:disabled) { background: rgba(148,163,184,0.12); }
.crad-btn-secondary:disabled { opacity: 0.45; cursor: not-allowed; }
.crad-btn-primary {
    color: #fff; background: var(--crad-blue); border-color: var(--crad-blue);
    box-shadow: 0 8px 20px rgba(37,99,235,0.35);
}
.crad-btn-primary:hover { background: #1d4ed8; color: #fff; }
.crad-btn-success {
    color: #fff; background: #16a34a; border-color: #16a34a;
    box-shadow: 0 8px 20px rgba(22,163,74,0.35);
}
.crad-btn-success:hover { background: #15803d; color: #fff; }
.crad-stepper {
    display: flex; align-items: center; gap: 0.75rem;
    padding: 1.1rem 1.5rem; border-bottom: 1px solid var(--crad-border);
    background: rgba(15,23,42,0.35); overflow-x: auto;
}
.crad-step {
    display: inline-flex; align-items: center; gap: 0.55rem;
    color: var(--crad-muted); white-space: nowrap; font-size: 0.9rem; font-weight: 600;
}
.crad-step-icon {
    width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;
    border-radius: 50%; background: #243044; color: #64748b; font-size: 0.75rem; font-weight: 800;
}
.crad-step.is-active { color: #60a5fa; }
.crad-step.is-active .crad-step-icon,
.crad-step.is-complete .crad-step-icon {
    background: var(--crad-blue); color: #fff;
}
.crad-step.is-complete { color: #86efac; }
.crad-step.is-complete .crad-step-icon {
    background: #16a34a; color: #fff;
}
.crad-step-line {
    flex: 1; min-width: 28px; height: 2px; background: rgba(148,163,184,0.25); border-radius: 99px;
}
.crad-form-body { padding: 1.35rem 1.5rem 0.5rem; }
.crad-field-row {
    display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 1rem; margin-bottom: 1.15rem;
}
.crad-field-row-3 { grid-template-columns: 1.4fr 0.9fr 1fr; }
.crad-field { display: grid; gap: 0.4rem; margin-bottom: 1rem; }
.crad-field-row .crad-field { margin-bottom: 0; }
.crad-field label {
    color: var(--crad-muted); font-size: 0.72rem; font-weight: 700;
    letter-spacing: 0.05em; text-transform: uppercase;
}
.crad-field label span { color: #f87171; }
.crad-field input,
.crad-field select,
.crad-field textarea {
    width: 100%; min-height: 44px; padding: 0.7rem 0.85rem;
    border: 1px solid var(--crad-border); border-radius: 10px;
    background: var(--crad-panel); color: var(--crad-text);
    font-size: 0.92rem; outline: none;
    color-scheme: dark;
}
.crad-field textarea { min-height: 110px; resize: vertical; }
.crad-field input.crad-or-field {
    color: #93c5fd;
    background: rgba(37,99,235,0.12);
    border-color: rgba(37,99,235,0.35);
    cursor: default;
    font-weight: 700;
    letter-spacing: 0.03em;
}
.crad-field input:focus,
.crad-field select:focus,
.crad-field textarea:focus {
    border-color: #3b82f6; box-shadow: 0 0 0 3px var(--crad-blue-soft);
}
.crad-field select {
    appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath fill='%94a3b8' d='M1 1l5 5 5-5'/%3E%3C/svg%3E");
    background-repeat: no-repeat; background-position: right 0.9rem center; padding-right: 2.2rem;
}
.crad-section-head {
    display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem;
    margin: 0.35rem 0 1rem;
}
.crad-section-head h2 { margin: 0; color: #fff; font-size: 1.05rem; font-weight: 800; }
.crad-section-head p { margin: 0.25rem 0 0; color: var(--crad-muted); font-size: 0.88rem; }
.crad-link-btn {
    border: 0; background: transparent; color: #60a5fa;
    font-size: 0.9rem; font-weight: 700; white-space: nowrap; cursor: pointer;
}
.crad-link-btn:hover { color: #93c5fd; }
.crad-member-card {
    margin-bottom: 1rem; padding: 1rem;
    border: 1px solid var(--crad-border); border-radius: 12px; background: var(--crad-panel-2);
}
.crad-member-card h3 {
    display: flex; align-items: center; gap: 0.55rem;
    margin: 0 0 0.9rem; color: #e2e8f0; font-size: 0.78rem;
    font-weight: 800; letter-spacing: 0.06em; text-transform: uppercase;
}
.crad-member-card h3 span {
    width: 22px; height: 22px; display: inline-flex; align-items: center; justify-content: center;
    border-radius: 50%; background: var(--crad-blue); color: #fff; font-size: 0.72rem;
}
.crad-member-card .crad-remove {
    margin-left: auto; border: 0; background: transparent; color: #f87171;
    font-size: 0.78rem; font-weight: 700; cursor: pointer;
}
.crad-align-block {
    margin-bottom: 1.5rem; padding-bottom: 1.35rem;
    border-bottom: 1px solid var(--crad-border);
}
.crad-align-block:last-child { border-bottom: 0; margin-bottom: 0.5rem; padding-bottom: 0; }
.crad-align-head { margin-bottom: 0.9rem; }
.crad-align-head h2 {
    margin: 0; color: #fff; font-size: 1.02rem; font-weight: 800;
}
.crad-align-head h2 span { color: #f87171; }
.crad-align-head p {
    margin: 0.3rem 0 0; color: var(--crad-muted); font-size: 0.88rem;
}
.crad-align-head p strong { color: #e2e8f0; }
.crad-radio-grid {
    display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0.75rem;
}
.crad-radio-list { display: grid; gap: 0.65rem; }
.crad-radio-card {
    display: flex; align-items: flex-start; gap: 0.7rem;
    padding: 0.85rem 0.95rem; border: 1px solid var(--crad-border);
    border-radius: 12px; background: var(--crad-panel); cursor: pointer;
    transition: border-color 0.15s ease, background 0.15s ease, box-shadow 0.15s ease;
}
.crad-radio-card:hover { border-color: rgba(96,165,250,0.45); }
.crad-radio-card:has(input:checked) {
    border-color: #3b82f6;
    background: rgba(37,99,235,0.16);
    box-shadow: 0 0 0 1px rgba(59,130,246,0.35);
}
.crad-radio-card input {
    margin-top: 0.15rem; accent-color: var(--crad-blue); flex-shrink: 0;
}
.crad-radio-card span {
    color: #e2e8f0; font-size: 0.9rem; line-height: 1.4; font-weight: 600;
}
.crad-title-input {
    min-height: 120px !important;
    text-transform: uppercase;
    font-weight: 700;
    letter-spacing: 0.02em;
    line-height: 1.45;
}
.crad-verify-box {
    display: flex; align-items: flex-start; gap: 0.85rem;
    margin: 0.25rem 0 0.75rem; padding: 1rem 1.1rem;
    border: 1px solid rgba(59,130,246,0.35);
    border-radius: 12px;
    background: rgba(30,64,175,0.22);
}
.crad-verify-icon {
    width: 36px; height: 36px; flex-shrink: 0;
    display: inline-flex; align-items: center; justify-content: center;
    border-radius: 10px; background: rgba(37,99,235,0.35); color: #93c5fd;
}
.crad-verify-box h3 {
    margin: 0 0 0.3rem; color: #dbeafe; font-size: 0.92rem; font-weight: 800;
}
.crad-verify-box p {
    margin: 0; color: #bfdbfe; font-size: 0.86rem; line-height: 1.45;
}
.crad-sdg-tiles {
    display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 0.75rem;
}
.crad-sdg-tile {
    position: relative; display: flex; flex-direction: column; justify-content: center;
    min-height: 88px; padding: 0.9rem 0.95rem;
    border: 1px solid var(--crad-border); border-radius: 12px;
    background: var(--crad-panel); cursor: pointer;
    transition: border-color 0.15s ease, background 0.15s ease, transform 0.15s ease;
}
.crad-sdg-tile input {
    position: absolute; opacity: 0; pointer-events: none;
}
.crad-sdg-num {
    color: var(--crad-muted); font-size: 0.7rem; font-weight: 800;
    letter-spacing: 0.06em; text-transform: uppercase; margin-bottom: 0.25rem;
}
.crad-sdg-title {
    color: #f1f5f9; font-size: 0.9rem; font-weight: 700; line-height: 1.3;
}
.crad-sdg-tile:hover { border-color: rgba(251,146,60,0.45); }
.crad-sdg-tile.is-selected,
.crad-sdg-tile:has(input:checked) {
    border-color: #f97316;
    background: linear-gradient(135deg, #ea580c 0%, #f97316 100%);
    box-shadow: 0 10px 24px rgba(249,115,22,0.28);
}
.crad-sdg-tile.is-selected .crad-sdg-num,
.crad-sdg-tile:has(input:checked) .crad-sdg-num,
.crad-sdg-tile.is-selected .crad-sdg-title,
.crad-sdg-tile:has(input:checked) .crad-sdg-title {
    color: #fff;
}
.crad-sdg-grid {
    display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0.65rem;
}
.crad-check {
    display: flex; align-items: flex-start; gap: 0.65rem;
    padding: 0.75rem 0.85rem; border: 1px solid var(--crad-border);
    border-radius: 10px; background: var(--crad-panel); cursor: pointer;
}
.crad-check input { margin-top: 0.15rem; accent-color: var(--crad-blue); }
.crad-check span { color: #e2e8f0; font-size: 0.86rem; line-height: 1.35; }
.crad-form-footer {
    display: flex; align-items: center; justify-content: space-between; gap: 1rem;
    padding: 1rem 1.5rem 1.35rem; border-top: 1px solid var(--crad-border);
}

/* Printable CRAD form */
.crad-print-preview {
    padding: 1rem;
    border-radius: 16px;
    background: #111827;
}
.crad-print-actions {
    width: 210mm; max-width: 100%; display: flex; justify-content: flex-end; gap: 0.75rem;
    margin: 0 auto 1rem;
}
.crad-print-sheet {
    position: relative; width: 210mm; min-height: 297mm; max-width: 100%;
    margin: 0 auto 1.25rem; padding: 11mm 13mm 13mm;
    background: #fff; color: #111; font-family: Arial, Helvetica, sans-serif;
    box-shadow: 0 18px 48px rgba(0,0,0,0.35); box-sizing: border-box;
}
.print-document-header {
    display: grid; grid-template-columns: 14mm 1fr auto; align-items: center; gap: 3mm;
    padding-bottom: 3mm; border-bottom: 1.5px solid #111;
}
.print-bcp-mark {
    width: 12mm; height: 12mm; display: grid; place-items: center;
    border: 1.5px solid #333; border-radius: 50%; font-size: 7pt; font-weight: 800;
}
.print-bcp-logo-wrap {
    width: 14mm; height: 14mm; display: flex; align-items: center; justify-content: center;
    overflow: hidden; border-radius: 50%; background: #fff;
}
.print-bcp-logo {
    width: 29mm; max-width: none; height: auto; display: block; flex: 0 0 auto;
}
.print-school-name { display: grid; gap: 0.6mm; font-size: 6.5pt; line-height: 1.2; }
.print-school-name strong { font-size: 9pt; }
.print-school-name b { font-size: 7.5pt; }
.print-form-code { align-self: start; padding-top: 1mm; font-size: 6.5pt; font-weight: 700; }
.print-document-title {
    margin: 4mm 0 3mm; color: #111; font-size: 13pt; font-weight: 800;
    text-align: center; text-decoration: underline;
}
.print-meta {
    display: grid; grid-template-columns: 1fr 1.5fr; gap: 8mm;
    margin-bottom: 3mm; font-size: 7.5pt;
}
.print-meta span { display: inline-block; min-width: 36mm; padding: 0 1mm 0.5mm; border-bottom: 1px solid #333; }
.print-section { margin-bottom: 3mm; }
.print-section h2,
.print-choice-box h2,
.print-response-section h2,
.print-notes-box h2 {
    margin: 0 0 1.5mm; color: #111; font-size: 7.5pt; font-weight: 800;
}
.print-table { width: 100%; border-collapse: collapse; font-size: 6.5pt; }
.print-table th, .print-table td { padding: 1.2mm; border: 0.8px solid #222; vertical-align: top; }
.print-table th { font-weight: 800; text-align: center; }
.print-student-table th:first-child, .print-student-table td:first-child { width: 8mm; text-align: center; }
.print-student-table th:nth-child(3) { width: 26mm; }
.print-student-table th:nth-child(4) { width: 34mm; }
.print-student-table td { height: 5mm; }
.print-two-column { display: grid; grid-template-columns: 1fr 1fr; gap: 3mm; margin-bottom: 3mm; }
.print-choice-box { padding: 2.5mm; border: 0.8px solid #222; border-radius: 1.5mm; font-size: 6pt; }
.print-choice-box h2 { padding-bottom: 1.2mm; border-bottom: 0.8px solid #222; }
.print-choice-box > div { margin: 0.7mm 0; line-height: 1.25; }
.print-choice-box .is-selected { font-weight: 800; }
.print-other-value { padding-left: 4mm; font-style: italic; }
.print-sdg-box > p { margin: 0 0 1.5mm; font-size: 5.5pt; }
.print-sdg-list { display: grid; grid-template-columns: 1fr 1fr; column-gap: 2mm; }
.print-response-section { margin-bottom: 3mm; }
.print-response {
    min-height: 8mm; padding: 1.5mm 4mm; border-bottom: 0.8px solid #222;
    font-size: 8pt; font-weight: 800; text-align: center; line-height: 1.35;
}
.print-response-small { min-height: 10mm; font-size: 6.5pt; font-weight: 400; text-align: left; }
.print-approval-row { margin-top: 2mm; }
.print-signature-box { text-align: center; }
.print-signature-box h2 { text-align: left; }
.print-signature-line { height: 8mm; margin: 0 7mm 1mm; border-bottom: 0.8px solid #222; }
.print-signature-box strong { font-size: 6pt; font-weight: 400; }
.print-page-footer {
    position: absolute; right: 13mm; bottom: 7mm; left: 13mm;
    color: #333; font-size: 6pt; text-align: right;
}
.print-evaluation-table td { height: 15mm; }
.print-evaluation-table th:nth-child(2),
.print-evaluation-table th:nth-child(3) { width: 22mm; }
.print-evaluation-table th:last-child { width: 55mm; }
.print-notes-box { margin-top: 6mm; padding: 4mm; border: 0.8px solid #222; }
.print-notes-box div { height: 9mm; border-bottom: 0.6px solid #777; }
.print-final-decision { margin-top: 6mm; }
.print-final-decision p { margin: 3mm 0; font-size: 7.5pt; }

/* Print visual polish */
.crad-print-sheet {
    --print-navy: #17366f;
    --print-blue: #2457a7;
    --print-pale: #edf4ff;
    --print-line: #b9c7da;
    border-top: 4mm solid var(--print-navy);
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
}
.crad-print-sheet::before {
    content: "";
    position: absolute; top: 4mm; right: 0; width: 32mm; height: 1.2mm;
    background: #e9a23b;
}
.print-document-header {
    padding: 1mm 0 3.5mm;
    border-bottom: 1.2px solid var(--print-navy);
}
.print-bcp-mark {
    border: 1.5px solid var(--print-navy);
    color: var(--print-navy);
    box-shadow: inset 0 0 0 1.3mm #fff, inset 0 0 0 1.6mm var(--print-navy);
}
.print-school-name strong { color: var(--print-navy); letter-spacing: 0.02em; }
.print-school-name b { color: #243b63; }
.print-form-code {
    padding: 1.5mm 2mm;
    border: 0.7px solid #c3cede; border-radius: 1.5mm;
    background: var(--print-pale); color: var(--print-navy);
}
.print-document-title {
    position: relative; margin: 4mm auto;
    color: var(--print-navy); text-decoration: none; letter-spacing: 0.05em;
}
.print-document-title::after {
    content: ""; display: block; width: 34mm; height: 0.8mm;
    margin: 1.5mm auto 0; border-radius: 99px; background: #e9a23b;
}
.print-meta {
    padding: 2.5mm 3mm; border: 0.7px solid var(--print-line);
    border-radius: 1.5mm; background: #f8fbff;
}
.print-meta strong { color: var(--print-navy); }
.print-meta span { border-bottom-color: #7c8da5; font-weight: 600; }
.print-section h2,
.print-response-section h2,
.print-notes-box h2 {
    padding: 1.4mm 2mm;
    border-left: 1.4mm solid var(--print-blue);
    background: var(--print-pale); color: var(--print-navy);
    letter-spacing: 0.01em;
}
.print-table { border: 0.8px solid #6f7f95; }
.print-table th {
    border-color: #8796aa;
    background: #e4edf9; color: var(--print-navy);
}
.print-table td { border-color: #9ba8b9; }
.print-student-table tbody tr:nth-child(even) td { background: #fafcff; }
.print-choice-box {
    border-color: #8998ab;
    background: #fff;
    box-shadow: inset 0 0 0 0.4mm #f1f5f9;
}
.print-choice-box h2 {
    margin: -2.5mm -2.5mm 1.5mm;
    padding: 1.6mm 2.5mm;
    border: 0; border-radius: 1.2mm 1.2mm 0 0;
    background: var(--print-navy); color: #fff;
    letter-spacing: 0.01em;
}
.print-choice-box > div {
    padding: 0.5mm 1mm;
    border-radius: 0.8mm;
}
.print-choice-box .is-selected {
    background: #dceaff; color: #12366f;
    box-shadow: inset 1mm 0 0 var(--print-blue);
}
.print-response {
    min-height: 10mm; padding: 2.5mm 4mm;
    border: 0.7px solid var(--print-line); border-left: 1.4mm solid var(--print-blue);
    border-radius: 1.2mm; background: #fbfdff; color: #12294d;
}
.print-response-small { min-height: 12mm; color: #24364f; }
.print-signature-box { background: #fbfdff; }
.print-signature-line { border-bottom-color: #63738a; }
.print-notes-box {
    border-color: #8998ab; border-radius: 1.5mm; background: #fbfdff;
}
.print-notes-box h2 { margin: -4mm -4mm 2mm; border-radius: 1.2mm 1.2mm 0 0; }
.print-page-footer {
    padding-top: 1.5mm; border-top: 0.6px solid var(--print-line);
    color: #52647c; font-weight: 700;
}

@media print {
    @page { size: A4 portrait; margin: 0; }
    body * { visibility: hidden !important; }
    .crad-print-preview, .crad-print-preview * { visibility: visible !important; }
    .crad-print-preview {
        position: absolute; inset: 0; width: 100%; padding: 0; background: #fff;
    }
    .crad-print-actions { display: none !important; }
    .crad-print-sheet {
        width: 210mm; min-height: 297mm; margin: 0; box-shadow: none;
        break-after: page; page-break-after: always;
    }
    .crad-print-sheet:last-child { break-after: auto; page-break-after: auto; }
}
@media (max-width: 991.98px) {
    .crad-field-row, .crad-field-row-3, .crad-sdg-grid, .crad-radio-grid, .crad-sdg-tiles { grid-template-columns: 1fr; }
}
@media (max-width: 767.98px) {
    .crad-form-header, .crad-section-head, .crad-form-footer { flex-direction: column; align-items: stretch; }
    .crad-btn, .crad-link-btn { width: 100%; justify-content: center; }
}
</style>

<script>
(function () {
    var currentStep = 1;
    var totalSteps = 3;
    var maxMembers = 6;
    var form = document.getElementById('cradTitleForm');
    if (!form) {
        window.addEventListener('load', function () {
            window.setTimeout(function () { window.print(); }, 350);
        });
        return;
    }
    var memberList = document.getElementById('memberList');
    var addMemberBtn = document.getElementById('addMemberBtn');
    var backBtn = document.getElementById('cradBackBtn');
    var nextBtn = document.getElementById('cradNextBtn');
    var processField = document.getElementById('cradProcessField');

    function memberCount() {
        return memberList.querySelectorAll('.crad-member-card').length;
    }

    function renumberMembers() {
        memberList.querySelectorAll('.crad-member-card').forEach(function (card, index) {
            var n = index + 1;
            card.setAttribute('data-member', String(n));
            var title = card.querySelector('h3');
            title.innerHTML = '<span>' + n + '</span> Group Member Profile';
            if (n > 1) {
                var remove = document.createElement('button');
                remove.type = 'button';
                remove.className = 'crad-remove';
                remove.textContent = 'Remove';
                remove.addEventListener('click', function () {
                    card.remove();
                    renumberMembers();
                    addMemberBtn.disabled = memberCount() >= maxMembers;
                });
                title.appendChild(remove);
            }
        });
        addMemberBtn.disabled = memberCount() >= maxMembers;
    }

    function generateOrNumber() {
        var year = String(new Date().getFullYear()).slice(-2);
        var serial = String(Math.floor(10000 + Math.random() * 90000));
        var used = {};
        memberList.querySelectorAll('[data-auto-or]').forEach(function (input) {
            used[input.value] = true;
        });
        var orNumber = 'OR-' + year + serial;
        while (used[orNumber]) {
            serial = String(Math.floor(10000 + Math.random() * 90000));
            orNumber = 'OR-' + year + serial;
        }
        return orNumber;
    }

    function createMemberCard(n) {
        var card = document.createElement('article');
        card.className = 'crad-member-card';
        card.setAttribute('data-member', String(n));
        card.innerHTML =
            '<h3><span>' + n + '</span> Group Member Profile</h3>' +
            '<div class="crad-field-row crad-field-row-3">' +
            '  <div class="crad-field"><label>Full Name (Last, First, M.I.) <span>*</span></label><input type="text" name="member_name[]" required></div>' +
            '  <div class="crad-field"><label>Section <span>*</span></label><input type="text" name="member_section[]" required></div>' +
            '  <div class="crad-field"><label>Research Forum Receipt OR</label><input type="text" name="member_or[]" value="' + generateOrNumber() + '" readonly class="crad-or-field" data-auto-or></div>' +
            '</div>';
        return card;
    }

    function validateStep(step) {
        var panel = form.querySelector('[data-step-panel="' + step + '"]');
        var fields = panel.querySelectorAll('input[required], select[required], textarea[required]');
        for (var i = 0; i < fields.length; i++) {
            if (!fields[i].checkValidity()) {
                fields[i].reportValidity();
                return false;
            }
        }
        if (step === 2) {
            if (!panel.querySelector('input[name="discipline_cluster"]:checked')) {
                alert('Please select a Research Discipline Cluster.');
                return false;
            }
            var agenda = panel.querySelector('input[name="research_agenda"]:checked');
            if (!agenda) {
                alert('Please select an Institutional Research Agenda.');
                return false;
            }
            if (agenda.value.indexOf('Others') === 0) {
                var others = document.getElementById('agendaOthers');
                if (!others.value.trim()) {
                    others.focus();
                    alert('Please specify the other institutional research agenda.');
                    return false;
                }
            }
            if (!panel.querySelector('input[name="primary_sdg"]:checked')) {
                alert('Please select one primary SDG.');
                return false;
            }
        }
        return true;
    }

    function renderStep() {
        form.querySelectorAll('[data-step-panel]').forEach(function (panel) {
            var step = Number(panel.getAttribute('data-step-panel'));
            var active = step === currentStep;
            panel.hidden = !active;
            panel.classList.toggle('is-active', active);
        });

        form.querySelectorAll('[data-step-indicator]').forEach(function (item) {
            var step = Number(item.getAttribute('data-step-indicator'));
            item.classList.toggle('is-active', step === currentStep);
            item.classList.toggle('is-complete', step < currentStep);

            var icon = item.querySelector('.crad-step-icon');
            if (step < currentStep) {
                icon.innerHTML = '<i class="fas fa-check"></i>';
            } else if (step === currentStep) {
                icon.innerHTML = step === 3 ? '3' : '<i class="fas fa-check"></i>';
            } else if (step === 2) {
                icon.innerHTML = '<i class="fas fa-check"></i>';
            } else {
                icon.textContent = String(step);
            }
        });

        backBtn.disabled = currentStep === 1;
        nextBtn.classList.toggle('crad-btn-primary', currentStep !== totalSteps);
        nextBtn.classList.toggle('crad-btn-success', currentStep === totalSteps);
        nextBtn.textContent = currentStep === totalSteps ? 'Submit Proposed Title' : 'Next Step →';
    }

    addMemberBtn.addEventListener('click', function () {
        if (memberCount() >= maxMembers) return;
        memberList.appendChild(createMemberCard(memberCount() + 1));
        renumberMembers();
    });

    backBtn.addEventListener('click', function () {
        if (currentStep > 1) {
            currentStep -= 1;
            renderStep();
        }
    });

    nextBtn.addEventListener('click', function () {
        if (!validateStep(currentStep)) return;
        if (currentStep < totalSteps) {
            currentStep += 1;
            renderStep();
            return;
        }
        processField.disabled = false;
        form.submit();
    });

    renumberMembers();
    renderStep();

    var agendaOthersWrap = document.getElementById('agendaOthersWrap');
    var agendaOthers = document.getElementById('agendaOthers');
    form.querySelectorAll('input[name="research_agenda"]').forEach(function (radio) {
        radio.addEventListener('change', function () {
            var isOthers = radio.value.indexOf('Others') === 0 && radio.checked;
            agendaOthersWrap.hidden = !isOthers;
            agendaOthers.required = isOthers;
            if (!isOthers) agendaOthers.value = '';
        });
    });

    form.querySelectorAll('input[name="primary_sdg"]').forEach(function (radio) {
        radio.addEventListener('change', function () {
            form.querySelectorAll('.crad-sdg-tile').forEach(function (tile) {
                tile.classList.toggle('is-selected', tile.querySelector('input').checked);
            });
        });
    });

    var proposedTitle = document.getElementById('proposedTitle');
    proposedTitle.addEventListener('input', function () {
        var start = proposedTitle.selectionStart;
        var end = proposedTitle.selectionEnd;
        proposedTitle.value = proposedTitle.value.toUpperCase();
        proposedTitle.setSelectionRange(start, end);
    });
})();
</script>

<?php require_once ROOT_PATH . '/includes/layout-end.php'; ?>
