<?php
/**
 * SMS 2 - Online Learning & LMS - Overview
 */
$pageTitle    = 'Online Learning & LMS';
$activeModule = 'lms';
$activePage   = '';
$breadcrumbs  = [
    ['label' => 'Online Learning & LMS', 'url' => null],
];

require_once __DIR__ . '/../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="page-header">
    <h1><i class="fas fa-laptop text-sms-primary me-2"></i>Online Learning & LMS</h1>
    <p>Select a submodule below to get started.</p>
</div>

<div class="row g-3">
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/lms/pages/class-portal.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Class Portal</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/lms/pages/lesson-material-upload.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Lesson Material Upload</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/lms/pages/assignment-submission.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Assignment Submission</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/lms/pages/online-quiz.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Online Quiz</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/lms/pages/virtual-classroom-integration.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Virtual Classroom Integration</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/lms/pages/grading-integration.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Grading Integration</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/lms/pages/feedback-comments.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Feedback &amp; Comments</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/lms/pages/module-completion-tracking.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Module Completion Tracking</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/lms/pages/multimedia-support.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Multimedia Support</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/lms/pages/lms-analytics.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">LMS Analytics</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>

</div>

<?php require_once __DIR__ . '/../../includes/layout-end.php'; ?>
