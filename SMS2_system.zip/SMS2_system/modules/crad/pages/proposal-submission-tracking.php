<?php
/**
 * SMS 2 - Proposal Submission & Tracking
 * Module: CRAD — Research Proposals Hub
 */
require_once __DIR__ . '/../../../config/config.php';

$pageTitle    = 'Proposal Submission & Tracking';
$activeModule = 'crad';
$activePage   = 'proposal-submission-tracking';
$breadcrumbs  = [
    ['label' => 'CRAD', 'url' => BASE_URL . '/modules/crad/index.php'],
    ['label' => 'Proposal Submission & Tracking', 'url' => null],
];

$departments = [
    'Computer Science',
    'Business Administration',
    'Education',
    'Criminology',
    'Hospitality & Tourism Management',
    'Engineering / IT',
];

$processAction = $_GET['process'] ?? '';
$flashMessage = '';
if ($processAction === 'submit-draft') {
    $flashMessage = 'Draft research proposal has been submitted to the pipeline.';
}

$proposals = [
    [
        'id' => 'RES-2024-401',
        'status' => 'Panel Assigned',
        'status_class' => 'panel',
        'title' => 'Smart Campus Autonomous Attendance via RFID & AI',
        'lead' => 'Dr. Hank Pym',
        'dept' => 'Computer Science',
        'progress' => 40,
    ],
    [
        'id' => 'RES-2024-402',
        'status' => 'Submitted',
        'status_class' => 'submitted',
        'title' => 'Socio-economic Impact of gamified curriculum platforms in primary schools',
        'lead' => 'Prof. Jean Grey',
        'dept' => 'Education',
        'progress' => 20,
    ],
];

$activeCount = count($proposals);

require_once __DIR__ . '/../../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../../includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="proposal-hub">
    <header class="proposal-hub-header">
        <div>
            <h1>Research Proposals Hub</h1>
            <p>Submit and track institutional and academic research programs.</p>
        </div>
        <span class="proposal-hub-active">Active Proposals: <?= (int) $activeCount ?></span>
    </header>

    <?php if ($flashMessage !== ''): ?>
        <div class="proposal-hub-alert" role="alert">
            <i class="fas fa-check-circle"></i>
            <span><?= htmlspecialchars($flashMessage) ?></span>
        </div>
    <?php endif; ?>

    <section class="proposal-hub-panel">
        <h2 class="proposal-hub-section-title">Submit New Research Proposal</h2>
        <form class="proposal-hub-form" method="get" action="">
            <input type="hidden" name="process" value="submit-draft">
            <div class="proposal-hub-fields">
                <label class="proposal-hub-field">
                    <span>Proposal Title</span>
                    <input type="text" name="proposal_title" placeholder="e.g. AI Ethics in Academic Settings" required>
                </label>
                <label class="proposal-hub-field">
                    <span>Lead Researcher / Author</span>
                    <input type="text" name="lead_researcher" placeholder="Researcher name" required>
                </label>
                <label class="proposal-hub-field">
                    <span>Department</span>
                    <select name="department" required>
                        <?php foreach ($departments as $dept): ?>
                            <option value="<?= htmlspecialchars($dept) ?>" <?= $dept === 'Computer Science' ? 'selected' : '' ?>>
                                <?= htmlspecialchars($dept) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </div>
            <div class="proposal-hub-form-actions">
                <button type="submit" class="proposal-hub-submit">Submit Draft Proposal</button>
            </div>
        </form>
    </section>

    <section class="proposal-hub-panel proposal-hub-pipeline">
        <h2 class="proposal-hub-section-title">Proposal Pipeline Tracking</h2>
        <div class="proposal-hub-list">
            <?php foreach ($proposals as $proposal): ?>
                <article class="proposal-hub-card">
                    <div class="proposal-hub-card-top">
                        <span class="proposal-hub-id"><?= htmlspecialchars($proposal['id']) ?></span>
                        <span class="proposal-hub-status <?= htmlspecialchars($proposal['status_class']) ?>">
                            <?= htmlspecialchars($proposal['status']) ?>
                        </span>
                    </div>
                    <h3><?= htmlspecialchars($proposal['title']) ?></h3>
                    <p>Lead: <?= htmlspecialchars($proposal['lead']) ?> | Dept: <?= htmlspecialchars($proposal['dept']) ?></p>
                    <div class="proposal-hub-progress-meta">
                        <span>Tracking Progress Stage</span>
                        <strong><?= (int) $proposal['progress'] ?>%</strong>
                    </div>
                    <div class="proposal-hub-progress-track" aria-hidden="true">
                        <span style="width: <?= (int) $proposal['progress'] ?>%"></span>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
</div>

<style>
.proposal-hub {
    --ph-bg: #141618;
    --ph-panel: #1a1d21;
    --ph-line: rgba(148,163,184,0.18);
    --ph-text: #f8fafc;
    --ph-muted: #94a3b8;
    --ph-accent: #8b5cf6;
    --ph-accent-soft: rgba(139,92,246,0.16);
    max-width: 980px;
    margin: 0 auto;
    padding: 0.35rem 0.25rem 1.5rem;
    color: var(--ph-text);
}
.proposal-hub-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 1rem;
    margin-bottom: 1.15rem;
}
.proposal-hub-header h1 {
    margin: 0;
    color: #fff;
    font-size: 1.55rem;
    font-weight: 800;
    letter-spacing: -0.02em;
}
.proposal-hub-header p {
    margin: 0.35rem 0 0;
    color: var(--ph-muted);
    font-size: 0.92rem;
}
.proposal-hub-active {
    display: inline-flex;
    align-items: center;
    padding: 0.45rem 0.85rem;
    border-radius: 999px;
    border: 1px solid rgba(139,92,246,0.35);
    background: var(--ph-accent-soft);
    color: #c4b5fd;
    font-size: 0.78rem;
    font-weight: 700;
    white-space: nowrap;
}
.proposal-hub-alert {
    display: flex;
    align-items: center;
    gap: 0.6rem;
    margin-bottom: 1rem;
    padding: 0.8rem 1rem;
    border-radius: 12px;
    border: 1px solid rgba(16,185,129,0.28);
    background: rgba(16,185,129,0.12);
    color: #6ee7b7;
    font-size: 0.86rem;
    font-weight: 600;
}
.proposal-hub-panel {
    margin-bottom: 1.15rem;
    padding: 1.15rem 1.2rem 1.2rem;
    border: 1px solid var(--ph-line);
    border-radius: 16px;
    background: var(--ph-panel);
    box-shadow: 0 12px 28px rgba(0,0,0,0.18);
}
.proposal-hub-section-title {
    margin: 0 0 1rem;
    color: #9aa3b2;
    font-size: 0.72rem;
    font-weight: 800;
    letter-spacing: 0.08em;
    text-transform: uppercase;
}
.proposal-hub-fields {
    display: grid;
    gap: 0.9rem;
}
.proposal-hub-field {
    display: grid;
    gap: 0.4rem;
}
.proposal-hub-field span {
    color: #cbd5e1;
    font-size: 0.82rem;
    font-weight: 700;
}
.proposal-hub-field input,
.proposal-hub-field select {
    width: 100%;
    min-height: 44px;
    padding: 0.7rem 0.9rem;
    border: 1px solid rgba(148,163,184,0.22);
    border-radius: 10px;
    background: #121417;
    color: #f8fafc;
    font-size: 0.9rem;
    outline: none;
}
.proposal-hub-field input::placeholder { color: #6b7280; }
.proposal-hub-field input:focus,
.proposal-hub-field select:focus {
    border-color: rgba(139,92,246,0.55);
    box-shadow: 0 0 0 3px rgba(139,92,246,0.12);
}
.proposal-hub-form-actions {
    display: flex;
    justify-content: flex-end;
    margin-top: 1.1rem;
}
.proposal-hub-submit {
    min-height: 42px;
    padding: 0.65rem 1.15rem;
    border: 0;
    border-radius: 10px;
    background: linear-gradient(135deg, #7c3aed 0%, #8b5cf6 100%);
    color: #fff;
    font-size: 0.88rem;
    font-weight: 700;
    cursor: pointer;
    box-shadow: 0 10px 22px rgba(124,58,237,0.28);
}
.proposal-hub-submit:hover { filter: brightness(1.06); }
.proposal-hub-list { display: grid; gap: 0.9rem; }
.proposal-hub-card {
    padding: 1rem 1.05rem 1.1rem;
    border: 1px solid var(--ph-line);
    border-radius: 14px;
    background: #14171b;
}
.proposal-hub-card-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.75rem;
    margin-bottom: 0.65rem;
}
.proposal-hub-id {
    display: inline-flex;
    padding: 0.28rem 0.55rem;
    border-radius: 7px;
    background: rgba(139,92,246,0.14);
    color: #c4b5fd;
    font-size: 0.72rem;
    font-weight: 800;
    letter-spacing: 0.02em;
}
.proposal-hub-status {
    display: inline-flex;
    padding: 0.28rem 0.7rem;
    border-radius: 999px;
    border: 1px solid rgba(148,163,184,0.22);
    background: rgba(30,41,59,0.65);
    color: #e2e8f0;
    font-size: 0.7rem;
    font-weight: 700;
}
.proposal-hub-status.panel {
    color: #c4b5fd;
    border-color: rgba(139,92,246,0.35);
    background: rgba(139,92,246,0.12);
}
.proposal-hub-status.submitted {
    color: #cbd5e1;
    border-color: rgba(148,163,184,0.28);
    background: rgba(71,85,105,0.25);
}
.proposal-hub-card h3 {
    margin: 0;
    color: #fff;
    font-size: 1rem;
    font-weight: 800;
    line-height: 1.35;
}
.proposal-hub-card p {
    margin: 0.4rem 0 0.95rem;
    color: var(--ph-muted);
    font-size: 0.82rem;
}
.proposal-hub-progress-meta {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.75rem;
    margin-bottom: 0.45rem;
    color: #9aa3b2;
    font-size: 0.74rem;
    font-weight: 600;
}
.proposal-hub-progress-meta strong { color: #e2e8f0; font-weight: 800; }
.proposal-hub-progress-track {
    height: 6px;
    overflow: hidden;
    border-radius: 999px;
    background: rgba(148,163,184,0.18);
}
.proposal-hub-progress-track span {
    display: block;
    height: 100%;
    border-radius: inherit;
    background: linear-gradient(90deg, #3b82f6 0%, #60a5fa 100%);
}

[data-theme="light"] .proposal-hub {
    --ph-bg: #f4f7fc;
    --ph-panel: #ffffff;
    --ph-line: #c9d5e8;
    --ph-text: #0f172a;
    --ph-muted: #475569;
}
[data-theme="light"] .proposal-hub-header h1,
[data-theme="light"] .proposal-hub-card h3 {
    color: #0f172a;
}
[data-theme="light"] .proposal-hub-header p,
[data-theme="light"] .proposal-hub-card p {
    color: #475569;
}
[data-theme="light"] .proposal-hub-section-title {
    color: #334155;
}
[data-theme="light"] .proposal-hub-field span {
    color: #1e293b;
}
[data-theme="light"] .proposal-hub-panel,
[data-theme="light"] .proposal-hub-card {
    background: #fff;
    border-color: #c9d5e8;
    box-shadow: 0 8px 22px rgba(15,33,88,0.06);
}
[data-theme="light"] .proposal-hub-field input,
[data-theme="light"] .proposal-hub-field select {
    background: #fff;
    color: #0f172a;
    border-color: #94a3b8;
}
[data-theme="light"] .proposal-hub-field input::placeholder {
    color: #64748b;
}
[data-theme="light"] .proposal-hub-active {
    color: #5b21b6;
    border-color: #c4b5fd;
    background: #f3e8ff;
}
[data-theme="light"] .proposal-hub-id {
    color: #5b21b6;
    background: #ede9fe;
}
[data-theme="light"] .proposal-hub-status {
    color: #1e293b;
    border-color: #94a3b8;
    background: #f1f5f9;
}
[data-theme="light"] .proposal-hub-status.panel {
    color: #5b21b6;
    border-color: #c4b5fd;
    background: #f3e8ff;
}
[data-theme="light"] .proposal-hub-status.submitted {
    color: #334155;
    border-color: #94a3b8;
    background: #e2e8f0;
}
[data-theme="light"] .proposal-hub-progress-meta {
    color: #475569;
}
[data-theme="light"] .proposal-hub-progress-meta strong {
    color: #0f172a;
}
[data-theme="light"] .proposal-hub-progress-track {
    background: #cbd5e1;
}

@media (max-width: 767.98px) {
    .proposal-hub-header { flex-direction: column; }
    .proposal-hub-form-actions { justify-content: stretch; }
    .proposal-hub-submit { width: 100%; }
}
</style>

<?php require_once __DIR__ . '/../../../includes/layout-end.php'; ?>
