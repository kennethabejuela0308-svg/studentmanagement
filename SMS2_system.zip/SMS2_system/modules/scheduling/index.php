<?php
/**
 * SMS 2 - Class Scheduling - Overview
 */
$pageTitle    = 'Class Scheduling';
$activeModule = 'scheduling';
$activePage   = '';
$breadcrumbs  = [
    ['label' => 'Class Scheduling', 'url' => null],
];

require_once __DIR__ . '/../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="page-header">
    <h1><i class="fas fa-calendar-alt text-sms-primary me-2"></i>Class Scheduling</h1>
    <p>Select a submodule below to get started.</p>
</div>

<div class="row g-3">
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/scheduling/pages/section-assignment-tool.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Section Assignment Tool</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/scheduling/pages/teacher-schedule-mapping.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Teacher Schedule Mapping</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/scheduling/pages/conflict-checker.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Conflict Checker</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/scheduling/pages/exam-timetable-generator.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Exam Timetable Generator</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/scheduling/pages/substitute-assignment-tracker.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Substitute Assignment Tracker</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/scheduling/pages/special-class-scheduler.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Special Class Scheduler</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/scheduling/pages/room-availability-checker.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Room Availability Checker</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/scheduling/pages/schedule-cloning-tool.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Schedule Cloning Tool</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/scheduling/pages/time-block-generator.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Time Block Generator</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/scheduling/pages/calendar-integration.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Calendar Integration</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>

</div>

<?php require_once __DIR__ . '/../../includes/layout-end.php'; ?>
