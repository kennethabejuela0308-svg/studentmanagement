<?php
/**
 * SMS 2 - Curriculum & Subject Management - Overview
 */
$pageTitle    = 'Curriculum & Subject Management';
$activeModule = 'curriculum';
$activePage   = '';
$breadcrumbs  = [
    ['label' => 'Curriculum & Subject Management', 'url' => null],
];

require_once __DIR__ . '/../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="page-header">
    <h1><i class="fas fa-book text-sms-primary me-2"></i>Curriculum & Subject Management</h1>
    <p>Select a submodule below to get started.</p>
</div>

<div class="row g-3">
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/curriculum/pages/curriculum-builder.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Curriculum Builder</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/curriculum/pages/subject-mapping.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Subject Mapping</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/curriculum/pages/pre-requisite-configuration.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Pre-requisite Configuration</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/curriculum/pages/electives-manager.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Electives Manager</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/curriculum/pages/academic-strand-assignment.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Academic Strand Assignment</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/curriculum/pages/subject-offering-history.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Subject Offering History</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/curriculum/pages/subject-equivalency-tool.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Subject Equivalency Tool</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/curriculum/pages/grade-weighting-setup.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Grade Weighting Setup</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/curriculum/pages/ched-deped-validator.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">CHED/DepEd Validator</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/curriculum/pages/curriculum-export-tool.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Curriculum Export Tool</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>

</div>

<?php require_once __DIR__ . '/../../includes/layout-end.php'; ?>
