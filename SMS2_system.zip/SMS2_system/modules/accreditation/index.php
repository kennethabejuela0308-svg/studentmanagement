<?php
/**
 * SMS 2 - Accreditation Management - Overview
 */
$pageTitle    = 'Accreditation Management';
$activeModule = 'accreditation';
$activePage   = '';
$breadcrumbs  = [
    ['label' => 'Accreditation Management', 'url' => null],
];

require_once __DIR__ . '/../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="page-header">
    <h1><i class="fas fa-award text-sms-primary me-2"></i>Accreditation Management</h1>
    <p>Select a submodule below to get started.</p>
</div>

<div class="row g-3">
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/accreditation/pages/accreditation-document-repository.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Accreditation Document Repository</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/accreditation/pages/self-assessment-report-builder.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Self Assessment Report Builder</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/accreditation/pages/compliance-matrix-criteria-tracking.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Compliance Matrix &amp; Criteria Tracking</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/accreditation/pages/internal-quality-audit-scheduler.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Internal Quality Audit Scheduler</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/accreditation/pages/accreditation-visit-management.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Accreditation Visit Management</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/accreditation/pages/program-accreditation-tracker.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Program Accreditation Tracker</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/accreditation/pages/faculty-staff-qualification-tracking.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Faculty &amp; Staff Qualification Tracking</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/accreditation/pages/physical-facilities-monitoring.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Physical Facilities Monitoring</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/accreditation/pages/continuous-improvement-action-planning.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Continuous Improvement Action Planning</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/accreditation/pages/accreditation-reports-analytics.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Accreditation Reports &amp; Analytics</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>

</div>

<?php require_once __DIR__ . '/../../includes/layout-end.php'; ?>
