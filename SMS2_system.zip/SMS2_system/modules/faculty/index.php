<?php
/**
 * SMS 2 - Faculty Management - Overview
 */
$pageTitle    = 'Faculty Management';
$activeModule = 'faculty';
$activePage   = '';
$breadcrumbs  = [
    ['label' => 'Faculty Management', 'url' => null],
];

require_once __DIR__ . '/../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="page-header">
    <h1><i class="fas fa-chalkboard-teacher text-sms-primary me-2"></i>Faculty Management</h1>
    <p>Select a submodule below to get started.</p>
</div>

<div class="row g-3">
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/faculty/pages/faculty-profile.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Faculty Profile</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/faculty/pages/subject-load-tracker.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Subject Load Tracker</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/faculty/pages/schedule-assignment.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Schedule Assignment</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/faculty/pages/attendance-monitoring.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Attendance Monitoring</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/faculty/pages/leave-application-approval.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Leave Application &amp; Approval</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/faculty/pages/salary-grade-payroll-setup.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Salary Grade &amp; Payroll Setup</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/faculty/pages/teaching-history.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Teaching History</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/faculty/pages/clearance-system.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Clearance System</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/faculty/pages/evaluation-summary.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Evaluation Summary</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a href="<?= BASE_URL ?>/modules/faculty/pages/faculty-directory.php" class="text-decoration-none">
            <div class="card module-card hover-card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="card-icon"><i class="far fa-square"></i></div>
                    <div>
                        <h6 class="mb-0 fw-semibold">Faculty Directory</h6>
                        <small class="text-muted">Open submodule</small>
                    </div>
                </div>
            </div>
        </a>
    </div>

</div>

<?php require_once __DIR__ . '/../../includes/layout-end.php'; ?>
