<?php
/**
 * SMS 2 - Login Page
 */
require_once __DIR__ . '/../config/config.php';
require_once ROOT_PATH . '/includes/authentication.php';

// Redirect if already logged in
if (isAuthenticated()) {
    if (getCurrentUserRoleKey() === 'student') {
        header('Location: ' . BASE_URL . '/modules/student-portal/pages/my-profile.php');
        exit;
    }

    header('Location: ' . BASE_URL . '/dashboard/index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (attemptLogin($username, $password)) {
        if (getCurrentUserRoleKey() === 'student') {
            header('Location: ' . BASE_URL . '/modules/student-portal/pages/my-profile.php');
            exit;
        }

        header('Location: ' . BASE_URL . '/dashboard/index.php');
        exit;
    }

    $error = 'Please enter both username and password.';
}

$pageTitle = 'Login';
$bodyClass = 'login-page';

require_once ROOT_PATH . '/includes/header.php';
?>

<style>
body.login-page {
    min-height: 100vh;
    background-image:
        linear-gradient(90deg, rgba(5, 22, 55, 0.88) 0%, rgba(8, 42, 97, 0.8) 46%, rgba(15, 80, 153, 0.72) 100%),
        url("<?= BASE_URL ?>/images/school2.png") !important;
    background-size: cover !important;
    background-position: center !important;
    background-repeat: no-repeat !important;
    display: flex !important;
    flex-direction: column;
    align-items: stretch !important;
    justify-content: flex-start !important;
    padding: 0 !important;
    overflow-x: hidden;
}

.login-stage {
    box-sizing: border-box;
    flex: 1;
    min-height: calc(100vh - 70px);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 2rem;
}

.login-shell {
    width: min(1060px, 100%);
    min-height: 560px;
    display: grid;
    grid-template-columns: 1.15fr 0.85fr;
    overflow: hidden;
    border: 1px solid rgba(255, 255, 255, 0.72);
    border-radius: 22px;
    background: #fff;
    box-shadow: 0 28px 70px rgba(2, 12, 32, 0.32);
}

.login-showcase {
    min-height: 560px;
    display: flex;
    align-items: flex-end;
    padding: 0 36px 32px;
    color: #fff;
    background-image:
        linear-gradient(180deg, rgba(4, 23, 55, 0.08) 0%, rgba(4, 20, 50, 0.78) 100%),
        url("<?= BASE_URL ?>/images/school1.png");
    background-size: cover;
    background-position: center;
}

.login-showcase-content {
    max-width: 560px;
}

.login-showcase h1 {
    margin: 0 0 12px;
    color: #fff;
    font-family: Georgia, "Times New Roman", serif;
    font-size: clamp(2.4rem, 4vw, 3.25rem);
    line-height: 0.98;
    font-weight: 800;
    letter-spacing: 0;
    text-shadow: 0 4px 18px rgba(0, 0, 0, 0.28);
}

.login-showcase p {
    margin: 0;
    color: rgba(255, 255, 255, 0.95);
    font-size: 0.92rem;
    font-weight: 600;
    line-height: 1.3;
    text-shadow: 0 2px 12px rgba(0, 0, 0, 0.28);
}

.login-card {
    width: 100%;
    min-height: 560px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    padding: 48px 30px;
    border: 0 !important;
    border-radius: 0 !important;
    background: #fff !important;
    box-shadow: none !important;
}

.login-badge {
    width: fit-content;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 16px;
    padding: 7px 12px;
    border: 1px solid #d8e5ff;
    border-radius: 999px;
    background: #eef5ff;
    color: #0d4bd6;
    font-size: 0.78rem;
    font-weight: 800;
}

.login-heading {
    margin-bottom: 26px;
}

.login-heading h1 {
    margin: 0 0 8px;
    color: #111827;
    font-family: Georgia, "Times New Roman", serif;
    font-size: clamp(2.55rem, 4vw, 3rem);
    line-height: 1;
    font-weight: 800;
    letter-spacing: 0;
}

.login-heading p {
    margin: 0;
    color: #475569;
    font-size: 0.9rem;
    line-height: 1.4;
}

.login-card .form-label {
    margin-bottom: 8px;
    color: #111827;
    font-size: 0.8rem;
    font-weight: 800 !important;
}

.login-card .input-group {
    position: relative;
    display: flex;
    align-items: center;
}

.login-card .input-group-text {
    display: none !important;
}

.login-card .form-control {
    width: 100%;
    min-height: 44px;
    border: 1px solid #d7e1ef !important;
    border-radius: 11px !important;
    background: #fff !important;
    color: #111827;
    padding: 12px 14px !important;
    font-size: 14px;
    box-shadow: none;
}

.login-card .form-control::placeholder {
    color: #111827;
    opacity: 1;
}

.login-card .form-control:focus {
    border-color: #93b4ff !important;
    box-shadow: 0 0 0 3px rgba(38, 84, 211, 0.12) !important;
}

.login-card .password-group .form-control {
    padding-right: 46px !important;
}

.password-toggle {
    position: absolute;
    top: 50%;
    right: 13px;
    z-index: 5;
    width: 22px;
    height: 22px;
    padding: 0;
    border: 0;
    background: transparent;
    color: #718299;
    cursor: pointer;
    font-size: 0.95rem;
}

.login-card .mb-3 {
    margin-bottom: 15px !important;
}

.login-card .mb-4 {
    margin-bottom: 18px !important;
}

.login-card .btn-sms-primary {
    border: 0 !important;
    border-radius: 10px !important;
    background: #294ecb !important;
    color: #fff !important;
    padding: 13px 16px !important;
    font-size: 14px;
    font-weight: 800;
    box-shadow: 0 11px 20px rgba(41, 78, 203, 0.25);
}

.login-card .btn-sms-primary:hover,
.login-card .btn-sms-primary:focus {
    background: #2445b7 !important;
}

.login-footer {
    margin-top: 0;
    padding: 0 1.5rem 1.5rem;
    color: rgba(255, 255, 255, 0.88);
    font-size: 0.95rem;
    font-weight: 600;
    text-align: center;
    text-shadow: 0 2px 14px rgba(0, 0, 0, 0.35);
}

@media (max-width: 991.98px) {
    .login-shell {
        max-width: 560px;
        min-height: 0;
        grid-template-columns: 1fr;
    }

    .login-showcase {
        min-height: 300px;
        padding: 32px 28px;
    }

    .login-card {
        min-height: 0;
        padding: 36px 28px;
    }
}

@media (max-width: 575.98px) {
    .login-stage {
        min-height: auto;
        padding: 1rem;
    }

    .login-shell {
        border-radius: 18px;
    }

    .login-showcase {
        min-height: 250px;
        padding: 28px 24px;
    }

    .login-showcase h1 {
        font-size: 2.1rem;
    }

    .login-card {
        padding: 30px 22px;
    }

    .login-heading h1 {
        font-size: 2.35rem;
    }
}
</style>

<main class="login-stage">
<section class="login-shell" aria-label="Student Management System login">
    <div class="login-showcase">
        <div class="login-showcase-content">
            <h1>Student<br>Management System 2</h1>
            <p>Manage enrollment, student records, financial transactions, and clinic services in one secure platform.</p>
        </div>
    </div>
    <div class="login-card card shadow-lg">
        <div class="login-badge">
            <i class="fas fa-shield-alt"></i>
            <span>Secure Access Portal</span>
        </div>
        <div class="login-heading">
            <h1>Sign In</h1>
            <p>Please enter your account credentials to continue.</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <form method="POST" action="" novalidate>
            <div class="mb-3">
                <label for="username" class="form-label fw-medium">Email / Username</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0"><i class="fas fa-user text-muted"></i></span>
                    <input type="text" class="form-control border-start-0" id="username" name="username"
                           placeholder="Enter your email or username" required autofocus
                           value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
                </div>
            </div>
            <div class="mb-4">
                <label for="password" class="form-label fw-medium">Password</label>
                <div class="input-group password-group">
                    <span class="input-group-text bg-light border-end-0"><i class="fas fa-lock text-muted"></i></span>
                    <input type="password" class="form-control border-start-0" id="password" name="password"
                           placeholder="Enter your password" required>
                    <button class="password-toggle" type="button" aria-label="Show password" title="Show password">
                        <i class="far fa-eye"></i>
                    </button>
                </div>
            </div>
            <button type="submit" class="btn btn-sms-primary w-100 py-2 rounded-3">
                <i class="fas fa-sign-in-alt me-2"></i>Sign In
            </button>
        </form>
    </div>
</section>
</main>

<footer class="login-footer">
    <p class="mb-0">&copy; 2026 Bestlink College of the Philippines. All rights reserved.</p>
</footer>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const toggle = document.querySelector('.password-toggle');
    const password = document.getElementById('password');

    if (!toggle || !password) {
        return;
    }

    toggle.addEventListener('click', function () {
        const showPassword = password.type === 'password';
        password.type = showPassword ? 'text' : 'password';
        toggle.innerHTML = showPassword ? '<i class="far fa-eye-slash"></i>' : '<i class="far fa-eye"></i>';
        toggle.setAttribute('aria-label', showPassword ? 'Hide password' : 'Show password');
        toggle.setAttribute('title', showPassword ? 'Hide password' : 'Show password');
    });
});
</script>

<?php require_once ROOT_PATH . '/includes/scripts.php'; ?>
